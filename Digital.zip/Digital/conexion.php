<?php
declare(strict_types=1);

require_once __DIR__ . '/config/config_empresa.php';

/*
 * Esta conexión solo se usa para la alerta opcional de UNICLASS dentro de
 * Informes. Un límite corto evita que una caída de la red o de la base
 * empresarial retrase o deje inaccesible el informe principal.
 */
$timeout = 5;

try {
    $conexion = new PDO(
        'mysql:host=' . DB_HOST .
        ';port=' . DB_PORT .
        ';dbname=' . DB_NAME .
        ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => $timeout,
        ]
    );
} catch (PDOException $exception) {
    throw new RuntimeException('No fue posible conectar con la fuente empresarial.', 0, $exception);
}

return $conexion;
