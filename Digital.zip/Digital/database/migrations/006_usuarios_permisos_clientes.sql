SET NAMES utf8mb4;

-- Normaliza los roles históricos antes de limitar el catálogo a tres perfiles.
ALTER TABLE ad_usuarios
    MODIFY rol VARCHAR(30) NOT NULL DEFAULT 'CONSULTOR';

UPDATE ad_usuarios SET rol='TECNICO' WHERE rol='TIC';
UPDATE ad_usuarios SET rol='CONSULTOR' WHERE rol IN ('FINANCIERO','AUDITOR');
UPDATE ad_usuarios SET rol='CONSULTOR' WHERE rol NOT IN ('ADMIN','TECNICO','CONSULTOR');

ALTER TABLE ad_usuarios
    MODIFY rol ENUM('ADMIN','TECNICO','CONSULTOR') NOT NULL DEFAULT 'CONSULTOR';

ALTER TABLE ad_usuarios
    ADD COLUMN IF NOT EXISTS todos_clientes_dashboard TINYINT(1) NOT NULL DEFAULT 0 AFTER activo;

UPDATE ad_usuarios
SET todos_clientes_dashboard=1
WHERE rol='ADMIN';

CREATE TABLE IF NOT EXISTS ad_permisos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(100) NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    modulo VARCHAR(80) NOT NULL,
    descripcion VARCHAR(255) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    orden INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ad_permiso_codigo (codigo),
    KEY idx_ad_permiso_modulo (modulo, orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_usuario_permisos (
    usuario_id BIGINT UNSIGNED NOT NULL,
    permiso_id BIGINT UNSIGNED NOT NULL,
    permitido TINYINT(1) NOT NULL DEFAULT 0,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, permiso_id),
    CONSTRAINT fk_ad_usuario_permiso_usuario FOREIGN KEY (usuario_id) REFERENCES ad_usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_ad_usuario_permiso_catalogo FOREIGN KEY (permiso_id) REFERENCES ad_permisos(id) ON DELETE CASCADE,
    KEY idx_ad_usuario_permiso_permitido (usuario_id, permitido)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_clientes_dashboard (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(80) NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ad_cliente_dashboard_codigo (codigo),
    UNIQUE KEY uq_ad_cliente_dashboard_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_usuario_clientes_dashboard (
    usuario_id BIGINT UNSIGNED NOT NULL,
    cliente_id BIGINT UNSIGNED NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, cliente_id),
    CONSTRAINT fk_ad_usuario_cliente_usuario FOREIGN KEY (usuario_id) REFERENCES ad_usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_ad_usuario_cliente_cliente FOREIGN KEY (cliente_id) REFERENCES ad_clientes_dashboard(id) ON DELETE CASCADE,
    KEY idx_ad_usuario_cliente_cliente (cliente_id, usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ad_permisos (codigo,nombre,modulo,descripcion,orden) VALUES
('dashboard.ver','Ver resumen general','Dashboard','Permite consultar el panel principal.',10),
('dashboards.clientes.ver','Ver informes por cliente','Informes','Permite consultar informes respetando los clientes asignados.',20),
('cuentas.ver','Ver cuentas','Cuentas','Permite consultar cuentas y licencias asignadas.',30),
('cuentas.editar','Gestionar cuentas','Cuentas','Permite crear, modificar y gestionar cuentas.',40),
('licencias.ver','Ver licencias','Licencias','Permite consultar información de licencias.',50),
('licencias.editar','Gestionar licencias','Licencias','Permite modificar asignaciones de licencias.',60),
('novedades.ver','Ver novedades','Novedades','Permite consultar novedades.',70),
('respaldos.ver','Ver backups','Backups','Permite consultar respaldos.',100),
('respaldos.crear','Crear backups','Backups','Permite registrar respaldos.',110),
('respaldos.editar','Gestionar backups','Backups','Permite modificar respaldos.',120),
('facturas.ver','Ver facturas','Facturas','Permite consultar facturación y costos.',130),
('facturas.crear','Crear facturas','Facturas','Permite registrar facturas.',140),
('facturas.editar','Gestionar facturas','Facturas','Permite modificar información de facturación.',150),
('facturas.conciliar','Conciliar y distribuir','Facturas','Permite conciliar facturas y distribuir costos.',160),
('facturas.aprobar','Aprobar facturas','Facturas','Permite aprobar facturas.',170),
('auditoria.ver','Ver auditoría','Administración','Permite consultar sesiones y eventos auditados.',180),
('usuarios.administrar','Administrar usuarios y permisos','Administración','Permite crear usuarios y configurar permisos y clientes.',190)
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),modulo=VALUES(modulo),descripcion=VALUES(descripcion),orden=VALUES(orden),activo=1;

INSERT INTO ad_clientes_dashboard (codigo,nombre,activo) VALUES
('ATP','ATP',1),
('CASA_MATRIZ','CASA MATRIZ',1),
('CLARO_PERU','CLARO PERU',1),
('CLARO_R3','CLARO R3',1),
('CLARO_R4','CLARO R4',1),
('HUAWEI','HUAWEI',1),
('HUAWEI_PERU','HUAWEI PERU',1),
('ISP','ISP',1),
('MOVISTAR','MOVISTAR',1),
('NA','NA',1),
('TIGO','TIGO',1),
('TRANSV_CTL','TRANSV CTL',1),
('TRANSV_CTV','TRANSV CTV',1),
('ZTE','ZTE',1)
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),activo=1;
