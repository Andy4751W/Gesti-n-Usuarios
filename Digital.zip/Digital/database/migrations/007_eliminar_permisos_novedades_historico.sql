SET NAMES utf8mb4;

-- Novedades es un histórico de solo lectura. No toca ad_novedades.
-- Las sentencias son idempotentes y eliminan primero las asignaciones.
DELETE up
FROM ad_usuario_permisos up
INNER JOIN ad_permisos p ON p.id = up.permiso_id
WHERE p.modulo = 'Novedades'
  AND p.codigo <> 'novedades.ver';

DELETE FROM ad_permisos
WHERE modulo = 'Novedades'
  AND codigo <> 'novedades.ver';

UPDATE ad_permisos
SET nombre = 'Ver novedades',
    descripcion = 'Permite consultar el histórico de novedades.',
    activo = 1
WHERE modulo = 'Novedades'
  AND codigo = 'novedades.ver';
