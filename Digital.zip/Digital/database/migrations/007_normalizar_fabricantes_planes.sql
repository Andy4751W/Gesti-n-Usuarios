-- Completa solo fabricantes ausentes de planes históricos; no modifica tarifas,
-- asignaciones, cuentas, clientes ni fabricantes ya definidos.
UPDATE ad_planes
SET fabricante = CASE
    WHEN UPPER(nombre) LIKE '%MICROSOFT%365%'
      OR UPPER(nombre) LIKE '%OFFICE%365%'
      OR UPPER(nombre) LIKE '%EXCHANGE%ONLINE%'
      OR UPPER(nombre) LIKE '%ONEDRIVE%'
      OR UPPER(nombre) LIKE '%PLANNER%'
      OR UPPER(nombre) LIKE '%PROJECT%'
      OR UPPER(nombre) LIKE '%POWER%BI%'
        THEN 'MICROSOFT'
    WHEN UPPER(nombre) LIKE '%G%SUITE%'
      OR UPPER(nombre) LIKE '%GOOGLE%WORKSPACE%'
      OR UPPER(nombre) LIKE '%GOOGLE%DRIVE%'
      OR UPPER(nombre) LIKE '%GOOGLE%MEET%'
      OR UPPER(nombre) LIKE '%GOOGLE%VAULT%'
        THEN 'GOOGLE'
    ELSE fabricante
END
WHERE NULLIF(TRIM(fabricante), '') IS NULL
   OR UPPER(TRIM(fabricante)) = 'SIN FABRICANTE';