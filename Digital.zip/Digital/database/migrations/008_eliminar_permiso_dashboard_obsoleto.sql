SET NAMES utf8mb4;

-- Dashboard fue reemplazado por Informes. No modifica datos funcionales ni informes.
DELETE up
FROM ad_usuario_permisos up
INNER JOIN ad_permisos p ON p.id = up.permiso_id
WHERE p.codigo IN ('dashboard.ver', 'resumen.ver')
   OR p.modulo = 'Dashboard';

DELETE FROM ad_permisos
WHERE codigo IN ('dashboard.ver', 'resumen.ver')
   OR modulo = 'Dashboard';
