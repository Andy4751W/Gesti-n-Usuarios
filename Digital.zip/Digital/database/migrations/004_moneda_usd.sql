ALTER TABLE ad_proveedores MODIFY moneda_principal CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE ad_dominios MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE ad_suscripciones MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE ad_asignaciones_licencia MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE ad_facturas MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';
ALTER TABLE ad_perfiles_distribucion_cuenta MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';

ALTER TABLE ad_reglas_integrales
    ADD COLUMN IF NOT EXISTS moneda CHAR(3) NOT NULL DEFAULT 'USD' AFTER ingresos;
ALTER TABLE ad_reglas_integrales MODIFY moneda CHAR(3) NOT NULL DEFAULT 'USD';

-- No se convierten ni se dividen los valores históricos.
-- Las tarifas reales se registran directamente en USD desde Datos maestros.
