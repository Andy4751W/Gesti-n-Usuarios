SET NAMES utf8mb4;

-- Permite registrar acciones descriptivas adicionales sin limitar la auditoría
-- existente a un catálogo ENUM cerrado.
ALTER TABLE ad_auditoria
    MODIFY accion VARCHAR(60) NOT NULL;

CREATE TABLE IF NOT EXISTS ad_sesiones_usuario (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_hash CHAR(64) NOT NULL,
    usuario_id BIGINT UNSIGNED NULL,
    usuario_nombre VARCHAR(180) NULL,
    usuario_email VARCHAR(190) NULL,
    rol VARCHAR(100) NULL,
    ip VARCHAR(64) NULL,
    user_agent VARCHAR(500) NULL,
    iniciada_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ultima_actividad_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cerrada_at DATETIME NULL,
    estado ENUM('ABIERTA','CERRADA') NOT NULL DEFAULT 'ABIERTA',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ad_sesion_hash (session_hash),
    KEY idx_ad_sesion_usuario_estado (usuario_id, estado),
    KEY idx_ad_sesion_ultima_actividad (ultima_actividad_at),
    KEY idx_ad_sesion_ip (ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_auditoria_sesiones (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_hash CHAR(64) NOT NULL,
    usuario_id BIGINT UNSIGNED NULL,
    usuario_nombre VARCHAR(180) NULL,
    usuario_email VARCHAR(190) NULL,
    rol VARCHAR(100) NULL,
    evento VARCHAR(40) NOT NULL,
    modulo VARCHAR(100) NULL,
    ruta VARCHAR(500) NOT NULL,
    metodo VARCHAR(10) NOT NULL,
    ip VARCHAR(64) NULL,
    user_agent VARCHAR(500) NULL,
    codigo_http SMALLINT UNSIGNED NULL,
    detalles JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_ad_audit_session_fecha (created_at),
    KEY idx_ad_audit_session_evento (evento, created_at),
    KEY idx_ad_audit_session_usuario (usuario_id, created_at),
    KEY idx_ad_audit_session_modulo (modulo, created_at),
    KEY idx_ad_audit_session_ip (ip, created_at),
    KEY idx_ad_audit_session_hash (session_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
