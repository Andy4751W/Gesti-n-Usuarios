CREATE TABLE IF NOT EXISTS ad_validaciones_uniclass_cuenta (
    cuenta_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    estado ENUM('ACTIVO','PENDIENTE_REGISTRO_UNICLASS','RETIRADO_CON_LICENCIA','UNICLASS_NO_DISPONIBLE') NOT NULL,
    est_uniclass CHAR(1) NULL,
    ultima_validacion DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ad_validacion_uniclass_cuenta
        FOREIGN KEY (cuenta_id) REFERENCES ad_cuentas(id) ON DELETE CASCADE,
    KEY idx_ad_validacion_uniclass_estado (estado),
    KEY idx_ad_validacion_uniclass_fecha (ultima_validacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;