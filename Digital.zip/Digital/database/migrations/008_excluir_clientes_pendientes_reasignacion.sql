-- Conserva los registros históricos N/A, pero evita que aparezcan como
-- clientes asignables o consultables en Informes.
UPDATE ad_clientes_dashboard
SET activo = 0
WHERE REPLACE(REPLACE(REPLACE(UPPER(TRIM(nombre)), '/', ''), '.', ''), ' ', '') = 'NA';