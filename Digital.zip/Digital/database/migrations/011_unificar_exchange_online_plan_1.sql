-- Unifica las dos denominaciones sin perder suscripciones, precios ni historicos.
SET @canonical_plan_id = (SELECT id FROM ad_planes WHERE UPPER(TRIM(nombre)) = 'EXCHANGE ONLINE (PLAN 1)' ORDER BY id LIMIT 1);
SET @legacy_plan_id = (SELECT id FROM ad_planes WHERE UPPER(TRIM(nombre)) = 'EXCHANGE ONLINE PLAN 1' ORDER BY id LIMIT 1);

-- Si solo existe el registro antiguo, se convierte en el plan canonico.
UPDATE ad_planes
SET nombre = 'EXCHANGE ONLINE (PLAN 1)'
WHERE @canonical_plan_id IS NULL
  AND id = @legacy_plan_id;

-- Permite instalaciones donde ninguno de los dos registros exista.
INSERT INTO ad_planes (codigo, nombre, fabricante, categoria, activo)
SELECT 'EXO_P1_CANONICAL', 'EXCHANGE ONLINE (PLAN 1)', 'MICROSOFT', 'CORREO', 1
WHERE @canonical_plan_id IS NULL
  AND @legacy_plan_id IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM ad_planes WHERE nombre = 'EXCHANGE ONLINE (PLAN 1)'
  );

SET @canonical_plan_id = (SELECT id FROM ad_planes WHERE UPPER(TRIM(nombre)) = 'EXCHANGE ONLINE (PLAN 1)' ORDER BY id LIMIT 1);
SET @legacy_plan_id = (SELECT id FROM ad_planes WHERE UPPER(TRIM(nombre)) = 'EXCHANGE ONLINE PLAN 1' ORDER BY id LIMIT 1);

UPDATE ad_planes
SET activo = 1
WHERE id = @canonical_plan_id;

-- Todas las suscripciones conservan sus propios contratos, monedas, precios y estados.
UPDATE ad_suscripciones
SET plan_id = @canonical_plan_id
WHERE @canonical_plan_id IS NOT NULL
  AND @legacy_plan_id IS NOT NULL
  AND plan_id = @legacy_plan_id;

-- Ambos nombres quedan registrados como alias del mismo plan.
INSERT INTO ad_plan_aliases (plan_id, alias, alias_normalizado)
SELECT @canonical_plan_id, 'EXCHANGE ONLINE PLAN 1', 'EXCHANGE ONLINE PLAN 1'
WHERE @canonical_plan_id IS NOT NULL
ON DUPLICATE KEY UPDATE plan_id = VALUES(plan_id), alias = VALUES(alias);

INSERT INTO ad_plan_aliases (plan_id, alias, alias_normalizado)
SELECT @canonical_plan_id, 'EXCHANGE ONLINE (PLAN 1)', 'EXCHANGE ONLINE (PLAN 1)'
WHERE @canonical_plan_id IS NOT NULL
ON DUPLICATE KEY UPDATE plan_id = VALUES(plan_id), alias = VALUES(alias);

-- Conserva una sola asignacion activa por cuenta y plan, cerrando solo duplicados.
UPDATE ad_asignaciones_licencia duplicate_assignment
INNER JOIN ad_asignaciones_licencia kept_assignment
        ON kept_assignment.cuenta_id = duplicate_assignment.cuenta_id
       AND kept_assignment.estado = 'ACTIVA'
       AND kept_assignment.id < duplicate_assignment.id
INNER JOIN ad_suscripciones duplicate_subscription
        ON duplicate_subscription.id = duplicate_assignment.suscripcion_id
INNER JOIN ad_suscripciones kept_subscription
        ON kept_subscription.id = kept_assignment.suscripcion_id
       AND kept_subscription.plan_id = duplicate_subscription.plan_id
SET duplicate_assignment.estado = 'CERRADA',
    duplicate_assignment.fecha_fin = COALESCE(duplicate_assignment.fecha_fin, CURDATE()),
    duplicate_assignment.motivo = 'DEPURACION_DUPLICADO_PLAN_CANONICO'
WHERE duplicate_assignment.estado = 'ACTIVA';

-- El registro antiguo se conserva para no borrar informacion, pero queda inactivo
-- solo cuando ya no tiene suscripciones asociadas.
UPDATE ad_planes old_plan
LEFT JOIN ad_suscripciones referenced_subscription
       ON referenced_subscription.plan_id = old_plan.id
SET old_plan.activo = 0
WHERE old_plan.id = @legacy_plan_id
  AND old_plan.id <> @canonical_plan_id
  AND referenced_subscription.id IS NULL;
