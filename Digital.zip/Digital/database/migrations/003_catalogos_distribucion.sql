ALTER TABLE ad_cuentas
    MODIFY estado ENUM('ACTIVA','GESTION_DE_BAJA','ELIMINADA') NOT NULL DEFAULT 'ACTIVA';

CREATE TABLE IF NOT EXISTS ad_cu1_catalogo (
    codigo VARCHAR(30) PRIMARY KEY,
    descripcion_corta VARCHAR(190) NULL,
    descripcion VARCHAR(255) NULL,
    proceso VARCHAR(190) NULL,
    regional VARCHAR(120) NULL,
    ciudad VARCHAR(120) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    fuente VARCHAR(80) NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_ad_cu1_activo (activo),
    KEY idx_ad_cu1_proceso (proceso)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_cu3_catalogo (
    codigo VARCHAR(30) PRIMARY KEY,
    descripcion_corta VARCHAR(190) NULL,
    descripcion VARCHAR(255) NULL,
    cliente VARCHAR(190) NULL,
    linea_negocio VARCHAR(190) NULL,
    proyecto VARCHAR(190) NULL,
    linea_temp VARCHAR(120) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    fuente VARCHAR(80) NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_ad_cu3_activo (activo),
    KEY idx_ad_cu3_cliente (cliente)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_almacenes_distribucion (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    clave VARCHAR(70) NOT NULL,
    cu1 VARCHAR(30) NULL,
    cu3 VARCHAR(30) NULL,
    codigo_almacen VARCHAR(40) NOT NULL,
    descripcion VARCHAR(255) NULL,
    cliente VARCHAR(190) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    fuente VARCHAR(80) NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ad_almacen_clave (clave),
    KEY idx_ad_almacen_codigo (codigo_almacen),
    KEY idx_ad_almacen_cu (cu1, cu3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_reglas_integrales (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    clave CHAR(64) NOT NULL,
    cliente VARCHAR(190) NOT NULL,
    linea_negocio VARCHAR(190) NOT NULL,
    ciudad VARCHAR(120) NOT NULL,
    proyecto VARCHAR(190) NOT NULL,
    ingresos DECIMAL(20,2) NOT NULL DEFAULT 0,
    moneda CHAR(3) NOT NULL DEFAULT 'USD',
    porcentaje DECIMAL(14,10) NOT NULL DEFAULT 0,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    fuente VARCHAR(80) NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ad_regla_integral_clave (clave),
    KEY idx_ad_regla_integral_activa (activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_perfiles_distribucion_cuenta (
    cuenta_id BIGINT UNSIGNED PRIMARY KEY,
    plan_fuente VARCHAR(190) NULL,
    costo_mensual DECIMAL(18,4) NULL,
    moneda CHAR(3) NOT NULL DEFAULT 'USD',
    cu1 VARCHAR(30) NULL,
    proceso_cu1 VARCHAR(190) NULL,
    regional VARCHAR(120) NULL,
    ciudad VARCHAR(120) NULL,
    cu3 VARCHAR(30) NULL,
    cliente VARCHAR(190) NULL,
    linea_negocio VARCHAR(190) NULL,
    proyecto VARCHAR(190) NULL,
    grupo VARCHAR(120) NULL,
    empresa VARCHAR(190) NULL,
    proceso_general VARCHAR(190) NULL,
    tipo_proyecto VARCHAR(120) NULL,
    observaciones VARCHAR(500) NULL,
    fuente VARCHAR(80) NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ad_perfil_dist_cuenta FOREIGN KEY (cuenta_id) REFERENCES ad_cuentas(id) ON DELETE CASCADE,
    KEY idx_ad_perfil_dist_cu (cu1, cu3),
    KEY idx_ad_perfil_dist_cliente (cliente)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
