CREATE TABLE IF NOT EXISTS ad_sincronizaciones_uniclass (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('INICIADA','COMPLETADA','COMPLETADA_CON_ERRORES','FALLIDA') NOT NULL,
    total_cuentas INT UNSIGNED NOT NULL DEFAULT 0,
    cuentas_actualizadas INT UNSIGNED NOT NULL DEFAULT 0,
    lotes_fallidos INT UNSIGNED NOT NULL DEFAULT 0,
    mensaje VARCHAR(500) NULL,
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at DATETIME NULL,
    KEY idx_ad_sync_uniclass_fecha (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;