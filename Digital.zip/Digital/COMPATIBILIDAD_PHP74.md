# Compatibilidad con PHP 7.4

El proyecto fue revisado integralmente para ejecutarse en PHP 7.4.

## Ajustes aplicados

- Eliminación de tipos `mixed` y `never`.
- Sustitución de propiedades `readonly` y promoción de propiedades en constructores.
- Eliminación de tipos unión.
- Sustitución de `str_contains()` y `str_starts_with()` por comparaciones con `strpos()`.
- Corrección de capturas `catch` sin variable.
- Control de versión mínima al iniciar la aplicación.
- Conservación de tipos, operadores y funciones disponibles en PHP 7.4.

## Extensiones requeridas

- `pdo_mysql`
- `mbstring`
- `zip`
- `simplexml`
- `json`

## Base de datos

El proyecto utiliza PDO con MySQL/MariaDB. Las credenciales se encuentran en `config/module.php` y deben modificarse antes de pasar a producción.

## Verificación recomendada en el servidor

```text
php -v
php -m
php bin/status.php
```

La primera instrucción debe mostrar PHP `7.4.x`; la segunda permite confirmar las extensiones y la tercera comprueba la conexión de la aplicación.
