<?php
declare(strict_types=1);

const DB_HOST = '68.178.198.21';      // Host/IP provisto por ti
const DB_PORT = 3306;
const DB_NAME = 'SRCGC';            // Nombre de tu base
const DB_USER = 'TicsConectar';     // Usuario creado
const DB_PASS = 'Conectaraldia2*';  // ContraseÃ±a

const APP_TIMEZONE = 'America/Bogota';

date_default_timezone_set(APP_TIMEZONE);

define('BASE_URL', '/SRCGC'); 
// Si algï¿½ï¿½ï¿½n dï¿½ï¿½ï¿½a cambias de carpeta, solo modificas aquï¿½ï¿½ï¿½.

