<?php
declare(strict_types=1);

return [
    /*
     * Configuración general de la aplicación
     */
    'app_name' => getenv('APP_NAME')
        ?: 'Activos Digitales',

    'environment' => getenv('APP_ENV')
        ?: 'development',

    'base_url' => rtrim(
        getenv('APP_BASE_URL') ?: '',
        '/'
    ),

    'storage_path' => getenv('APP_STORAGE_PATH')
        ?: dirname(__DIR__) . '/storage',

    'max_pdf_bytes' => (int)(
        getenv('MAX_PDF_BYTES')
        ?: 10 * 1024 * 1024
    ),

    'max_xlsx_bytes' => (int)(
        getenv('MAX_XLSX_BYTES')
        ?: 30 * 1024 * 1024
    ),

    'timezone' => getenv('APP_TIMEZONE')
        ?: 'America/Bogota',

    /*
     * Todos los valores monetarios nuevos se registran directamente en dólares.
     * No se aplica conversión desde COP ni se consulta una tasa de cambio.
     */
    'currency' => 'USD',

    /*
     * Conexión con MariaDB
     */
    'database' => [
        'host' => getenv('DB_HOST')
            ?: '127.0.0.1',

        'port' => (int)(
            getenv('DB_PORT')
            ?: 3306
        ),

        'name' => getenv('DB_DATABASE')
            ?: 'activos_digitales',

        'username' => getenv('DB_USERNAME')
            ?: 'root',

        'password' => getenv('DB_PASSWORD')
            ?: '',

        'charset' => 'utf8mb4',
    ],

    /*
     * Conexión empresarial existente. No se duplican los datos de UNICLASS:
     * el informe incluye este archivo y consulta mae_data_uniclass en vivo.
     * Por defecto se espera C:\xampp\htdocs\Digital\conexion.php.
     */
    'uniclass_connection' => [
        'file' => getenv('UNICLASS_CONNECTION_FILE')
            ?: dirname(__DIR__) . '/conexion.php',
    ],

    /*
     * Permisos por rol
     */
    'roles' => [
        'ADMIN' => [
            '*',
        ],

        'TECNICO' => [
            'dashboards.clientes.ver',

            'cuentas.ver',
            'cuentas.editar',

            'licencias.ver',
            'licencias.editar',

            'novedades.ver',

            'respaldos.ver',
            'respaldos.crear',
            'respaldos.editar',

            'facturas.ver',
            'facturas.crear',
            'facturas.editar',
            'facturas.conciliar',
        ],

        'CONSULTOR' => [
            'dashboards.clientes.ver',
        ],
    ],
];
