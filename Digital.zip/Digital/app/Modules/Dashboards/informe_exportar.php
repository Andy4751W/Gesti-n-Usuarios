<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('dashboards.clientes.ver');

$service = new ClientDashboardService(db());
$clientValue = trim((string)($_GET['cliente'] ?? ''));
$isAllClients = mb_strtolower($clientValue, 'UTF-8') === 'all';
if ($isAllClients && ad_user_role() !== 'ADMIN') {
    ad_deny_access('dashboards.clientes.todos');
}
$client = $isAllClients ? [
    'id' => 0,
    'codigo' => 'ALL',
    'nombre' => 'TODOS LOS CLIENTES',
    'aliases' => array_column($service->visibleClients(), 'nombre'),
] : $service->findVisibleClient(max(0, (int)$clientValue));
if (!$client) {
    http_response_code(403);
    exit('El cliente solicitado no está autorizado.');
}

$licenseId = max(0, (int)($_GET['licencia'] ?? 0));
$search = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 160, 'UTF-8');
$filename = 'informe-licencias-' . preg_replace('/[^a-z0-9_-]+/i', '-', (string)$client['codigo']) . '-' . date('Ymd-His') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');

$output = fopen('php://output', 'wb');
fwrite($output, "\xEF\xBB\xBF");
fputcsv($output, [
    'Cuenta', 'Nombre', 'Documento', 'Cargo', 'Licencia', 'Fabricante', 'Valor mensual USD',
    'CU3', 'Cliente', 'Línea', 'Proyecto', 'Ciudad', 'País'
], ';');

$safe = static function ($value): string {
    $text = (string)$value;
    return preg_match('/^[=+\-@]/', $text) ? "'" . $text : $text;
};

$page = 1;
do {
    $detail = $service->licenseDetail($client, $licenseId, $search, $page, 100);
    foreach ($detail['rows'] as $row) {
        fputcsv($output, array_map($safe, [
            $row['correo'], $row['funcionario'], $row['numero_documento'] ?? '',
            $row['cargo'] ?? '', $row['licencia'], $row['fabricante'] ?: 'Sin fabricante',
            number_format((float)$row['valor_usd'], 4, '.', ''),
            $row['cu3'] ?? '', $row['cliente'], $row['linea_negocio'] ?? '',
            $row['proyecto'] ?? '', $row['ciudad'] ?? '', $row['pais'],
        ]), ';');
    }
    $page++;
} while ($page <= (int)$detail['pages']);

fclose($output);
exit;
