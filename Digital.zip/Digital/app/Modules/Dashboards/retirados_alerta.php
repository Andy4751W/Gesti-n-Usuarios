<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';

/* La protección se aplica antes de procesar parámetros o consultar datos. */
if (!ad_is_authenticated() || ad_user_role() !== 'ADMIN') {
    ad_json_response(['ok' => false, 'message' => 'No autorizado.'], 403);
}

$result = (new UniclassEmploymentService(db()))->pendingValidationAccounts();
if (!$result['available'] || !empty($result['forbidden'])) {
    ad_json_response(['ok' => false, 'message' => 'No autorizado.'], 403);
}

$accounts = [];
foreach ($result['accounts'] as $account) {
    $accounts[] = [
        'motivo' => (string)($account['motivo'] ?? ''),
        'correo' => (string)($account['correo'] ?? ''),
        'nombre' => (string)($account['nombre'] ?? '—'),
        'numero_documento' => (string)($account['numero_documento'] ?? '—'),
        'licencias_detalle' => (string)($account['licencias_detalle'] ?? ''),
        'costo_mensual' => ad_money((float)($account['costo_total'] ?? 0), 'USD'),
        'cargo' => (string)($account['cargo'] ?? '—'),
        'estado_validacion' => (string)($account['estado_validacion'] ?? ''),
        'estado_uniclass' => (string)($account['estado_uniclass'] ?? '—'),
        'cliente' => (string)($account['cliente'] ?? '—'),
        'ultima_validacion' => (string)($account['ultima_validacion'] ?? ''),
    ];
}

ad_json_response(['ok' => true, 'accounts' => $accounts, 'sync' => $result['sync']]);
