<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('dashboards.clientes.ver');

$search = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 160, 'UTF-8');
$filename = 'licencias-pendientes-reasignacion-' . date('Ymd-His') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');

$output = fopen('php://output', 'wb');
fwrite($output, "\xEF\xBB\xBF");
fputcsv($output, [
    'Cuenta', 'Nombre', 'Documento', 'Cargo', 'Licencia', 'Valor mensual USD',
    'CU3', 'CU3-CLIENTE', 'Línea', 'Proyecto', 'Ciudad', 'País',
], ';');

$safe = static function ($value): string {
    $text = (string)$value;
    return preg_match('/^[=+\-@]/', $text) ? "'" . $text : $text;
};

$licenses = (new ClientDashboardService(db()))->pendingReassignmentLicenses($search);
foreach ($licenses as $license) {
    fputcsv($output, array_map($safe, [
        $license['correo'], $license['nombre'], $license['numero_documento'] ?? '',
        $license['cargo'] ?? '', $license['licencia'],
        number_format((float)$license['valor_usd'], 4, '.', ''),
        $license['cu3'] ?? '', 'N/A', $license['linea_negocio'] ?? '',
        $license['proyecto'] ?? '', $license['ciudad'] ?? '', $license['pais'],
    ]), ';');
}

fclose($output);
exit;
