<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('dashboards.clientes.ver');

$service = new ClientDashboardService(db());
$requestedClient = trim((string)($_GET['cliente'] ?? ''));
$isAdmin = ad_user_role() === 'ADMIN';
$isAllClients = mb_strtolower($requestedClient, 'UTF-8') === 'all';
if ($isAllClients && !$isAdmin) {
    ad_deny_access('dashboards.clientes.todos');
}
$selectedId = max(0, (int)$requestedClient);
$clients = $service->visibleClients();
$selectedClient = $isAllClients ? [
    'id' => 0,
    'codigo' => 'ALL',
    'nombre' => 'TODOS LOS CLIENTES',
    'aliases' => array_column($clients, 'nombre'),
] : null;
if (!$isAllClients && $selectedId > 0) {
  $selectedClient = $service->findVisibleClient($selectedId);
}
if (!$selectedClient && $clients) {
    $firstClientId = (int)$clients[0]['id'];
    if ($requestedClient !== '' && $selectedId !== $firstClientId) {
        ad_redirect('dashboards/informe.php?cliente=' . $firstClientId);
    }
    $selectedClient = $clients[0];
    $selectedId = (int)$selectedClient['id'];
}

$report = $selectedClient ? $service->licenseReport($selectedClient) : null;
$selectedClientValue = $isAllClients ? 'all' : (string)$selectedId;

$title = 'Informe de licencias por cliente';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<link rel="stylesheet" href="<?= ad_e(ad_url('assets/css/client-dashboards.css?v=6')) ?>">

<div class="client-dashboard">
  <div class="dashboard-hero mb-3">
    <div>
      <div class="dashboard-eyebrow">REPORTE EJECUTIVO</div>
      <h1>Informe de licencias por cliente</h1>
      <p>Cuentas con licencia, licencias asignadas y costo mensual registrado directamente en USD.</p>
    </div>
    <div class="dashboard-period-badge"><span>Fecha de corte</span><strong><?= ad_e($report['fecha_corte'] ? date('d/m/Y H:i', strtotime((string)$report['fecha_corte'])) : 'Sin lote activo') ?></strong></div>
  </div>

  <form class="card dashboard-filter mb-3" method="get">
    <div class="card-body row g-3 align-items-end">
      <div class="col-lg-9">
        <label class="form-label" for="reportClient">Cliente asignado</label>
        <select class="form-select" id="reportClient" name="cliente" required>
          <?php if ($isAdmin): ?><option value="all" <?= $isAllClients ? 'selected' : '' ?>>TODOS LOS CLIENTES</option><?php endif; ?>
          <?php foreach ($clients as $client): ?>
            <option value="<?= (int)$client['id'] ?>" <?= (int)$client['id'] === $selectedId ? 'selected' : '' ?>><?= ad_e($client['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-lg-3 d-grid"><button class="btn btn-primary">Generar informe</button></div>
    </div>
  </form>

  <?php if (!$clients): ?>
    <div class="alert alert-warning">No tiene clientes habilitados. Solicite al administrador que le asigne al menos uno.</div>
  <?php elseif ($report && $selectedClient): ?>
    <div class="kpi-grid report-kpis report-kpis-compact mb-3">
      <article class="metric-card metric-purple"><span class="metric-icon">◆</span><div><span>Cuentas con licencia</span><strong><?= number_format((int)$report['cuentas_licenciadas'], 0, ',', '.') ?></strong><small>Cuentas que tienen al menos una licencia</small></div></article>
      <article class="metric-card metric-teal"><span class="metric-icon">✓</span><div><span>Licencias asignadas</span><strong><?= number_format((int)$report['licencias_asignadas'], 0, ',', '.') ?></strong><small>Licencias activas facturadas en USD</small></div></article>
      <article class="metric-card metric-green"><span class="metric-icon">$</span><div><span>Costo mensual</span><strong><?= ad_e(ad_money((float)$report['costo_mensual'], 'USD')) ?></strong><small>Valor directo en dólares</small></div></article>
    </div>

    <section class="report-control-grid mb-3" aria-label="Controles de licenciamiento">
      <article class="report-control-card report-control-multiple">
        <div><span class="report-control-label">CUENTAS CON VARIAS LICENCIAS</span><strong><?= number_format(count($report['cuentas_multiples']), 0, ',', '.') ?></strong><h2>Cuentas con varias licencias</h2><p>Cuentas que tienen dos o más licencias activas asignadas.</p></div>
        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#multipleLicenseAccounts" aria-expanded="false" <?= !$report['cuentas_multiples'] ? 'disabled' : '' ?>>Ver cuentas</button>
      </article>
      <?php if ($isAdmin): ?>
        <article class="report-control-card report-control-pending">
          <div>
            <span class="report-control-label">ALERTA EXCLUSIVA PARA ADMIN</span>
            <strong id="retiredLicensedCount" aria-live="polite">—</strong>
            <h2>Licencias pendientes de validación</h2>
            <p id="retiredLicensedStatus" aria-live="polite">Consultando estado laboral en UNICLASS…</p>
          </div>
          <button class="btn btn-sm btn-outline-danger" id="retiredLicensedButton" type="button" data-bs-toggle="collapse" data-bs-target="#retiredLicensedAccounts" aria-expanded="false" disabled>Ver pendientes</button>
        </article>
      <?php endif; ?>
    </section>

    <?php if ($isAdmin): ?>
      <div class="alert alert-warning mb-3" id="retiredLicensedUnavailable" role="alert" hidden>No fue posible consultar UNICLASS. El informe principal continúa disponible.</div>
      <div class="collapse" id="retiredLicensedAccounts">
        <section class="card report-retired-detail mb-3">
          <div class="card-header"><h2 class="h6 mb-1">Licencias pendientes de validación</h2><div class="small">Cuentas con licencia activa que requieren validación frente a UNICLASS.</div></div>
          <div class="report-table-scroll">
            <table class="table table-sm table-hover align-middle mb-0 report-retired-table">
              <thead><tr><th>Motivo pendiente</th><th>Cuenta</th><th>Documento</th><th>Nombre</th><th>Cargo</th><th>Licencias</th><th>VALOR MENSUAL</th><th>CLIENTE</th><th>Última validación</th></tr></thead>
              <tbody id="retiredLicensedRows"><tr><td colspan="9" class="text-center text-muted py-4">Consultando estado laboral…</td></tr></tbody>
            </table>
          </div>
        </section>
      </div>
    <?php endif; ?>

    <div class="collapse" id="multipleLicenseAccounts">
      <section class="card mb-3">
        <div class="card-header bg-white"><h2 class="h6 mb-1">Cuentas con varias licencias</h2><div class="small text-muted">Cada fila consolida todas las asignaciones activas asociadas al mismo correo.</div></div>
        <div class="table-responsive">
          <table class="table table-sm table-hover align-middle mb-0 report-control-table" style="min-width:900px">
            <thead><tr><th>Cuenta</th><th>Nombre</th><th>Cliente</th><th class="text-center">Cantidad de licencias</th><th>Licencias asignadas</th><th>Costo mensual total</th></tr></thead>
            <tbody><?php foreach ($report['cuentas_multiples'] as $account): ?><tr><td><strong><?= ad_e($account['correo']) ?></strong></td><td><?= ad_e($account['nombre']) ?></td><td><?= ad_e($account['cliente'] ?: '—') ?></td><td class="text-center fw-semibold"><?= (int)$account['cantidad_licencias'] ?></td><td><?= ad_e($account['licencias_detalle']) ?></td><td class="text-nowrap fw-semibold"><?= ad_e(ad_money((float)$account['costo_total'], 'USD')) ?></td></tr><?php endforeach; ?></tbody>
          </table>
        </div>
      </section>
    </div>

    <section class="card mb-4" aria-labelledby="licenseDistributionTitle">
      <div class="card-header bg-white">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
          <div><h2 class="h5 mb-1" id="licenseDistributionTitle">Distribución por tipo de licencia</h2><div class="text-muted small">Resumen de cuentas, licencias y costo mensual. Use “Ver usuarios” para consultar quién tiene cada licencia.</div></div>
          <div class="d-flex align-items-center gap-2"><span class="badge text-bg-primary"><?= number_format((int)$report['licencias_asignadas'], 0, ',', '.') ?> licencias</span><a class="btn btn-sm btn-outline-success" href="<?= ad_e(ad_url('dashboards/informe_exportar.php?' . http_build_query(['cliente'=>$selectedClientValue]))) ?>">Descargar CSV</a></div>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0 report-license-table" style="min-width:900px">
          <thead><tr><th>Licencia</th><th class="text-center">Cuentas</th><th class="text-center">Licencias</th><th>Valor por licencia</th><th>Costo mensual</th><th class="text-end">Detalle</th></tr></thead>
          <tbody>
            <?php foreach ($report['grupos'] as $index => $group):
              $samePrice = abs((float)$group['valor_minimo'] - (float)$group['valor_maximo']) < 0.0001;
            ?>
              <tr>
                <td><strong><?= ad_e($group['licencia']) ?></strong><div class="small text-muted"><?= ad_e($group['fabricante'] ?: 'Sin fabricante') ?></div></td>
                <td class="text-center"><?= number_format((int)$group['cuentas_licenciadas'], 0, ',', '.') ?></td>
                <td class="text-center"><?= number_format((int)$group['licencias'], 0, ',', '.') ?></td>
                <td class="text-nowrap"><?= $samePrice ? ad_e(ad_money((float)$group['valor_minimo'], 'USD')) : ad_e(ad_money((float)$group['valor_minimo'], 'USD') . ' – ' . ad_money((float)$group['valor_maximo'], 'USD')) ?></td>
                <td class="text-nowrap fw-semibold"><?= ad_e(ad_money((float)$group['costo_total'], 'USD')) ?></td>
                <td class="text-end"><button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#licenseUsers<?= $index ?>" aria-expanded="false">Ver usuarios</button></td>
              </tr>
              <tr class="collapse report-users-row" id="licenseUsers<?= $index ?>">
                <td colspan="6" class="p-0">
                  <div class="p-2 bg-light">
                    <div class="report-table-scroll report-detail-scroll" tabindex="0" aria-label="Detalle de usuarios con desplazamiento horizontal">
                      <table class="table table-sm table-bordered bg-white mb-0 report-detail-table">
                        <thead><tr><th>Cuenta</th><th>Nombre</th><th>Documento</th><th>Cargo</th><th>Valor mensual</th><th>CU3</th><th>Cliente</th><th>Línea</th><th>Proyecto</th><th>Ciudad</th><th>País</th></tr></thead>
                        <tbody>
                          <?php foreach ($group['usuarios'] as $row): ?>
                            <tr>
                              <td><strong><?= ad_e($row['correo']) ?></strong></td>
                              <td><?= ad_e($row['nombre']) ?></td>
                              <td><?= ad_e($row['numero_documento'] ?: '—') ?></td>
                              <td><?= ad_e($row['cargo'] ?: '—') ?></td>
                              <td class="text-nowrap fw-semibold"><?= ad_e(ad_money((float)$row['valor_usd'], 'USD')) ?></td>
                              <td><?= ad_e($row['cu3'] ?: '—') ?></td>
                              <td><?= ad_e($row['cliente'] ?: '—') ?></td>
                              <td><?= ad_e($row['linea_negocio'] ?: '—') ?></td>
                              <td><?= ad_e($row['proyecto'] ?: '—') ?></td>
                              <td><?= ad_e($row['ciudad'] ?: '—') ?></td>
                              <td><?= ad_e($row['pais'] ?: '—') ?></td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$report['grupos']): ?><tr><td colspan="6" class="text-center text-muted py-4">El cliente no tiene registros en la última importación de BASE_PPAL.</td></tr><?php endif; ?>
          </tbody>
          <?php if ($report['grupos']): ?><tfoot><tr><th>Total</th><th class="text-center"><?= number_format((int)$report['cuentas_licenciadas'], 0, ',', '.') ?></th><th class="text-center"><?= number_format((int)$report['licencias_asignadas'], 0, ',', '.') ?></th><th></th><th><?= ad_e(ad_money((float)$report['costo_mensual'], 'USD')) ?></th><th></th></tr></tfoot><?php endif; ?>
        </table>
      </div>
      <div class="report-fixed-scroll" id="reportFixedScroll" hidden aria-label="Desplazamiento horizontal de la tabla"><div></div></div>
    </section>

    <div class="dashboard-note mb-4"><strong>Origen:</strong> última importación exitosa de la hoja <strong>BASE_PPAL</strong>. El cliente se toma exclusivamente de <strong>CU3-CLIENTE</strong> y el precio de <strong>PRECIO USD</strong>.</div>
  <?php endif; ?>
</div>
<script>
(function () {
  var fixedScroll = document.getElementById('reportFixedScroll');
  var tableScrolls = document.querySelectorAll('.report-table-scroll');
  if (!fixedScroll || !fixedScroll.firstElementChild || !tableScrolls.length) return;
  var spacer = fixedScroll.firstElementChild;
  var activeScroll = null;
  var syncing = false;

  function refreshFixedScroll() {
    if (!activeScroll) {
      fixedScroll.hidden = true;
      return;
    }
    var rect = activeScroll.getBoundingClientRect();
    var left = Math.max(0, rect.left);
    var right = Math.min(window.innerWidth, rect.right);
    spacer.style.width = activeScroll.scrollWidth + 'px';
    fixedScroll.style.left = left + 'px';
    fixedScroll.style.width = Math.max(0, right - left) + 'px';
    fixedScroll.hidden = activeScroll.scrollWidth <= activeScroll.clientWidth + 1;
  }

  Array.prototype.forEach.call(tableScrolls, function (tableScroll) {
    tableScroll.addEventListener('scroll', function () {
      if (syncing || activeScroll !== tableScroll) return;
      syncing = true;
      fixedScroll.scrollLeft = tableScroll.scrollLeft;
      syncing = false;
    });
  });
  fixedScroll.addEventListener('scroll', function () {
    if (syncing || !activeScroll) return;
    syncing = true;
    activeScroll.scrollLeft = fixedScroll.scrollLeft;
    syncing = false;
  });
  document.addEventListener('shown.bs.collapse', function (event) {
    var tableScroll = event.target.querySelector('.report-table-scroll');
    if (!tableScroll) return;
    activeScroll = tableScroll;
    tableScroll.scrollLeft = 0;
    fixedScroll.scrollLeft = 0;
    refreshFixedScroll();
  });
  document.addEventListener('hidden.bs.collapse', function (event) {
    if (activeScroll && event.target.contains(activeScroll)) {
      activeScroll = null;
      refreshFixedScroll();
    }
  });
  window.addEventListener('resize', refreshFixedScroll);
  window.addEventListener('scroll', refreshFixedScroll, {passive: true});
  if (window.ResizeObserver) {
    Array.prototype.forEach.call(tableScrolls, function (tableScroll) {
      new ResizeObserver(refreshFixedScroll).observe(tableScroll);
    });
  }
}());
</script>
<script>
(function () {
  var search = document.getElementById('pendingReassignmentSearch');
  var rows = document.querySelectorAll('#pendingReassignmentRows tr[data-pending-search]');
  var csv = document.getElementById('pendingReassignmentCsv');
  if (!search || !csv) return;
  var csvUrl = <?= json_encode(ad_url('dashboards/pendientes_reasignacion_exportar.php'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

  function filterRows() {
    var value = search.value.toLocaleLowerCase();
    Array.prototype.forEach.call(rows, function (row) {
      row.hidden = value !== '' && row.getAttribute('data-pending-search').indexOf(value) === -1;
    });
    csv.href = csvUrl + (value ? '?q=' + encodeURIComponent(search.value) : '');
  }

  search.addEventListener('input', filterRows);
}());
</script>
<?php if ($isAdmin && $selectedClient): ?>
<script>
(function () {
  var count = document.getElementById('retiredLicensedCount');
  var status = document.getElementById('retiredLicensedStatus');
  var button = document.getElementById('retiredLicensedButton');
  var rows = document.getElementById('retiredLicensedRows');
  var unavailable = document.getElementById('retiredLicensedUnavailable');
  if (!count || !status || !button || !rows || !unavailable || !window.fetch) return;

  var controller = window.AbortController ? new AbortController() : null;
  var timeout = window.setTimeout(function () {
    if (controller) controller.abort();
    else setUnavailable();
  }, 5000);
  var url = <?= json_encode(ad_url('dashboards/retirados_alerta.php?cliente=' . rawurlencode($selectedClientValue)), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

  function setUnavailable() {
    window.clearTimeout(timeout);
    count.textContent = '—';
    status.textContent = 'No fue posible consultar UNICLASS. El informe principal continúa disponible.';
    button.disabled = true;
    rows.textContent = '';
  }

  function addCell(row, value, className) {
    var cell = document.createElement('td');
    if (className) cell.className = className;
    cell.textContent = value || '—';
    row.appendChild(cell);
  }

  fetch(url, {credentials: 'same-origin', signal: controller ? controller.signal : undefined, headers: {'Accept': 'application/json'}})
    .then(function (response) {
      if (!response.ok) throw new Error('UNICLASS no disponible');
      return response.json();
    })
    .then(function (payload) {
      window.clearTimeout(timeout);
      if (!payload || !payload.ok || !Array.isArray(payload.accounts)) throw new Error('Respuesta no válida');
      var accounts = payload.accounts;
      var sync = payload.sync || {};
      var completedLabel = sync.ultima_completada_at ? ' Última sincronización completada: ' + sync.ultima_completada_at + '.' : '';
      count.textContent = String(accounts.length);
      if (sync.estado === 'NUNCA_SINCRONIZADA') {
        status.textContent = 'Pendiente de sincronización con UNICLASS' + completedLabel;
      } else if (sync.estado === 'FALLIDA') {
        status.textContent = 'La última sincronización UNICLASS falló. Se muestran los datos locales disponibles.' + completedLabel;
        unavailable.hidden = false;
      } else {
        status.textContent = (accounts.length
        ? 'Cuentas con licencia activa que requieren validación frente a UNICLASS.'
        : 'No hay cuentas con licencia activa pendientes de validación.')
          + completedLabel;
      }
      rows.textContent = '';
      if (!accounts.length) {
        var empty = document.createElement('tr');
        var cell = document.createElement('td');
        cell.colSpan = 9;
        cell.className = 'text-center text-success py-4';
        cell.textContent = 'No hay cuentas con licencia activa pendientes de validación.';
        empty.appendChild(cell);
        rows.appendChild(empty);
        return;
      }
      button.disabled = sync.estado === 'NUNCA_SINCRONIZADA';
      accounts.forEach(function (account) {
        var row = document.createElement('tr');
        addCell(row, account.motivo);
        addCell(row, account.correo, 'fw-semibold');
        addCell(row, account.numero_documento);
        addCell(row, account.nombre);
        addCell(row, account.cargo);
        addCell(row, account.licencias_detalle);
        addCell(row, account.costo_mensual, 'text-nowrap fw-semibold');
        addCell(row, account.cliente);
        addCell(row, account.ultima_validacion);
        rows.appendChild(row);
      });
    })
    .catch(setUnavailable);
}());
</script>
<?php endif; ?>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
