<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
ad_verify_csrf();

$invoiceId = (int)($_POST['factura_id'] ?? 0);
try {
    if ($invoiceId <= 0) {
        throw new RuntimeException('La factura seleccionada no es válida.');
    }
    $importId = (new InvoiceDistributionService(db()))->generateFromDatabase(
        $invoiceId,
        ad_current_user_id()
    );
    ad_flash('success', 'La distribución fue calculada con los datos registrados en el software.');
    ad_redirect('facturas/distribucion_ver.php?id=' . $importId);
} catch (Throwable $e) {
    ad_flash('danger', 'No fue posible generar la distribución: ' . $e->getMessage());
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}
