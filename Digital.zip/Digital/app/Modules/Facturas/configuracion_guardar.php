<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
ad_verify_csrf();
$pdo = db();
$type = (string)($_POST['tipo'] ?? '');
$allowed = ['licencias', 'perfiles', 'cu1', 'cu3', 'almacenes', 'integrales'];
if (!in_array($type, $allowed, true)) {
    ad_flash('danger', 'El tipo de configuración no es válido.');
    ad_redirect('facturas/configuracion.php');
}
$idOriginal = trim((string)($_POST['id_original'] ?? ''));
$textValue = static function (string $key): ?string {
    $value = trim((string)($_POST[$key] ?? ''));
    return $value === '' ? null : $value;
};
$codeValue = static function (string $key) use ($textValue): string {
    $value = $textValue($key) ?? '';
    return preg_replace('/\s+/u', '', mb_strtoupper($value, 'UTF-8')) ?: '';
};

$pdo->beginTransaction();
try {
    $userId = ad_current_user_id();
    if ($type === 'licencias') {
        $subscriptionId = (int)$idOriginal;
        $priceText = trim((string)($_POST['valor_unitario'] ?? ''));
        if ($subscriptionId <= 0 || $priceText === '' || !is_numeric($priceText) || (float)$priceText < 0) {
            throw new RuntimeException('Indique un precio válido en USD para la licencia.');
        }
        $price = round((float)$priceText, 4);
        $exists = $pdo->prepare('SELECT id FROM ad_suscripciones WHERE id=:id FOR UPDATE');
        $exists->execute([':id'=>$subscriptionId]);
        if ($exists->fetchColumn() === false) {
            throw new RuntimeException('La suscripción seleccionada no existe.');
        }
        $updateSubscription = $pdo->prepare(
            'UPDATE ad_suscripciones SET valor_unitario=:valor,moneda="USD" WHERE id=:id'
        );
        $updateSubscription->execute([':valor'=>$price, ':id'=>$subscriptionId]);

        $updateAssignments = $pdo->prepare(
            'UPDATE ad_asignaciones_licencia
             SET valor_unitario_asignado=:valor,moneda="USD"
             WHERE suscripcion_id=:id AND estado="ACTIVA"'
        );
        $updateAssignments->execute([':valor'=>$price, ':id'=>$subscriptionId]);

        $pdo->exec(
            'UPDATE ad_perfiles_distribucion_cuenta pd
             INNER JOIN (
                SELECT cuenta_id,SUM(valor_unitario_asignado) costo_total
                FROM ad_asignaciones_licencia WHERE estado="ACTIVA" GROUP BY cuenta_id
                HAVING SUM(CASE WHEN moneda<>"USD" THEN 1 ELSE 0 END)=0
             ) costos ON costos.cuenta_id=pd.cuenta_id
             SET pd.costo_mensual=costos.costo_total,pd.moneda="USD"
             WHERE pd.fuente="MOVIMIENTO"'
        );
        $entityId = $subscriptionId;
    } elseif ($type === 'perfiles') {
        $accountId = (int)($_POST['cuenta_id'] ?? 0);
        if ($accountId <= 0 || $codeValue('cu1') === '' || $codeValue('cu3') === '') {
            throw new RuntimeException('Debe seleccionar la cuenta e indicar CU1 y CU3.');
        }
        $account = $pdo->prepare('SELECT id FROM ad_cuentas WHERE id=:id');
        $account->execute([':id' => $accountId]);
        if ($account->fetchColumn() === false) {
            throw new RuntimeException('La cuenta seleccionada no existe.');
        }
        $costText = trim((string)($_POST['costo_mensual'] ?? ''));
        $cost = $costText === '' ? null : round((float)$costText, 4);
        $currency = 'USD';
        $statement = $pdo->prepare(
            'INSERT INTO ad_perfiles_distribucion_cuenta
             (cuenta_id,plan_fuente,costo_mensual,moneda,cu1,proceso_cu1,regional,ciudad,
              cu3,cliente,linea_negocio,proyecto,grupo,empresa,proceso_general,tipo_proyecto,
              observaciones,fuente,updated_by)
             VALUES (:cuenta,:plan,:costo,:moneda,:cu1,:proceso,:regional,:ciudad,
              :cu3,:cliente,:linea,:proyecto,:grupo,:empresa,:proceso_general,:tipo_proyecto,
              :observaciones,"MANUAL",:usuario)
             ON DUPLICATE KEY UPDATE plan_fuente=VALUES(plan_fuente), costo_mensual=VALUES(costo_mensual),
              moneda=VALUES(moneda), cu1=VALUES(cu1), proceso_cu1=VALUES(proceso_cu1),
              regional=VALUES(regional), ciudad=VALUES(ciudad), cu3=VALUES(cu3),
              cliente=VALUES(cliente), linea_negocio=VALUES(linea_negocio), proyecto=VALUES(proyecto),
              grupo=VALUES(grupo), empresa=VALUES(empresa), proceso_general=VALUES(proceso_general),
              tipo_proyecto=VALUES(tipo_proyecto), observaciones=VALUES(observaciones),
              fuente="MANUAL", updated_by=VALUES(updated_by)'
        );
        $statement->execute([
            ':cuenta'=>$accountId, ':plan'=>$textValue('plan_fuente'), ':costo'=>$cost,
            ':moneda'=>$currency, ':cu1'=>$codeValue('cu1'), ':proceso'=>$textValue('proceso_cu1'),
            ':regional'=>$textValue('regional'), ':ciudad'=>$textValue('ciudad'),
            ':cu3'=>$codeValue('cu3'), ':cliente'=>$textValue('cliente'),
            ':linea'=>$textValue('linea_negocio'), ':proyecto'=>$textValue('proyecto'),
            ':grupo'=>$textValue('grupo'), ':empresa'=>$textValue('empresa'),
            ':proceso_general'=>$textValue('proceso_general'), ':tipo_proyecto'=>$textValue('tipo_proyecto'),
            ':observaciones'=>$textValue('observaciones'), ':usuario'=>$userId,
        ]);
        $entityId = $accountId;
    } elseif ($type === 'cu1') {
        $code = $codeValue('codigo');
        if ($code === '') { throw new RuntimeException('Debe indicar el código CU1.'); }
        $statement = $pdo->prepare(
            'INSERT INTO ad_cu1_catalogo (codigo,descripcion_corta,descripcion,proceso,regional,ciudad,activo,fuente,updated_by)
             VALUES (:codigo,:corta,:descripcion,:proceso,:regional,:ciudad,:activo,"MANUAL",:usuario)
             ON DUPLICATE KEY UPDATE descripcion_corta=VALUES(descripcion_corta),descripcion=VALUES(descripcion),
              proceso=VALUES(proceso),regional=VALUES(regional),ciudad=VALUES(ciudad),activo=VALUES(activo),
              fuente="MANUAL",updated_by=VALUES(updated_by)'
        );
        $statement->execute([':codigo'=>$code,':corta'=>$textValue('descripcion_corta'),':descripcion'=>$textValue('descripcion'),':proceso'=>$textValue('proceso'),':regional'=>$textValue('regional'),':ciudad'=>$textValue('ciudad'),':activo'=>isset($_POST['activo'])?1:0,':usuario'=>$userId]);
        $entityId = 0;
    } elseif ($type === 'cu3') {
        $code = $codeValue('codigo');
        if ($code === '') { throw new RuntimeException('Debe indicar el código CU3.'); }
        $statement = $pdo->prepare(
            'INSERT INTO ad_cu3_catalogo (codigo,descripcion_corta,descripcion,cliente,linea_negocio,proyecto,linea_temp,activo,fuente,updated_by)
             VALUES (:codigo,:corta,:descripcion,:cliente,:linea,:proyecto,:linea_temp,:activo,"MANUAL",:usuario)
             ON DUPLICATE KEY UPDATE descripcion_corta=VALUES(descripcion_corta),descripcion=VALUES(descripcion),
              cliente=VALUES(cliente),linea_negocio=VALUES(linea_negocio),proyecto=VALUES(proyecto),
              linea_temp=VALUES(linea_temp),activo=VALUES(activo),fuente="MANUAL",updated_by=VALUES(updated_by)'
        );
        $statement->execute([':codigo'=>$code,':corta'=>$textValue('descripcion_corta'),':descripcion'=>$textValue('descripcion'),':cliente'=>$textValue('cliente'),':linea'=>$textValue('linea_negocio'),':proyecto'=>$textValue('proyecto'),':linea_temp'=>$textValue('linea_temp'),':activo'=>isset($_POST['activo'])?1:0,':usuario'=>$userId]);
        $entityId = 0;
    } elseif ($type === 'almacenes') {
        $cu1 = $codeValue('cu1'); $cu3 = $codeValue('cu3'); $warehouse = $codeValue('codigo_almacen');
        if ($cu1 === '' || $cu3 === '' || $warehouse === '') { throw new RuntimeException('Debe indicar CU1, CU3 y código de almacén.'); }
        $parameters = [':clave'=>$cu1.$cu3,':cu1'=>$cu1,':cu3'=>$cu3,':codigo'=>$warehouse,':descripcion'=>$textValue('descripcion'),':cliente'=>$textValue('cliente'),':activo'=>isset($_POST['activo'])?1:0,':usuario'=>$userId];
        if ($idOriginal === '') {
            $statement = $pdo->prepare('INSERT INTO ad_almacenes_distribucion (clave,cu1,cu3,codigo_almacen,descripcion,cliente,activo,fuente,updated_by) VALUES (:clave,:cu1,:cu3,:codigo,:descripcion,:cliente,:activo,"MANUAL",:usuario)');
        } else {
            $statement = $pdo->prepare('UPDATE ad_almacenes_distribucion SET clave=:clave,cu1=:cu1,cu3=:cu3,codigo_almacen=:codigo,descripcion=:descripcion,cliente=:cliente,activo=:activo,fuente="MANUAL",updated_by=:usuario WHERE id=:id');
            $parameters[':id'] = (int)$idOriginal;
        }
        $statement->execute($parameters);
        $entityId = $idOriginal === '' ? (int)$pdo->lastInsertId() : (int)$idOriginal;
    } else {
        $client=$textValue('cliente'); $line=$textValue('linea_negocio'); $city=$textValue('ciudad'); $project=$textValue('proyecto'); $income=round((float)($_POST['ingresos']??0),2);
        if ($client===null||$line===null||$city===null||$project===null||$income<=0) { throw new RuntimeException('Complete cliente, línea, ciudad, proyecto e ingresos.'); }
        $key=hash('sha256',ad_normalize_text($client.'|'.$line.'|'.$city.'|'.$project));
        $parameters=[':clave'=>$key,':cliente'=>$client,':linea'=>$line,':ciudad'=>$city,':proyecto'=>$project,':ingresos'=>$income,':activo'=>isset($_POST['activo'])?1:0,':usuario'=>$userId];
        if ($idOriginal==='') {
            $statement=$pdo->prepare('INSERT INTO ad_reglas_integrales (clave,cliente,linea_negocio,ciudad,proyecto,ingresos,moneda,porcentaje,activo,fuente,updated_by) VALUES (:clave,:cliente,:linea,:ciudad,:proyecto,:ingresos,"USD",0,:activo,"MANUAL",:usuario)');
        } else {
            $statement=$pdo->prepare('UPDATE ad_reglas_integrales SET clave=:clave,cliente=:cliente,linea_negocio=:linea,ciudad=:ciudad,proyecto=:proyecto,ingresos=:ingresos,moneda="USD",activo=:activo,fuente="MANUAL",updated_by=:usuario WHERE id=:id');
            $parameters[':id']=(int)$idOriginal;
        }
        $statement->execute($parameters);
        $entityId=$idOriginal===''?(int)$pdo->lastInsertId():(int)$idOriginal;
        $total=(float)$pdo->query('SELECT SUM(ingresos) FROM ad_reglas_integrales WHERE activo=1')->fetchColumn();
        if ($total>0) {
            $recalculate=$pdo->prepare('UPDATE ad_reglas_integrales SET porcentaje=CASE WHEN activo=1 THEN ingresos/:total ELSE 0 END');
            $recalculate->execute([':total'=>$total]);
        }
    }
    $auditData = $_POST;
    unset($auditData['_token']);
    AuditService::log(
        $pdo,
        'configuracion_distribucion_' . $type,
        (int)$entityId,
        'GUARDAR',
        null,
        $auditData
    );
    $pdo->commit();
    ad_flash('success', 'La configuración fue guardada correctamente.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    ad_flash('danger', 'No fue posible guardar la configuración: '.$e->getMessage());
}
ad_redirect('facturas/configuracion.php?tipo='.$type);
