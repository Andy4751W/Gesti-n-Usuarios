<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$invoiceId = (int)($_GET['id'] ?? 0);

$invoiceStatement = $pdo->prepare(
    'SELECT f.*, p.razon_social proveedor
     FROM ad_facturas f
     INNER JOIN ad_proveedores p ON p.id=f.proveedor_id
     WHERE f.id=:id'
);
$invoiceStatement->execute([':id' => $invoiceId]);
$invoice = $invoiceStatement->fetch(PDO::FETCH_ASSOC);
if (!$invoice) {
    http_response_code(404);
    exit('Factura no encontrada.');
}

$importsStatement = $pdo->prepare(
    'SELECT * FROM ad_importaciones_distribucion
     WHERE factura_id=:factura ORDER BY id DESC'
);
$importsStatement->execute([':factura' => $invoiceId]);
$imports = $importsStatement->fetchAll(PDO::FETCH_ASSOC);

$title = 'Distribución de factura';
require dirname(__DIR__, 2) . '/Views/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h1 class="h3 mb-1">Distribución de costos</h1>
        <div class="text-muted">
            Factura <?= ad_e($invoice['numero_factura']) ?> · <?= ad_e($invoice['proveedor']) ?>
        </div>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-outline-primary" href="<?= ad_e(ad_url('facturas/configuracion.php')) ?>">Configurar datos maestros</a>
        <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/show.php?id=' . $invoiceId)) ?>">Volver a la factura</a>
    </div>
</div>

<div class="row g-3">
    <div class="col-xl-6">
        <div class="card card-kpi h-100">
            <div class="card-header fw-semibold">Generar desde el software</div>
            <div class="card-body d-flex flex-column">
                <p class="text-muted">Usa las licencias activas, tarifas, perfiles CU1/CU3, almacenes y reglas integrales guardadas en la base de datos.</p>
                <form class="mt-auto" method="post" action="<?= ad_e(ad_url('facturas/distribucion_generar.php')) ?>">
                    <input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>">
                    <input type="hidden" name="factura_id" value="<?= $invoiceId ?>">
                    <button class="btn btn-success">Calcular distribución</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card card-kpi h-100">
            <div class="card-header fw-semibold">Sincronización inicial o actualización masiva</div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data" action="<?= ad_e(ad_url('facturas/distribucion_importar.php')) ?>">
                    <input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>">
                    <input type="hidden" name="factura_id" value="<?= $invoiceId ?>">
                    <label class="form-label" for="distributionFile">Archivo de distribución en Excel</label>
                    <input class="form-control" type="file" id="distributionFile" name="archivo_xlsx" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
                    <div class="form-text">
                        Debe incluir las hojas <strong>BASE ADMIN</strong> y <strong>SHAREPOINT</strong>. Para completar los cruces se recomiendan también <strong>CUs</strong>, <strong>CONCATEN ALMACENES</strong> e <strong>INTEGRALES R3</strong>.
                    </div>
                    <button class="btn btn-primary mt-3">Sincronizar Excel y distribuir</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card card-kpi h-100">
            <div class="card-header fw-semibold">Control de la factura</div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2"><span>Subtotal factura</span><strong><?= ad_e(ad_money($invoice['subtotal'], $invoice['moneda'])) ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>Periodo</span><strong><?= ad_e(($invoice['periodo_desde'] ?: '—') . ' a ' . ($invoice['periodo_hasta'] ?: '—')) ?></strong></div>
                <div class="d-flex justify-content-between"><span>Estado</span><span class="badge text-bg-secondary"><?= ad_e($invoice['estado']) ?></span></div>
            </div>
        </div>
    </div>
</div>

<div class="card card-kpi mt-3">
    <div class="card-header fw-semibold">Importaciones realizadas</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0 selectable-table">
            <thead><tr><th>Fecha</th><th>Archivo</th><th>Usuarios</th><th>Pendientes</th><th>Total archivo</th><th>Diferencia</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            <?php if (!$imports): ?>
                <tr><td colspan="8" class="p-4 text-muted">Todavía no hay distribuciones para esta factura.</td></tr>
            <?php endif; ?>
            <?php foreach ($imports as $import): ?>
                <?php $viewUrl = ad_url('facturas/distribucion_ver.php?id=' . (int)$import['id']); ?>
                <tr data-href="<?= ad_e($viewUrl) ?>" tabindex="0" role="link">
                    <td><?= ad_e($import['created_at']) ?></td>
                    <td><strong><?= ad_e($import['archivo_nombre']) ?></strong></td>
                    <td><?= number_format((int)$import['usuarios_fuente'], 0, ',', '.') ?></td>
                    <td><?= number_format((int)$import['usuarios_pendientes'], 0, ',', '.') ?></td>
                    <td><?= ad_e(ad_money($import['total_fuente'], $invoice['moneda'])) ?></td>
                    <td><?= ad_e(ad_money($import['diferencia_factura'], $invoice['moneda'])) ?></td>
                    <td><span class="badge text-bg-<?= $import['estado'] === 'COMPLETADA' ? 'success' : 'warning' ?>"><?= ad_e($import['estado']) ?></span></td>
                    <td class="row-arrow" aria-hidden="true">›</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.selectable-table tr[data-href]').forEach(function (row) {
        const openRow = function () { window.location.href = row.getAttribute('data-href'); };
        row.addEventListener('click', openRow);
        row.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openRow();
            }
        });
    });
});
</script>

<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
