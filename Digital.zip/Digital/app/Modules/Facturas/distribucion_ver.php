<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$importId = (int)($_GET['id'] ?? 0);

$statement = $pdo->prepare(
    'SELECT i.*, f.numero_factura, f.moneda, f.subtotal, f.id factura_id,
            p.razon_social proveedor
     FROM ad_importaciones_distribucion i
     INNER JOIN ad_facturas f ON f.id=i.factura_id
     INNER JOIN ad_proveedores p ON p.id=f.proveedor_id
     WHERE i.id=:id'
);
$statement->execute([':id' => $importId]);
$import = $statement->fetch(PDO::FETCH_ASSOC);
if (!$import) {
    http_response_code(404);
    exit('Distribución no encontrada.');
}

$query = trim((string)($_GET['q'] ?? ''));
$status = trim((string)($_GET['estado'] ?? ''));
$allowedStatuses = ['OK', 'SIN_CUENTA', 'PENDIENTE_CU1', 'PENDIENTE_CU3', 'SIN_ALMACEN', 'DUPLICADO'];
if (!in_array($status, $allowedStatuses, true)) {
    $status = '';
}
$page = max(1, (int)($_GET['pagina'] ?? 1));
$pageSize = 50;
$where = ['d.importacion_id=:importacion'];
$parameters = [':importacion' => $importId];
if ($query !== '') {
    $where[] = '(d.correo LIKE :busqueda_correo OR d.plan_normalizado LIKE :busqueda_plan
                 OR d.cu1 LIKE :busqueda_cu1 OR d.cu3 LIKE :busqueda_cu3
                 OR d.cliente LIKE :busqueda_cliente OR d.almacen LIKE :busqueda_almacen)';
    $searchValue = '%' . $query . '%';
    $parameters[':busqueda_correo'] = $searchValue;
    $parameters[':busqueda_plan'] = $searchValue;
    $parameters[':busqueda_cu1'] = $searchValue;
    $parameters[':busqueda_cu3'] = $searchValue;
    $parameters[':busqueda_cliente'] = $searchValue;
    $parameters[':busqueda_almacen'] = $searchValue;
}
if ($status !== '') {
    $where[] = 'd.estado=:estado';
    $parameters[':estado'] = $status;
}
$whereSql = implode(' AND ', $where);

$count = $pdo->prepare('SELECT COUNT(*) FROM ad_distribuciones_usuario_factura d WHERE ' . $whereSql);
$count->execute($parameters);
$totalRows = (int)$count->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $pageSize));
$page = min($page, $totalPages);

$rowsStatement = $pdo->prepare(
    'SELECT d.* FROM ad_distribuciones_usuario_factura d
     WHERE ' . $whereSql . '
     ORDER BY CASE WHEN d.estado="OK" THEN 1 ELSE 0 END, d.correo, d.fila_origen, d.id
     LIMIT :limite OFFSET :desplazamiento'
);
foreach ($parameters as $key => $value) {
    $rowsStatement->bindValue($key, $value, PDO::PARAM_STR);
}
$rowsStatement->bindValue(':limite', $pageSize, PDO::PARAM_INT);
$rowsStatement->bindValue(':desplazamiento', ($page - 1) * $pageSize, PDO::PARAM_INT);
$rowsStatement->execute();
$rows = $rowsStatement->fetchAll(PDO::FETCH_ASSOC);

$summaryStatement = $pdo->prepare(
    'SELECT plan_normalizado plan, COUNT(DISTINCT correo) usuarios,
            SUM(valor_distribuido) total
     FROM ad_distribuciones_usuario_factura
     WHERE importacion_id=:id
     GROUP BY plan_normalizado ORDER BY total DESC'
);
$summaryStatement->execute([':id' => $importId]);
$planSummary = $summaryStatement->fetchAll(PDO::FETCH_ASSOC);

$statusLabels = [
    'OK' => 'Correcto',
    'SIN_CUENTA' => 'Cuenta no registrada',
    'PENDIENTE_CU1' => 'Falta CU1',
    'PENDIENTE_CU3' => 'Falta CU3',
    'SIN_ALMACEN' => 'Falta almacén',
    'DUPLICADO' => 'Correo duplicado',
];
$statusColors = [
    'OK' => 'success',
    'SIN_CUENTA' => 'danger',
    'PENDIENTE_CU1' => 'warning',
    'PENDIENTE_CU3' => 'warning',
    'SIN_ALMACEN' => 'warning',
    'DUPLICADO' => 'danger',
];

function distributionPageUrl(int $importId, string $query, string $status, int $page): string
{
    return ad_url('facturas/distribucion_ver.php?' . http_build_query([
        'id' => $importId,
        'q' => $query,
        'estado' => $status,
        'pagina' => $page,
    ]));
}

$title = 'Revisión de distribución';
require dirname(__DIR__, 2) . '/Views/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h1 class="h3 mb-1">Revisión de distribución</h1>
        <div class="text-muted">Factura <?= ad_e($import['numero_factura']) ?> · <?= ad_e($import['proveedor']) ?></div>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-success" href="<?= ad_e(ad_url('facturas/distribucion_exportar.php?id=' . $importId)) ?>">Exportar detalle</a>
        <a class="btn btn-outline-success" href="<?= ad_e(ad_url('facturas/distribucion_resumen_exportar.php?id=' . $importId)) ?>">Exportar consolidado</a>
        <a class="btn btn-outline-primary" href="<?= ad_e(ad_url('facturas/distribucion.php?id=' . (int)$import['factura_id'])) ?>">Importaciones</a>
        <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/show.php?id=' . (int)$import['factura_id'])) ?>">Factura</a>
    </div>
</div>

<?php if (!empty($import['mensaje'])): ?>
    <div class="alert alert-warning"><?= ad_e($import['mensaje']) ?></div>
<?php endif; ?>

<div class="distribution-kpis mb-3">
    <div class="distribution-kpi"><span>Usuarios del archivo</span><strong><?= number_format((int)$import['usuarios_fuente'], 0, ',', '.') ?></strong></div>
    <div class="distribution-kpi"><span>Correctos</span><strong class="text-success"><?= number_format((int)$import['usuarios_ok'], 0, ',', '.') ?></strong></div>
    <div class="distribution-kpi"><span>Pendientes</span><strong class="<?= (int)$import['usuarios_pendientes'] > 0 ? 'text-danger' : 'text-success' ?>"><?= number_format((int)$import['usuarios_pendientes'], 0, ',', '.') ?></strong></div>
    <div class="distribution-kpi"><span>Total base</span><strong><?= ad_e(ad_money($import['total_fuente'], $import['moneda'])) ?></strong></div>
    <div class="distribution-kpi"><span>Total distribuido</span><strong><?= ad_e(ad_money($import['total_distribuido'], $import['moneda'])) ?></strong></div>
    <div class="distribution-kpi"><span>Diferencia factura</span><strong class="<?= abs((float)$import['diferencia_factura']) > 0.02 ? 'text-danger' : 'text-success' ?>"><?= ad_e(ad_money($import['diferencia_factura'], $import['moneda'])) ?></strong></div>
</div>

<div class="card card-kpi mb-3">
    <div class="card-header fw-semibold">Resumen por plan</div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead><tr><th>Plan</th><th class="money">Usuarios</th><th class="money">Costo distribuido</th></tr></thead>
            <tbody>
            <?php foreach ($planSummary as $summary): ?>
                <tr><td><?= ad_e($summary['plan'] ?: 'SIN PLAN') ?></td><td class="money"><?= number_format((int)$summary['usuarios'], 0, ',', '.') ?></td><td class="money"><?= ad_e(ad_money($summary['total'], $import['moneda'])) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<form class="module-filter-card mb-3" method="get">
    <input type="hidden" name="id" value="<?= $importId ?>">
    <div class="row g-2">
        <div class="col-lg-7">
            <label class="form-label" for="distributionSearch">Buscar registro</label>
            <input class="form-control module-filter-control" id="distributionSearch" name="q" value="<?= ad_e($query) ?>" placeholder="Correo, plan, CU1, CU3, cliente o almacén">
        </div>
        <div class="col-lg-3">
            <label class="form-label" for="distributionStatus">Estado</label>
            <select class="form-select module-filter-control" id="distributionStatus" name="estado">
                <option value="">Todos los estados</option>
                <?php foreach ($statusLabels as $value => $label): ?>
                    <option value="<?= ad_e($value) ?>" <?= $status === $value ? 'selected' : '' ?>><?= ad_e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-lg-2 d-grid"><button class="btn btn-dark">Filtrar</button></div>
    </div>
</form>

<div class="card card-kpi">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Detalle distribuido</span>
        <small class="text-muted"><?= number_format($totalRows, 0, ',', '.') ?> registros</small>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-hover align-middle mb-0 distribution-table selectable-table">
            <thead><tr><th>Cuenta y plan</th><th>Distribución</th><th>Centros de costo</th><th>Destino</th><th class="money">Valor</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="7" class="p-4 text-muted">No se encontraron registros con estos filtros.</td></tr><?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <?php $editUrl = ad_url('facturas/distribucion_editar.php?importacion=' . $importId . '&fila=' . (int)$row['id']); ?>
                <tr data-href="<?= ad_e($editUrl) ?>" tabindex="0" role="link">
                    <td><strong><?= ad_e($row['correo']) ?></strong><div class="small text-muted"><?= ad_e($row['plan_normalizado'] ?: 'SIN PLAN') ?></div></td>
                    <td><span class="badge text-bg-light border"><?= ad_e($row['tipo_distribucion']) ?></span><div class="small text-muted"><?= number_format((float)$row['porcentaje'] * 100, 2, ',', '.') ?>%</div></td>
                    <td><div><strong>CU1:</strong> <?= ad_e($row['cu1'] ?: '—') ?></div><div class="small text-muted"><strong>CU3:</strong> <?= ad_e($row['cu3'] ?: '—') ?></div></td>
                    <td><?= ad_e($row['cliente'] ?: '—') ?><div class="small text-muted"><?= ad_e($row['almacen'] ?: 'Sin almacén') ?></div></td>
                    <td class="money"><strong><?= ad_e(ad_money($row['valor_distribuido'], $import['moneda'])) ?></strong></td>
                    <td><span class="badge text-bg-<?= ad_e($statusColors[$row['estado']] ?? 'secondary') ?>"><?= ad_e($statusLabels[$row['estado']] ?? $row['estado']) ?></span></td>
                    <td class="row-arrow" aria-hidden="true">›</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3" aria-label="Paginación de distribución"><ul class="pagination pagination-sm flex-wrap">
    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= ad_e(distributionPageUrl($importId, $query, $status, max(1, $page - 1))) ?>">Anterior</a></li>
    <?php for ($number = max(1, $page - 2); $number <= min($totalPages, $page + 2); $number++): ?>
        <li class="page-item <?= $number === $page ? 'active' : '' ?>"><a class="page-link" href="<?= ad_e(distributionPageUrl($importId, $query, $status, $number)) ?>"><?= $number ?></a></li>
    <?php endfor; ?>
    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="<?= ad_e(distributionPageUrl($importId, $query, $status, min($totalPages, $page + 1))) ?>">Siguiente</a></li>
</ul></nav>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.selectable-table tr[data-href]').forEach(function (row) {
        var openRow = function () { window.location.href = row.getAttribute('data-href'); };
        row.addEventListener('click', openRow);
        row.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openRow(); }
        });
    });
});
</script>

<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
