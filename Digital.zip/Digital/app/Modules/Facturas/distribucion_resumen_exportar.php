<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$importId = (int)($_GET['id'] ?? 0);

$importStatement = $pdo->prepare(
    'SELECT i.periodo, f.numero_factura, f.moneda
     FROM ad_importaciones_distribucion i
     INNER JOIN ad_facturas f ON f.id=i.factura_id
     WHERE i.id=:id'
);
$importStatement->execute([':id' => $importId]);
$import = $importStatement->fetch(PDO::FETCH_ASSOC);
if (!$import) {
    http_response_code(404);
    exit('Distribución no encontrada.');
}

$statement = $pdo->prepare(
    'SELECT cu1, cu3, proceso_cu1, regional, ciudad, almacen, cliente,
            linea_negocio, proyecto, grupo, empresa, proceso_general,
            tipo_proyecto, COUNT(DISTINCT correo) usuarios,
            SUM(valor_distribuido) total
     FROM ad_distribuciones_usuario_factura
     WHERE importacion_id=:id
     GROUP BY cu1, cu3, proceso_cu1, regional, ciudad, almacen, cliente,
              linea_negocio, proyecto, grupo, empresa, proceso_general, tipo_proyecto
     ORDER BY cu1, cu3, cliente, proyecto'
);
$statement->execute([':id' => $importId]);
$summary = $statement->fetchAll(PDO::FETCH_ASSOC);

$headers = [
    'Periodo', 'Factura', 'CU1', 'CU3', 'Usuarios', 'Total',
    'Proceso CU1', 'Regional', 'Ciudad', 'Almacén', 'Cliente',
    'Línea de negocio', 'Proyecto', 'Grupo', 'Empresa',
    'Proceso general', 'Tipo de proyecto',
];
$rows = [];
foreach ($summary as $row) {
    $rows[] = [
        $import['periodo'], $import['numero_factura'], $row['cu1'], $row['cu3'],
        (int)$row['usuarios'], (float)$row['total'], $row['proceso_cu1'],
        $row['regional'], $row['ciudad'], $row['almacen'], $row['cliente'],
        $row['linea_negocio'], $row['proyecto'], $row['grupo'], $row['empresa'],
        $row['proceso_general'], $row['tipo_proyecto'],
    ];
}

$storage = rtrim((string)ad_config('storage_path'), '/\\');
$directory = $storage . DIRECTORY_SEPARATOR . 'exports';
$safeInvoice = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)$import['numero_factura']) ?: 'factura';
$downloadName = 'consolidado_' . $safeInvoice . '_' . date('Ymd_His') . '.xlsx';
$path = $directory . DIRECTORY_SEPARATOR . bin2hex(random_bytes(8)) . '.xlsx';

try {
    SimpleXlsxWriter::write($path, 'Consolidado', $headers, $rows, [5], []);
    AuditService::log(
        $pdo,
        'ad_importaciones_distribucion',
        $importId,
        'EXPORTAR_CONSOLIDADO',
        null,
        ['registros' => count($rows)]
    );
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $downloadName . '"');
    header('Content-Length: ' . (string)filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
} catch (Throwable $e) {
    http_response_code(500);
    exit('No fue posible generar la exportación consolidada: ' . $e->getMessage());
} finally {
    if (is_file($path)) {
        unlink($path);
    }
}
