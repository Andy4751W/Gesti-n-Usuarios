<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.aprobar');
ad_verify_csrf();

try {
    if (!isset($_POST['respaldo_confirmado'])) {
        throw new RuntimeException('Debe confirmar que realizó la copia de seguridad de MySQL.');
    }
    if (trim((string)($_POST['confirmacion'] ?? '')) !== 'CONVERTIR A USD') {
        throw new RuntimeException('La frase de confirmación no coincide.');
    }
    $rateText = str_replace(',', '.', trim((string)($_POST['tasa'] ?? '')));
    if (!is_numeric($rateText)) {
        throw new RuntimeException('La tasa indicada no es válida.');
    }
    $service = new CurrencyConversionService(db());
    $service->convertCopToUsd((float)$rateText, (string)($_POST['fecha_tasa'] ?? ''), ad_current_user_id());
    ad_flash('success', 'La información histórica fue convertida correctamente a USD.');
} catch (Throwable $exception) {
    ad_flash('danger', 'No fue posible convertir la moneda: ' . $exception->getMessage());
}
ad_redirect('facturas/moneda.php');
