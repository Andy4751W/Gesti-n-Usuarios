<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$type = (string)($_GET['tipo'] ?? 'perfiles');
$allowed = ['licencias', 'perfiles', 'cu1', 'cu3', 'almacenes', 'integrales'];
if (!in_array($type, $allowed, true)) {
    $type = 'perfiles';
}
$query = trim((string)($_GET['q'] ?? ''));
$search = '%' . $query . '%';

$counts = [
    'licencias' => (int)$pdo->query('SELECT COUNT(*) FROM ad_suscripciones WHERE estado="VIGENTE"')->fetchColumn(),
    'perfiles' => (int)$pdo->query('SELECT COUNT(*) FROM ad_perfiles_distribucion_cuenta')->fetchColumn(),
    'cu1' => (int)$pdo->query('SELECT COUNT(*) FROM ad_cu1_catalogo WHERE activo=1')->fetchColumn(),
    'cu3' => (int)$pdo->query('SELECT COUNT(*) FROM ad_cu3_catalogo WHERE activo=1')->fetchColumn(),
    'almacenes' => (int)$pdo->query('SELECT COUNT(*) FROM ad_almacenes_distribucion WHERE activo=1')->fetchColumn(),
    'integrales' => (int)$pdo->query('SELECT COUNT(*) FROM ad_reglas_integrales WHERE activo=1')->fetchColumn(),
];
$labels = [
    'licencias' => 'Tarifas de licencias',
    'perfiles' => 'Perfiles por cuenta',
    'cu1' => 'Catálogo CU1',
    'cu3' => 'Catálogo CU3',
    'almacenes' => 'Almacenes',
    'integrales' => 'Reglas integrales R3',
];

if ($type === 'licencias') {
    $statement = $pdo->prepare(
        'SELECT s.*, p.nombre plan_nombre, p.fabricante, pr.razon_social proveedor
         FROM ad_suscripciones s
         INNER JOIN ad_planes p ON p.id=s.plan_id
         LEFT JOIN ad_proveedores pr ON pr.id=s.proveedor_id
         WHERE s.estado="VIGENTE" AND (
            p.nombre LIKE :q OR p.fabricante LIKE :q2 OR pr.razon_social LIKE :q3
            OR s.referencia_contrato LIKE :q4
         )
         ORDER BY p.nombre, s.estado, s.id LIMIT 100'
    );
    $statement->execute([':q'=>$search, ':q2'=>$search, ':q3'=>$search, ':q4'=>$search]);
} elseif ($type === 'perfiles') {
    $statement = $pdo->prepare(
        'SELECT pd.*, c.correo FROM ad_perfiles_distribucion_cuenta pd
         INNER JOIN ad_cuentas c ON c.id=pd.cuenta_id
         WHERE c.correo LIKE :q OR pd.cu1 LIKE :q2 OR pd.cu3 LIKE :q3
            OR pd.cliente LIKE :q4 OR pd.proyecto LIKE :q5
         ORDER BY c.correo LIMIT 100'
    );
    $statement->execute([':q' => $search, ':q2' => $search, ':q3' => $search, ':q4' => $search, ':q5' => $search]);
} elseif ($type === 'cu1') {
    $statement = $pdo->prepare(
        'SELECT * FROM ad_cu1_catalogo WHERE codigo LIKE :q OR descripcion LIKE :q2
          OR proceso LIKE :q3 OR ciudad LIKE :q4 ORDER BY activo DESC, codigo LIMIT 100'
    );
    $statement->execute([':q' => $search, ':q2' => $search, ':q3' => $search, ':q4' => $search]);
} elseif ($type === 'cu3') {
    $statement = $pdo->prepare(
        'SELECT * FROM ad_cu3_catalogo WHERE codigo LIKE :q OR descripcion LIKE :q2
          OR cliente LIKE :q3 OR proyecto LIKE :q4 ORDER BY activo DESC, codigo LIMIT 100'
    );
    $statement->execute([':q' => $search, ':q2' => $search, ':q3' => $search, ':q4' => $search]);
} elseif ($type === 'almacenes') {
    $statement = $pdo->prepare(
        'SELECT * FROM ad_almacenes_distribucion WHERE clave LIKE :q OR codigo_almacen LIKE :q2
          OR descripcion LIKE :q3 OR cliente LIKE :q4 ORDER BY activo DESC, clave LIMIT 100'
    );
    $statement->execute([':q' => $search, ':q2' => $search, ':q3' => $search, ':q4' => $search]);
} else {
    $statement = $pdo->prepare(
        'SELECT * FROM ad_reglas_integrales WHERE cliente LIKE :q OR linea_negocio LIKE :q2
          OR ciudad LIKE :q3 OR proyecto LIKE :q4 ORDER BY activo DESC, id LIMIT 100'
    );
    $statement->execute([':q' => $search, ':q2' => $search, ':q3' => $search, ':q4' => $search]);
}
$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
if ($type === 'licencias') {
    foreach ($rows as &$row) {
        $row['fabricante'] = ClientDashboardService::normalizeLicenseManufacturer(
            isset($row['fabricante']) ? (string)$row['fabricante'] : null,
            (string)$row['plan_nombre']
        );
    }
    unset($row);
}
$title = 'Datos maestros y tarifas';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h1 class="h3 mb-1">Datos maestros de facturación</h1><div class="text-muted">Reemplazan los cruces y búsquedas manuales del libro de Excel.</div></div>
    <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/facturas.php')) ?>">Volver a facturas</a>
</div>

<div class="distribution-kpis mb-3">
    <?php foreach ($labels as $key => $label): ?>
        <a class="distribution-kpi text-decoration-none <?= $type === $key ? 'master-kpi-active' : '' ?>" href="<?= ad_e(ad_url('facturas/configuracion.php?tipo=' . $key)) ?>">
            <span><?= ad_e($label) ?></span><strong><?= number_format($counts[$key], 0, ',', '.') ?></strong>
        </a>
    <?php endforeach; ?>
</div>

<form class="module-filter-card mb-3" method="get">
    <input type="hidden" name="tipo" value="<?= ad_e($type) ?>">
    <div class="row g-2">
        <div class="col-lg-9"><label class="form-label">Buscar en <?= ad_e($labels[$type]) ?></label><input class="form-control" name="q" value="<?= ad_e($query) ?>" placeholder="<?= $type === 'licencias' ? 'Licencia, fabricante, proveedor o contrato' : 'Código, correo, cliente, ciudad o proyecto' ?>"></div>
        <div class="col-lg-3 d-grid"><button class="btn btn-dark">Buscar</button></div>
    </div>
</form>

<div class="d-flex justify-content-between align-items-center mb-2">
    <h2 class="h5 mb-0"><?= ad_e($labels[$type]) ?></h2>
    <?php if ($type !== 'licencias'): ?><a class="btn btn-sm btn-primary" href="<?= ad_e(ad_url('facturas/configuracion_editar.php?tipo=' . $type)) ?>">Nuevo registro</a><?php endif; ?>
</div>
<div class="card card-kpi"><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0 selectable-table">
<thead><tr>
<?php if ($type === 'licencias'): ?><th>Licencia</th><th>Fabricante</th><th>Proveedor / contrato</th><th class="money">Precio mensual</th><th>Estado</th>
<?php elseif ($type === 'perfiles'): ?><th>Cuenta</th><th>Plan / costo</th><th>CU1</th><th>CU3</th><th>Destino</th>
<?php elseif ($type === 'cu1'): ?><th>Código</th><th>Descripción</th><th>Proceso</th><th>Regional / ciudad</th><th>Estado</th>
<?php elseif ($type === 'cu3'): ?><th>Código</th><th>Descripción</th><th>Cliente</th><th>Línea / proyecto</th><th>Estado</th>
<?php elseif ($type === 'almacenes'): ?><th>Clave</th><th>CU1</th><th>CU3</th><th>Almacén</th><th>Descripción / cliente</th>
<?php else: ?><th>Cliente</th><th>Línea</th><th>Ciudad</th><th>Proyecto</th><th class="money">Ingresos / participación</th>
<?php endif; ?><th></th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="6" class="p-4 text-muted">No se encontraron registros.</td></tr><?php endif; ?>
<?php foreach ($rows as $row): ?>
<?php $rowId = $type === 'perfiles' ? $row['cuenta_id'] : ($type === 'cu1' || $type === 'cu3' ? $row['codigo'] : $row['id']); $url=ad_url('facturas/configuracion_editar.php?'.http_build_query(['tipo'=>$type,'id'=>$rowId])); ?>
<tr data-href="<?= ad_e($url) ?>" tabindex="0" role="link">
<?php if ($type === 'licencias'): ?>
<td><strong><?= ad_e($row['plan_nombre']) ?></strong><div class="small text-muted"><?= ad_e($row['referencia_sku'] ?: 'Sin SKU') ?></div></td><td><?= ad_e($row['fabricante'] ?: '—') ?></td><td><?= ad_e($row['proveedor'] ?: '—') ?><div class="small text-muted"><?= ad_e($row['referencia_contrato'] ?: 'Sin contrato') ?></div></td><td class="money"><?php if (strtoupper((string)$row['moneda']) === 'USD'): ?><strong><?= ad_e(ad_money($row['valor_unitario'], 'USD')) ?></strong><?php else: ?><span class="badge text-bg-warning">Pendiente configurar en USD</span><?php endif; ?></td><td><span class="badge text-bg-<?= $row['estado']==='VIGENTE'?'success':'secondary' ?>"><?= ad_e($row['estado']) ?></span></td>
<?php elseif ($type === 'perfiles'): ?>
<td><strong><?= ad_e($row['correo']) ?></strong></td><td><?= ad_e($row['plan_fuente'] ?: '—') ?><div class="small text-muted"><?= $row['costo_mensual'] !== null ? ad_e(ad_money($row['costo_mensual'], $row['moneda'])) : 'Sin costo fijo' ?></div></td><td><?= ad_e($row['cu1'] ?: '—') ?><div class="small text-muted"><?= ad_e($row['proceso_cu1']) ?></div></td><td><?= ad_e($row['cu3'] ?: '—') ?><div class="small text-muted"><?= ad_e($row['cliente']) ?></div></td><td><?= ad_e($row['almacen'] ?? 'Calculado por CU') ?><div class="small text-muted"><?= ad_e($row['proyecto']) ?></div></td>
<?php elseif ($type === 'cu1'): ?>
<td><strong><?= ad_e($row['codigo']) ?></strong></td><td><?= ad_e($row['descripcion']) ?></td><td><?= ad_e($row['proceso']) ?></td><td><?= ad_e($row['regional']) ?><div class="small text-muted"><?= ad_e($row['ciudad']) ?></div></td><td><span class="badge text-bg-<?= (int)$row['activo']===1?'success':'secondary' ?>"><?= (int)$row['activo']===1?'Activo':'Inactivo' ?></span></td>
<?php elseif ($type === 'cu3'): ?>
<td><strong><?= ad_e($row['codigo']) ?></strong></td><td><?= ad_e($row['descripcion']) ?></td><td><?= ad_e($row['cliente']) ?></td><td><?= ad_e($row['linea_negocio']) ?><div class="small text-muted"><?= ad_e($row['proyecto']) ?></div></td><td><span class="badge text-bg-<?= (int)$row['activo']===1?'success':'secondary' ?>"><?= (int)$row['activo']===1?'Activo':'Inactivo' ?></span></td>
<?php elseif ($type === 'almacenes'): ?>
<td><strong><?= ad_e($row['clave']) ?></strong></td><td><?= ad_e($row['cu1']) ?></td><td><?= ad_e($row['cu3']) ?></td><td><strong><?= ad_e($row['codigo_almacen']) ?></strong></td><td><?= ad_e($row['descripcion']) ?><div class="small text-muted"><?= ad_e($row['cliente']) ?></div></td>
<?php else: ?>
<td><?= ad_e($row['cliente']) ?></td><td><?= ad_e($row['linea_negocio']) ?></td><td><?= ad_e($row['ciudad']) ?></td><td><?= ad_e($row['proyecto']) ?></td><td class="money"><?= ad_e(ad_money($row['ingresos'], (string)($row['moneda'] ?? 'USD'))) ?><div class="small text-muted"><?= number_format((float)$row['porcentaje']*100,4,',','.') ?>%</div></td>
<?php endif; ?><td class="row-arrow">›</td></tr>
<?php endforeach; ?>
</tbody></table></div></div>
<div class="small text-muted mt-2">Se muestran hasta 100 registros. Use el buscador para encontrar un dato específico.</div>
<script>document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('tr[data-href]').forEach(function(row){var open=function(){window.location.href=row.getAttribute('data-href');};row.addEventListener('click',open);row.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});});});</script>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
