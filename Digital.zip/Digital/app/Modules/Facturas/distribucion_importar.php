<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
ad_verify_csrf();

$invoiceId = (int)($_POST['factura_id'] ?? 0);
$file = $_FILES['archivo_xlsx'] ?? null;
if ($invoiceId <= 0 || !is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    ad_flash('danger', 'Seleccione un archivo XLSX válido.');
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}

$originalName = basename((string)$file['name']);
$extension = mb_strtolower(pathinfo($originalName, PATHINFO_EXTENSION), 'UTF-8');
$size = (int)($file['size'] ?? 0);
$maxSize = (int)ad_config('max_xlsx_bytes');
if ($extension !== 'xlsx' || $size <= 0 || $size > $maxSize) {
    ad_flash('danger', 'El archivo debe ser XLSX y no superar ' . number_format($maxSize / 1048576, 0) . ' MB.');
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}
$signature = file_get_contents((string)$file['tmp_name'], false, null, 0, 4);
if ($signature === false || substr($signature, 0, 2) !== 'PK') {
    ad_flash('danger', 'El archivo cargado no tiene una estructura XLSX válida.');
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}

$storage = rtrim((string)ad_config('storage_path'), '/\\');
$relativeDirectory = 'facturas/distribuciones';
$directory = $storage . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDirectory);
if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
    ad_flash('danger', 'No fue posible crear el directorio para la distribución.');
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}

$storedName = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.xlsx';
$fullPath = $directory . DIRECTORY_SEPARATOR . $storedName;
$relativePath = $relativeDirectory . '/' . $storedName;
if (!move_uploaded_file((string)$file['tmp_name'], $fullPath)) {
    ad_flash('danger', 'No fue posible guardar el archivo cargado.');
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}

try {
    $service = new InvoiceDistributionService(db());
    $importId = $service->importWorkbook(
        $invoiceId,
        $fullPath,
        $originalName,
        $relativePath,
        ad_current_user_id()
    );
    if ($service->wasReprocessed()) {
        if (is_file($fullPath)) {
            unlink($fullPath);
        }
        ad_flash(
            'success',
            'Los datos maestros y la distribución fueron actualizados con el archivo ya registrado.'
        );
    } else {
        ad_flash(
            'success',
            'La distribución fue procesada. Revise los registros pendientes antes de aprobarla.'
        );
    }
    ad_redirect('facturas/distribucion_ver.php?id=' . $importId);
} catch (Throwable $e) {
    if (is_file($fullPath)) {
        unlink($fullPath);
    }
    ad_flash('danger', 'No fue posible procesar la distribución: ' . $e->getMessage());
    ad_redirect('facturas/distribucion.php?id=' . $invoiceId);
}
