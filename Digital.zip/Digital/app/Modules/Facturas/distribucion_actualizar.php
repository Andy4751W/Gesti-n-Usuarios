<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
ad_verify_csrf();

$importId = (int)($_POST['importacion_id'] ?? 0);
$rowId = (int)($_POST['fila_id'] ?? 0);
try {
    if ($importId <= 0 || $rowId <= 0) {
        throw new RuntimeException('La fila seleccionada no es válida.');
    }
    (new InvoiceDistributionService(db()))->updateDistribution($importId, $rowId, $_POST);
    ad_flash('success', 'La distribución fue corregida y sus controles se actualizaron.');
} catch (Throwable $e) {
    ad_flash('danger', 'No fue posible guardar la corrección: ' . $e->getMessage());
}
ad_redirect('facturas/distribucion_ver.php?id=' . $importId);
