<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.aprobar');
$service = new CurrencyConversionService(db());
try {
    $status = $service->status();
} catch (Throwable $exception) {
    http_response_code(500);
    exit(
        'No fue posible preparar la configuración de moneda. Ejecute '
        . 'C:\\xampp\\php\\php.exe bin\\update.php. Detalle: '
        . ad_e($exception->getMessage())
    );
}
$completed = ($status['estado'] ?? '') === 'COMPLETADA';
$summary = json_decode((string)($status['resumen'] ?? ''), true);
$summary = is_array($summary) ? $summary : [];
$labels = [
    'detalles_factura'=>'Detalles de factura',
    'conciliaciones'=>'Conciliaciones',
    'distribuciones_factura'=>'Distribuciones de factura',
    'importaciones_distribucion'=>'Importaciones de distribución',
    'distribuciones_usuario'=>'Distribuciones por usuario',
    'facturas'=>'Facturas',
    'dominios'=>'Dominios',
    'suscripciones'=>'Suscripciones',
    'asignaciones_licencia'=>'Asignaciones de licencia',
    'perfiles_distribucion'=>'Perfiles de distribución',
    'reglas_integrales'=>'Reglas integrales',
    'proveedores'=>'Proveedores',
];
$title = 'Moneda del sistema';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h1 class="h3 mb-1">Moneda del sistema</h1><div class="text-muted">Todos los valores nuevos se registran y presentan en USD.</div></div>
    <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/configuracion.php')) ?>">Volver a datos maestros</a>
</div>

<?php if ($completed): ?>
<div class="alert alert-success">
    <strong>Conversión completada.</strong> La base histórica fue convertida de COP a USD con una tasa de
    <strong><?= ad_e(number_format((float)$status['tasa_cop_por_usd'], 6, ',', '.')) ?> COP por USD</strong>,
    correspondiente al <?= ad_e((string)$status['fecha_tasa']) ?>.
</div>
<div class="card card-kpi"><div class="card-body">
    <h2 class="h5">Registro de la conversión</h2>
    <p class="text-muted">El control de una sola ejecución está activo. El sistema no permite volver a dividir estos valores.</p>
    <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Conjunto de datos</th><th class="text-end">Registros actualizados</th></tr></thead><tbody>
    <?php foreach ($labels as $key=>$label): ?><tr><td><?= ad_e($label) ?></td><td class="text-end"><?= number_format((int)($summary[$key] ?? 0), 0, ',', '.') ?></td></tr><?php endforeach; ?>
    </tbody></table></div>
</div></div>
<?php else: ?>
<div class="alert alert-warning"><strong>Pendiente:</strong> los registros históricos marcados como COP todavía no han sido convertidos. Haga primero una copia de seguridad de MySQL.</div>
<div class="card card-kpi"><div class="card-body">
    <h2 class="h5">Convertir información histórica a USD</h2>
    <p>Escriba la tasa exacta en formato <strong>COP por 1 USD</strong>. Ejemplo: si un dólar vale 4.000 pesos, escriba <strong>4000</strong>. El cálculo aplicado será <code>valor COP ÷ tasa = valor USD</code>.</p>
    <form method="post" action="<?= ad_e(ad_url('facturas/moneda_convertir.php')) ?>" class="row g-3">
        <input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>">
        <div class="col-md-4"><label class="form-label">Tasa COP por USD *</label><input class="form-control" name="tasa" type="number" min="100" max="100000" step="0.000001" required placeholder="Ejemplo: 4000.000000"></div>
        <div class="col-md-4"><label class="form-label">Fecha oficial de la tasa *</label><input class="form-control" name="fecha_tasa" type="date" required value="<?= ad_e(date('Y-m-d')) ?>"></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="respaldo_confirmado" value="1" id="backupConfirmed" required><label class="form-check-label" for="backupConfirmed">Confirmo que hice una copia de seguridad de la base de datos.</label></div></div>
        <div class="col-md-6"><label class="form-label">Confirmación *</label><input class="form-control" name="confirmacion" required autocomplete="off" placeholder="Escriba: CONVERTIR A USD"></div>
        <div class="col-12"><button class="btn btn-danger">Convertir definitivamente a USD</button></div>
    </form>
</div></div>
<?php endif; ?>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
