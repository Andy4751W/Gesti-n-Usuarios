<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$type = (string)($_GET['tipo'] ?? '');
$allowed = ['licencias', 'perfiles', 'cu1', 'cu3', 'almacenes', 'integrales'];
if (!in_array($type, $allowed, true)) {
    http_response_code(400);
    exit('Tipo de configuración no válido.');
}
$id = trim((string)($_GET['id'] ?? ''));
if ($id === '' && $type === 'licencias') {
    ad_redirect('facturas/configuracion.php?tipo=licencias');
}
$row = [];
if ($id !== '') {
    if ($type === 'licencias') {
        $statement = $pdo->prepare(
            'SELECT s.*, p.nombre plan_nombre, p.fabricante, pr.razon_social proveedor
             FROM ad_suscripciones s INNER JOIN ad_planes p ON p.id=s.plan_id
             LEFT JOIN ad_proveedores pr ON pr.id=s.proveedor_id WHERE s.id=:id'
        );
    } elseif ($type === 'perfiles') {
        $statement = $pdo->prepare('SELECT pd.*, c.correo FROM ad_perfiles_distribucion_cuenta pd INNER JOIN ad_cuentas c ON c.id=pd.cuenta_id WHERE pd.cuenta_id=:id');
    } elseif ($type === 'cu1') {
        $statement = $pdo->prepare('SELECT * FROM ad_cu1_catalogo WHERE codigo=:id');
    } elseif ($type === 'cu3') {
        $statement = $pdo->prepare('SELECT * FROM ad_cu3_catalogo WHERE codigo=:id');
    } elseif ($type === 'almacenes') {
        $statement = $pdo->prepare('SELECT * FROM ad_almacenes_distribucion WHERE id=:id');
    } else {
        $statement = $pdo->prepare('SELECT * FROM ad_reglas_integrales WHERE id=:id');
    }
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
    if ($row === []) {
        http_response_code(404);
        exit('Registro de configuración no encontrado.');
    }
    if ($type === 'licencias') {
        $row['fabricante'] = ClientDashboardService::normalizeLicenseManufacturer(
            isset($row['fabricante']) ? (string)$row['fabricante'] : null,
            (string)$row['plan_nombre']
        );
    }
}
$accounts = [];
if ($type === 'perfiles' && $id === '') {
    $accounts = $pdo->query(
        'SELECT c.id, c.correo FROM ad_cuentas c
         LEFT JOIN ad_perfiles_distribucion_cuenta pd ON pd.cuenta_id=c.id
         WHERE pd.cuenta_id IS NULL ORDER BY c.correo LIMIT 2500'
    )->fetchAll(PDO::FETCH_ASSOC);
}
$labels = ['licencias'=>'Tarifa de licencia en USD','perfiles'=>'Perfil de distribución','cu1'=>'Centro de costo CU1','cu3'=>'Centro de costo CU3','almacenes'=>'Almacén de distribución','integrales'=>'Regla integral R3'];
function configValue(array $row, string $key): string { return ad_e($row[$key] ?? ''); }
$title = ($id === '' ? 'Crear ' : 'Editar ') . $labels[$type];
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h1 class="h3 mb-1"><?= ad_e($title) ?></h1><div class="text-muted">Los cambios se aplicarán en la siguiente distribución calculada.</div></div><a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/configuracion.php?tipo='.$type)) ?>">Volver</a></div>
<div class="card card-kpi"><div class="card-body"><form method="post" action="<?= ad_e(ad_url('facturas/configuracion_guardar.php')) ?>">
<input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>"><input type="hidden" name="tipo" value="<?= ad_e($type) ?>"><input type="hidden" name="id_original" value="<?= ad_e($id) ?>">
<div class="row g-3">
<?php if ($type === 'licencias'): ?>
<div class="col-lg-6"><label class="form-label">Licencia</label><input class="form-control" value="<?= configValue($row,'plan_nombre') ?>" readonly></div>
<div class="col-lg-3"><label class="form-label">Fabricante</label><input class="form-control" value="<?= configValue($row,'fabricante') ?>" readonly></div>
<div class="col-lg-3"><label class="form-label">Proveedor</label><input class="form-control" value="<?= configValue($row,'proveedor') ?>" readonly></div>
<div class="col-lg-6"><label class="form-label">Referencia de contrato</label><input class="form-control" value="<?= configValue($row,'referencia_contrato') ?>" readonly></div>
<div class="col-lg-3"><label class="form-label">Precio mensual real (USD) *</label><input class="form-control" type="number" min="0" step="0.0001" name="valor_unitario" required value="<?= strtoupper((string)($row['moneda'] ?? '')) === 'USD' ? configValue($row,'valor_unitario') : '' ?>" placeholder="Ejemplo: 5.0000"></div>
<div class="col-lg-3"><label class="form-label">Moneda</label><input class="form-control" value="USD" readonly><input type="hidden" name="moneda" value="USD"></div>
<div class="col-12"><div class="alert alert-info mb-0">Digite el precio que el proveedor cobra originalmente en dólares. El sistema no consulta TRM ni convierte valores desde pesos colombianos.</div></div>
<?php elseif ($type === 'perfiles'): ?>
<div class="col-12"><label class="form-label">Cuenta *</label><?php if ($id!==''): ?><input class="form-control" value="<?= configValue($row,'correo') ?>" readonly><input type="hidden" name="cuenta_id" value="<?= (int)$row['cuenta_id'] ?>"><?php else: ?><select class="form-select" name="cuenta_id" required><option value="">Seleccione una cuenta</option><?php foreach($accounts as $account):?><option value="<?= (int)$account['id'] ?>"><?= ad_e($account['correo']) ?></option><?php endforeach;?></select><?php endif;?></div>
<div class="col-lg-6"><label class="form-label">Plan de referencia</label><input class="form-control" name="plan_fuente" maxlength="190" value="<?= configValue($row,'plan_fuente') ?>"></div><div class="col-lg-3"><label class="form-label">Costo mensual (USD)</label><input class="form-control" type="number" min="0" step="0.0001" name="costo_mensual" value="<?= configValue($row,'costo_mensual') ?>"></div><div class="col-lg-3"><label class="form-label">Moneda</label><input class="form-control" value="USD" readonly><input type="hidden" name="moneda" value="USD"></div>
<div class="col-lg-3"><label class="form-label">CU1 *</label><input class="form-control" name="cu1" maxlength="30" required value="<?= configValue($row,'cu1') ?>"></div><div class="col-lg-3"><label class="form-label">CU3 *</label><input class="form-control" name="cu3" maxlength="30" required value="<?= configValue($row,'cu3') ?>"></div><div class="col-lg-3"><label class="form-label">Regional</label><input class="form-control" name="regional" maxlength="120" value="<?= configValue($row,'regional') ?>"></div><div class="col-lg-3"><label class="form-label">Ciudad</label><input class="form-control" name="ciudad" maxlength="120" value="<?= configValue($row,'ciudad') ?>"></div>
<div class="col-lg-4"><label class="form-label">Proceso CU1</label><input class="form-control" name="proceso_cu1" maxlength="190" value="<?= configValue($row,'proceso_cu1') ?>"></div><div class="col-lg-4"><label class="form-label">Cliente</label><input class="form-control" name="cliente" maxlength="190" value="<?= configValue($row,'cliente') ?>"></div><div class="col-lg-4"><label class="form-label">Línea de negocio</label><input class="form-control" name="linea_negocio" maxlength="190" value="<?= configValue($row,'linea_negocio') ?>"></div>
<div class="col-lg-4"><label class="form-label">Proyecto</label><input class="form-control" name="proyecto" maxlength="190" value="<?= configValue($row,'proyecto') ?>"></div><div class="col-lg-4"><label class="form-label">Grupo</label><input class="form-control" name="grupo" maxlength="120" value="<?= configValue($row,'grupo') ?>"></div><div class="col-lg-4"><label class="form-label">Empresa</label><input class="form-control" name="empresa" maxlength="190" value="<?= configValue($row,'empresa') ?>"></div>
<div class="col-lg-6"><label class="form-label">Proceso general</label><input class="form-control" name="proceso_general" maxlength="190" value="<?= configValue($row,'proceso_general') ?>"></div><div class="col-lg-6"><label class="form-label">Tipo de proyecto</label><input class="form-control" name="tipo_proyecto" maxlength="120" value="<?= configValue($row,'tipo_proyecto') ?>"></div><div class="col-12"><label class="form-label">Observaciones</label><input class="form-control" name="observaciones" maxlength="500" value="<?= configValue($row,'observaciones') ?>"></div>
<?php elseif ($type === 'cu1'): ?>
<div class="col-lg-3"><label class="form-label">Código *</label><input class="form-control" name="codigo" maxlength="30" required value="<?= configValue($row,'codigo') ?>" <?= $id!==''?'readonly':'' ?>></div><div class="col-lg-9"><label class="form-label">Descripción corta</label><input class="form-control" name="descripcion_corta" maxlength="190" value="<?= configValue($row,'descripcion_corta') ?>"></div><div class="col-12"><label class="form-label">Descripción</label><input class="form-control" name="descripcion" maxlength="255" value="<?= configValue($row,'descripcion') ?>"></div><div class="col-lg-4"><label class="form-label">Proceso</label><input class="form-control" name="proceso" maxlength="190" value="<?= configValue($row,'proceso') ?>"></div><div class="col-lg-4"><label class="form-label">Regional</label><input class="form-control" name="regional" maxlength="120" value="<?= configValue($row,'regional') ?>"></div><div class="col-lg-4"><label class="form-label">Ciudad</label><input class="form-control" name="ciudad" maxlength="120" value="<?= configValue($row,'ciudad') ?>"></div>
<?php elseif ($type === 'cu3'): ?>
<div class="col-lg-3"><label class="form-label">Código *</label><input class="form-control" name="codigo" maxlength="30" required value="<?= configValue($row,'codigo') ?>" <?= $id!==''?'readonly':'' ?>></div><div class="col-lg-9"><label class="form-label">Descripción corta</label><input class="form-control" name="descripcion_corta" maxlength="190" value="<?= configValue($row,'descripcion_corta') ?>"></div><div class="col-12"><label class="form-label">Descripción</label><input class="form-control" name="descripcion" maxlength="255" value="<?= configValue($row,'descripcion') ?>"></div><div class="col-lg-4"><label class="form-label">Cliente</label><input class="form-control" name="cliente" maxlength="190" value="<?= configValue($row,'cliente') ?>"></div><div class="col-lg-4"><label class="form-label">Línea de negocio</label><input class="form-control" name="linea_negocio" maxlength="190" value="<?= configValue($row,'linea_negocio') ?>"></div><div class="col-lg-4"><label class="form-label">Proyecto</label><input class="form-control" name="proyecto" maxlength="190" value="<?= configValue($row,'proyecto') ?>"></div><div class="col-lg-6"><label class="form-label">Clasificación integral</label><input class="form-control" name="linea_temp" maxlength="120" value="<?= configValue($row,'linea_temp') ?>" placeholder="Ejemplo: INTEGRAL"></div>
<?php elseif ($type === 'almacenes'): ?>
<div class="col-lg-3"><label class="form-label">CU1 *</label><input class="form-control" name="cu1" maxlength="30" required value="<?= configValue($row,'cu1') ?>"></div><div class="col-lg-3"><label class="form-label">CU3 *</label><input class="form-control" name="cu3" maxlength="30" required value="<?= configValue($row,'cu3') ?>"></div><div class="col-lg-3"><label class="form-label">Código almacén *</label><input class="form-control" name="codigo_almacen" maxlength="40" required value="<?= configValue($row,'codigo_almacen') ?>"></div><div class="col-lg-3"><label class="form-label">Cliente</label><input class="form-control" name="cliente" maxlength="190" value="<?= configValue($row,'cliente') ?>"></div><div class="col-12"><label class="form-label">Descripción</label><input class="form-control" name="descripcion" maxlength="255" value="<?= configValue($row,'descripcion') ?>"></div>
<?php else: ?>
<div class="col-lg-6"><label class="form-label">Cliente *</label><input class="form-control" name="cliente" maxlength="190" required value="<?= configValue($row,'cliente') ?>"></div><div class="col-lg-6"><label class="form-label">Línea de negocio *</label><input class="form-control" name="linea_negocio" maxlength="190" required value="<?= configValue($row,'linea_negocio') ?>"></div><div class="col-lg-4"><label class="form-label">Ciudad *</label><input class="form-control" name="ciudad" maxlength="120" required value="<?= configValue($row,'ciudad') ?>"></div><div class="col-lg-4"><label class="form-label">Proyecto / alcance *</label><input class="form-control" name="proyecto" maxlength="190" required value="<?= configValue($row,'proyecto') ?>"></div><div class="col-lg-4"><label class="form-label">Ingresos (USD) *</label><input class="form-control" type="number" min="0.01" step="0.01" name="ingresos" required value="<?= configValue($row,'ingresos') ?>"></div><div class="col-12"><div class="form-text">La participación se recalcula automáticamente como ingresos de la regla ÷ ingresos totales activos.</div></div>
<?php endif; ?>
<?php if ($type !== 'perfiles' && $type !== 'licencias'): ?><div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" value="1" id="activeRecord" <?= !isset($row['activo']) || (int)$row['activo']===1?'checked':'' ?>><label class="form-check-label" for="activeRecord">Registro activo</label></div></div><?php endif; ?>
</div><div class="d-flex justify-content-end gap-2 mt-4"><a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/configuracion.php?tipo='.$type)) ?>">Cancelar</a><button class="btn btn-primary">Guardar</button></div></form></div></div>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
