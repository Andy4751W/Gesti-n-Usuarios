<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$importId = (int)($_GET['importacion'] ?? 0);
$rowId = (int)($_GET['fila'] ?? 0);

$statement = $pdo->prepare(
    'SELECT d.*, i.factura_id, f.numero_factura, f.moneda
     FROM ad_distribuciones_usuario_factura d
     INNER JOIN ad_importaciones_distribucion i ON i.id=d.importacion_id
     INNER JOIN ad_facturas f ON f.id=i.factura_id
     WHERE d.id=:fila AND d.importacion_id=:importacion'
);
$statement->execute([':fila' => $rowId, ':importacion' => $importId]);
$row = $statement->fetch(PDO::FETCH_ASSOC);
if (!$row) {
    http_response_code(404);
    exit('Registro de distribución no encontrado.');
}

$title = 'Corregir distribución';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h1 class="h3 mb-1">Corregir distribución</h1><div class="text-muted">Factura <?= ad_e($row['numero_factura']) ?> · fila <?= (int)$row['fila_origen'] ?> de BASE ADMIN</div></div>
    <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/distribucion_ver.php?id=' . $importId)) ?>">Volver</a>
</div>

<div class="card card-kpi">
    <div class="card-body">
        <div class="alert alert-light border d-flex flex-wrap justify-content-between gap-2">
            <span><strong><?= ad_e($row['plan_normalizado'] ?: 'SIN PLAN') ?></strong> · <?= ad_e($row['tipo_distribucion']) ?></span>
            <span><?= ad_e(ad_money($row['valor_distribuido'], $row['moneda'])) ?></span>
        </div>
        <form method="post" action="<?= ad_e(ad_url('facturas/distribucion_actualizar.php')) ?>">
            <input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>">
            <input type="hidden" name="importacion_id" value="<?= $importId ?>">
            <input type="hidden" name="fila_id" value="<?= $rowId ?>">
            <div class="row g-3">
                <div class="col-lg-6"><label class="form-label">Correo</label><input class="form-control" type="email" name="correo" maxlength="190" required value="<?= ad_e($row['correo']) ?>"></div>
                <div class="col-lg-3"><label class="form-label">CU1</label><input class="form-control" name="cu1" maxlength="30" required value="<?= ad_e($row['cu1']) ?>"></div>
                <div class="col-lg-3"><label class="form-label">CU3</label><input class="form-control" name="cu3" maxlength="30" required value="<?= ad_e($row['cu3']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Proceso CU1</label><input class="form-control" name="proceso_cu1" maxlength="190" value="<?= ad_e($row['proceso_cu1']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Regional</label><input class="form-control" name="regional" maxlength="120" value="<?= ad_e($row['regional']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Ciudad</label><input class="form-control" name="ciudad" maxlength="120" value="<?= ad_e($row['ciudad']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Cliente</label><input class="form-control" name="cliente" maxlength="190" value="<?= ad_e($row['cliente']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Línea de negocio</label><input class="form-control" name="linea_negocio" maxlength="190" value="<?= ad_e($row['linea_negocio']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Proyecto</label><input class="form-control" name="proyecto" maxlength="190" value="<?= ad_e($row['proyecto']) ?>"></div>
                <div class="col-lg-4"><label class="form-label">Almacén</label><input class="form-control" name="almacen" maxlength="40" required value="<?= ad_e($row['almacen']) ?>"></div>
                <div class="col-lg-8"><label class="form-label">Observaciones</label><input class="form-control" name="observaciones" maxlength="500" value="<?= ad_e($row['observaciones']) ?>"></div>
            </div>
            <div class="d-flex justify-content-end gap-2 mt-4">
                <a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('facturas/distribucion_ver.php?id=' . $importId)) ?>">Cancelar</a>
                <button class="btn btn-primary">Guardar corrección</button>
            </div>
        </form>
    </div>
</div>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
