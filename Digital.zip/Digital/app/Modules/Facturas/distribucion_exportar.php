<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('facturas.conciliar');
$pdo = db();
$importId = (int)($_GET['id'] ?? 0);

$importStatement = $pdo->prepare(
    'SELECT i.*, f.numero_factura, f.moneda
     FROM ad_importaciones_distribucion i
     INNER JOIN ad_facturas f ON f.id=i.factura_id
     WHERE i.id=:id'
);
$importStatement->execute([':id' => $importId]);
$import = $importStatement->fetch(PDO::FETCH_ASSOC);
if (!$import) {
    http_response_code(404);
    exit('Distribución no encontrada.');
}

$statement = $pdo->prepare(
    'SELECT * FROM ad_distribuciones_usuario_factura
     WHERE importacion_id=:id ORDER BY correo, fila_origen, id'
);
$statement->execute([':id' => $importId]);
$distributions = $statement->fetchAll(PDO::FETCH_ASSOC);

$headers = [
    'Periodo', 'Factura', 'Correo', 'Plan', 'Valor base', 'Tipo distribución',
    'Porcentaje', 'Valor distribuido', 'CU1', 'Proceso CU1', 'Regional', 'Ciudad',
    'CU3', 'Cliente', 'Línea de negocio', 'Proyecto', 'Grupo', 'Empresa',
    'Proceso general', 'Tipo de proyecto', 'Almacén', 'Estado', 'Observaciones',
];
$rows = [];
$seenBase = [];
foreach ($distributions as $distribution) {
    $baseKey = (string)$distribution['correo'] . '|' . (string)$distribution['fila_origen'];
    $baseValue = isset($seenBase[$baseKey]) ? null : (float)$distribution['valor_base'];
    $seenBase[$baseKey] = true;
    $rows[] = [
        $import['periodo'],
        $import['numero_factura'],
        $distribution['correo'],
        $distribution['plan_normalizado'],
        $baseValue,
        $distribution['tipo_distribucion'],
        (float)$distribution['porcentaje'],
        (float)$distribution['valor_distribuido'],
        $distribution['cu1'],
        $distribution['proceso_cu1'],
        $distribution['regional'],
        $distribution['ciudad'],
        $distribution['cu3'],
        $distribution['cliente'],
        $distribution['linea_negocio'],
        $distribution['proyecto'],
        $distribution['grupo'],
        $distribution['empresa'],
        $distribution['proceso_general'],
        $distribution['tipo_proyecto'],
        $distribution['almacen'],
        $distribution['estado'],
        $distribution['observaciones'],
    ];
}

$storage = rtrim((string)ad_config('storage_path'), '/\\');
$directory = $storage . DIRECTORY_SEPARATOR . 'exports';
$safeInvoice = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)$import['numero_factura']) ?: 'factura';
$downloadName = 'distribucion_' . $safeInvoice . '_' . date('Ymd_His') . '.xlsx';
$path = $directory . DIRECTORY_SEPARATOR . bin2hex(random_bytes(8)) . '.xlsx';

try {
    SimpleXlsxWriter::write($path, 'Distribucion', $headers, $rows, [4, 7], [6]);
    AuditService::log($pdo, 'ad_importaciones_distribucion', $importId, 'EXPORTAR_DISTRIBUCION', null, ['registros' => count($rows)]);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $downloadName . '"');
    header('Content-Length: ' . (string)filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
} catch (Throwable $e) {
    http_response_code(500);
    exit('No fue posible generar la exportación: ' . $e->getMessage());
} finally {
    if (is_file($path)) {
        unlink($path);
    }
}
