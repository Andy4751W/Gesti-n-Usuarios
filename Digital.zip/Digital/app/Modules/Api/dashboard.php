<?php
declare(strict_types=1);
require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('dashboards.clientes.ver');
ad_redirect('dashboards/informe.php');
