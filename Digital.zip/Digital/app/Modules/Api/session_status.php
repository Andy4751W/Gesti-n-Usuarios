<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';

header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

$user = ad_current_user();
if (!$user) {
    ad_json_response([
        'authenticated' => false,
        'message' => 'La sesión ya no está activa.',
    ], 401);
}

SessionAuditService::heartbeat($user);
ad_json_response(['authenticated' => true]);
