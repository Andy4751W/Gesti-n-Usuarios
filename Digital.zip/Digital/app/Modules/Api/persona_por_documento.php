<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

require_once dirname(__DIR__, 3) . '/bootstrap.php';

$sendJson = static function (bool $ok, string $found, string $validation, ?string $uniclass, ?array $data, string $message, string $consultedAt, int $status = 200): void {
    http_response_code($status);
    echo json_encode([
        'ok' => $ok,
        'encontrado' => $found,
        'estado_validacion' => $validation,
        'estado_uniclass' => $uniclass,
        'origen' => 'UNICLASS_DIRECTO',
        'consulta_directa' => true,
        'consultado_en' => $consultedAt,
        'datos' => $data,
        'mensaje' => $message,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
};

try {
    if (!ad_is_authenticated()) {
        $sendJson(false, 'ERROR_CONEXION', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'La sesión ha vencido. Ingrese nuevamente.', date('c'), 401);
    }
    if (!ad_can('cuentas.editar')) {
        $sendJson(false, 'ERROR_CONEXION', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'No tiene permiso para consultar funcionarios.', date('c'), 403);
    }

    $pais = strtoupper(trim((string)($_GET['pais'] ?? 'CO')));
    if (!in_array($pais, ['CO', 'PE'], true)) {
        $sendJson(false, 'NO_ENCONTRADO', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'El país seleccionado no es válido.', date('c'), 422);
    }
    $document = preg_replace('/\D+/', '', trim((string)($_GET['documento'] ?? ''))) ?? '';
    if ($document === '') {
        $sendJson(false, 'NO_ENCONTRADO', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'Debe ingresar el número de documento.', date('c'), 422);
    }

    $result = (new UniclassEmploymentService(db()))->lookupDocument($document);
    $state = (string)($result['status'] ?? 'ERROR_CONEXION');
    if ($state === 'RETIRADO') {
        $sendJson(false, 'RETIRADO', 'RETIRADO_CON_LICENCIA', 'R', null, (string)$result['message'], (string)$result['consultado_en'], 409);
    }
    if ($state === 'ACTIVO') {
        $data = (array)($result['datos'] ?? []);
        $sendJson(true, 'ACTIVO', 'ACTIVO', $result['estado_uniclass'], [
            'numero_documento' => $document,
            'nombre' => $data['nombre'] ?? null,
            'cargo' => $data['cargo'] ?? null,
            'ciudad' => $data['ciudad'] ?? null,
            'proceso' => $data['proceso'] ?? null,
            'cliente' => $data['cliente'] ?? null,
            'proyecto' => $data['proyecto'] ?? null,
            'cu3' => $data['cu3'] ?? null,
            'linea' => $data['linea'] ?? null,
            'empresa' => $data['empresa'] ?? null,
            'empresa_codigo' => $data['empresa_codigo'] ?? null,
            'pais' => $data['pais'] ?? null,
            'estado_uniclass' => $data['estado_uniclass'] ?? null,
            'actualizado_uniclass' => $data['actualizado_uniclass'] ?? null,
        ], (string)$result['message'], (string)$result['consultado_en']);
    }
    if ($state === 'NO_ENCONTRADO') {
        $sendJson(false, 'NO_ENCONTRADO', 'PENDIENTE_REGISTRO_UNICLASS', null, null, (string)$result['message'], (string)$result['consultado_en'], 404);
    }
    $sendJson(false, 'ERROR_CONEXION', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'UNICLASS no disponible', (string)($result['consultado_en'] ?? date('c')), 503);
} catch (Throwable $exception) {
    error_log('persona_por_documento.php: ' . $exception->getMessage());
    $sendJson(false, 'ERROR_CONEXION', 'PENDIENTE_REGISTRO_UNICLASS', null, null, 'UNICLASS no disponible', date('c'), 503);
}
