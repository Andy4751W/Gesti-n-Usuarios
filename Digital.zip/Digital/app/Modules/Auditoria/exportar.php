<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('auditoria.ver');
$filters = SessionAuditReportService::filters($_GET);
$rows = SessionAuditReportService::exportRows(db(), $filters);
$filename = 'auditoria_sesiones_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
$output = fopen('php://output', 'wb');
if ($output === false) { http_response_code(500); exit; }
fwrite($output, "\xEF\xBB\xBF");
fputcsv($output, ['Fecha','Evento','ID usuario','Nombre','Correo','Rol','Módulo','Ruta','Método','IP','Sesión hash','HTTP','Estado sesión','Última actividad','Cierre'], ';');
$safeCell = static function ($value) {
    $text = (string)$value;
    return preg_match('/^[=+\-@]/', $text) ? "'" . $text : $text;
};
foreach ($rows as $row) {
    fputcsv($output, array_map($safeCell, [$row['created_at'],$row['evento'],$row['usuario_id'],$row['usuario_nombre'],$row['usuario_email'],$row['rol'],$row['modulo'],$row['ruta'],$row['metodo'],$row['ip'],$row['session_hash'],$row['codigo_http'],$row['sesion_estado'],$row['ultima_actividad_at'],$row['cerrada_at']]), ';');
}
fclose($output);
exit;
