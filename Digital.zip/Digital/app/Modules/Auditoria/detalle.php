<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('auditoria.ver');
$pdo = db();
$filters = SessionAuditReportService::filters($_GET);
$report = SessionAuditReportService::detailed($pdo, $filters);
$events = SessionAuditReportService::events($pdo);
$query = $filters;
unset($query['page']);
$title = 'Auditoría detallada';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><h1 class="h3 mb-1">Auditoría de sesiones</h1><div class="text-muted">Trazabilidad detallada de accesos y uso de la plataforma.</div></div><a class="btn btn-outline-success" href="<?= ad_e(ad_url('auditoria/exportar.php?' . http_build_query($query))) ?>">Descargar CSV</a></div>
<ul class="nav nav-tabs audit-tabs mb-3"><li class="nav-item"><a class="nav-link" href="<?= ad_e(ad_url('auditoria/auditoria.php')) ?>">Uso general</a></li><li class="nav-item"><a class="nav-link active" href="<?= ad_e(ad_url('auditoria/detalle.php')) ?>">Auditoría detallada</a></li></ul>

<form class="module-filter-card mb-3" method="get"><div class="row g-2">
<div class="col-md-3 col-xl-2"><label class="form-label">Desde</label><input class="form-control" type="date" name="desde" value="<?= ad_e($filters['desde']) ?>"></div>
<div class="col-md-3 col-xl-2"><label class="form-label">Hasta</label><input class="form-control" type="date" name="hasta" value="<?= ad_e($filters['hasta']) ?>"></div>
<div class="col-md-3 col-xl-2"><label class="form-label">Evento</label><select class="form-select" name="evento"><option value="">Todos</option><?php foreach($events as $event): ?><option value="<?= ad_e($event) ?>" <?= $filters['evento']===$event?'selected':'' ?>><?= ad_e($event) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3 col-xl-2"><label class="form-label">Método</label><select class="form-select" name="metodo"><option value="">Todos</option><?php foreach(['GET','POST','PUT','DELETE'] as $method): ?><option <?= $filters['metodo']===$method?'selected':'' ?>><?= $method ?></option><?php endforeach; ?></select></div>
<div class="col-md-4 col-xl-2"><label class="form-label">Módulo</label><input class="form-control" name="modulo" value="<?= ad_e($filters['modulo']) ?>" placeholder="cuentas"></div>
<div class="col-md-4 col-xl-2"><label class="form-label">ID usuario</label><input class="form-control" type="number" min="1" name="usuario_id" value="<?= $filters['usuario_id'] ?: '' ?>"></div>
<div class="col-md-4 col-xl-3"><label class="form-label">Usuario</label><input class="form-control" name="usuario" value="<?= ad_e($filters['usuario']) ?>" placeholder="Nombre o correo"></div>
<div class="col-md-4 col-xl-2"><label class="form-label">IP</label><input class="form-control" name="ip" value="<?= ad_e($filters['ip']) ?>"></div>
<div class="col-md-4 col-xl-2"><label class="form-label">Estado sesión</label><select class="form-select" name="sesion_estado"><option value="">Todos</option><?php foreach(['ABIERTA'=>'Activa','INACTIVA'=>'Inactiva','CERRADA'=>'Cerrada'] as $value=>$label): ?><option value="<?= $value ?>" <?= $filters['sesion_estado']===$value?'selected':'' ?>><?= $label ?></option><?php endforeach; ?></select></div>
<div class="col-md-4 col-xl-3"><label class="form-label">Búsqueda libre</label><input class="form-control" name="q" value="<?= ad_e($filters['q']) ?>" placeholder="Usuario, ruta, módulo, IP o sesión"></div>
<div class="col-md-4 col-xl-2"><label class="form-label">Límite</label><select class="form-select" name="limit"><?php foreach([25,50,100,200] as $limit): ?><option value="<?= $limit ?>" <?= $filters['limit']===$limit?'selected':'' ?>><?= $limit ?></option><?php endforeach; ?></select></div>
<div class="col-md-8 col-xl-4 d-flex gap-2 align-items-end"><button class="btn btn-primary flex-grow-1">Filtrar</button><a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('auditoria/detalle.php')) ?>">Limpiar</a></div>
</div></form>

<?php $m=$report['metrics']; $cards=[['Eventos',$m['eventos']??0,'primary'],['Usuarios únicos',$m['usuarios']??0,'success'],['Módulos únicos',$m['modulos']??0,'info'],['IP únicas',$m['ips']??0,'warning'],['Logins exitosos',$m['ingresos_exitosos']??0,'success'],['Logins fallidos',$m['ingresos_fallidos']??0,'warning'],['Páginas vistas',$m['vistas']??0,'primary'],['Denegados',$m['denegados']??0,'danger']]; ?>
<div class="audit-kpi-grid mb-3"><?php foreach($cards as $card): ?><div class="audit-kpi audit-kpi-<?= ad_e($card[2]) ?>"><div class="small text-muted"><?= ad_e($card[0]) ?></div><strong><?= number_format((int)$card[1],0,',','.') ?></strong></div><?php endforeach; ?></div>

<div class="row g-3 mb-3"><div class="col-lg-6"><div class="card card-kpi h-100"><div class="card-header fw-semibold">Módulos con mayor uso</div><div class="list-group list-group-flush"><?php foreach($report['top_modules'] as $row): ?><div class="list-group-item d-flex justify-content-between"><span><?= ad_e($row['etiqueta']) ?></span><span class="badge text-bg-primary"><?= number_format((int)$row['total'],0,',','.') ?></span></div><?php endforeach; ?><?php if(!$report['top_modules']): ?><div class="p-3 text-muted">Sin datos.</div><?php endif; ?></div></div></div><div class="col-lg-6"><div class="card card-kpi h-100"><div class="card-header fw-semibold">Usuarios con mayor actividad</div><div class="list-group list-group-flush"><?php foreach($report['top_users'] as $row): ?><div class="list-group-item d-flex justify-content-between"><span><?= ad_e($row['etiqueta']) ?></span><span class="badge text-bg-primary"><?= number_format((int)$row['total'],0,',','.') ?></span></div><?php endforeach; ?><?php if(!$report['top_users']): ?><div class="p-3 text-muted">Sin datos.</div><?php endif; ?></div></div></div></div>

<div class="card card-kpi"><div class="card-header d-flex flex-wrap justify-content-between gap-2"><span class="fw-semibold">Registros</span><span class="small text-muted">Página <?= (int)$report['page'] ?> de <?= (int)$report['pages'] ?> · <?= number_format((int)$report['total'],0,',','.') ?> eventos</span></div><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0 audit-table"><thead><tr><th>Fecha</th><th>Evento</th><th>Usuario</th><th>Rol</th><th>Módulo / ruta</th><th>Método</th><th>IP</th><th>Sesión</th><th>HTTP</th></tr></thead><tbody>
<?php if(!$report['rows']): ?><tr><td colspan="9" class="text-muted p-4">No se encontraron registros con estos filtros.</td></tr><?php endif; ?>
<?php foreach($report['rows'] as $row): ?><tr><td class="text-nowrap"><?= ad_e($row['created_at']) ?></td><td><span class="badge text-bg-<?= $row['evento']==='ACCESS_DENIED'?'danger':($row['evento']==='LOGIN_SUCCESS'?'success':($row['evento']==='LOGIN_FAILED'?'warning':'light')) ?>"><?= ad_e($row['evento']) ?></span></td><td><strong><?= ad_e($row['usuario_nombre'] ?: 'Anónimo') ?></strong><div class="small text-muted"><?= ad_e($row['usuario_email']) ?><?= $row['usuario_id'] ? ' · ID ' . (int)$row['usuario_id'] : '' ?></div></td><td><?= ad_e($row['rol'] ?: '—') ?></td><td><strong><?= ad_e($row['modulo'] ?: '—') ?></strong><div class="small text-muted audit-route" title="<?= ad_e($row['ruta']) ?>"><?= ad_e($row['ruta']) ?></div></td><td><?= ad_e($row['metodo']) ?></td><td><?= ad_e($row['ip'] ?: '—') ?></td><td class="audit-session-cell"><code class="audit-session-hash" title="Seleccione para copiar el identificador completo"><?= ad_e($row['session_hash']) ?></code><div class="small text-muted"><?= ad_e($row['sesion_estado'] ?: '—') ?></div></td><td><?= (int)$row['codigo_http'] ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php if($report['pages']>1): ?><div class="card-footer d-flex justify-content-between"><a class="btn btn-sm btn-outline-primary <?= $report['page']<=1?'disabled':'' ?>" href="<?= ad_e(ad_url('auditoria/detalle.php?' . http_build_query(array_merge($query,['page'=>max(1,$report['page']-1)])))) ?>">Anterior</a><a class="btn btn-sm btn-outline-primary <?= $report['page']>=$report['pages']?'disabled':'' ?>" href="<?= ad_e(ad_url('auditoria/detalle.php?' . http_build_query(array_merge($query,['page'=>min($report['pages'],$report['page']+1)])))) ?>">Siguiente</a></div><?php endif; ?>
</div>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
