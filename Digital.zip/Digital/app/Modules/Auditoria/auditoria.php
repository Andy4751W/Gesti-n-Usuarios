<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('auditoria.ver');
$pdo = db();
$filters = SessionAuditReportService::filters($_GET);
$report = SessionAuditReportService::general($pdo, $filters);
$metrics = $report['metrics'];
$title = 'Auditoría de sesiones';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h1 class="h3 mb-1">Auditoría de sesiones</h1><div class="text-muted">Control de accesos, actividad y sesiones de los usuarios.</div></div>
    <span class="badge text-bg-dark px-3 py-2">Actualizado <?= ad_e(date('Y-m-d H:i:s')) ?></span>
</div>

<ul class="nav nav-tabs audit-tabs mb-3">
    <li class="nav-item"><a class="nav-link active" href="<?= ad_e(ad_url('auditoria/auditoria.php')) ?>">Uso general</a></li>
    <li class="nav-item"><a class="nav-link" href="<?= ad_e(ad_url('auditoria/detalle.php')) ?>">Auditoría detallada</a></li>
</ul>

<form class="module-filter-card mb-3" method="get">
    <div class="row g-2 align-items-end">
        <div class="col-md-4"><label class="form-label">Desde</label><input class="form-control" type="date" name="desde" value="<?= ad_e($filters['desde']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Hasta</label><input class="form-control" type="date" name="hasta" value="<?= ad_e($filters['hasta']) ?>"></div>
        <div class="col-md-4 d-grid"><button class="btn btn-primary">Actualizar periodo</button></div>
    </div>
</form>

<?php
$cards = [
    ['Usuarios activos en el periodo', (int)($metrics['usuarios'] ?? 0), 'de ' . (int)$metrics['usuarios_registrados'] . ' usuarios habilitados', 'primary'],
    ['Módulos observados', (int)($metrics['modulos'] ?? 0), 'secciones diferentes consultadas', 'info'],
    ['Inicios de sesión exitosos', (int)($metrics['ingresos_exitosos'] ?? 0), (int)($metrics['ingresos_fallidos'] ?? 0) . ' intentos fallidos', 'success'],
    ['Eventos auditados', (int)($metrics['eventos'] ?? 0), 'consultas y acciones protegidas', 'secondary'],
    ['Eventos GET', (int)($metrics['eventos_get'] ?? 0), 'aperturas y consultas', 'primary'],
    ['Eventos POST', (int)($metrics['eventos_post'] ?? 0), 'procesos y acciones', 'warning'],
    ['Accesos denegados', (int)($metrics['denegados'] ?? 0), 'intentos sin autorización', 'danger'],
    ['Sesiones activas ahora', (int)($metrics['sesiones_activas'] ?? 0), 'actividad durante los últimos 30 minutos', 'success'],
];
?>
<div class="audit-kpi-grid mb-3">
<?php foreach ($cards as $card): ?>
    <div class="audit-kpi audit-kpi-<?= ad_e($card[3]) ?>"><div class="small text-muted"><?= ad_e($card[0]) ?></div><strong><?= number_format($card[1], 0, ',', '.') ?></strong><div class="small text-muted"><?= ad_e($card[2]) ?></div></div>
<?php endforeach; ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-7"><div class="card card-kpi h-100"><div class="card-header fw-semibold">Actividad diaria</div><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0"><thead><tr><th>Fecha</th><th class="text-end">Usuarios</th><th class="text-end">Módulos</th><th class="text-end">Eventos</th></tr></thead><tbody>
    <?php if (!$report['daily']): ?><tr><td colspan="4" class="text-muted p-3">Aún no hay actividad registrada en el periodo.</td></tr><?php endif; ?>
    <?php foreach ($report['daily'] as $row): ?><tr><td><?= ad_e($row['fecha']) ?></td><td class="text-end"><?= number_format((int)$row['usuarios'],0,',','.') ?></td><td class="text-end"><?= number_format((int)$row['modulos'],0,',','.') ?></td><td class="text-end fw-semibold"><?= number_format((int)$row['eventos'],0,',','.') ?></td></tr><?php endforeach; ?>
    </tbody></table></div></div></div>
    <div class="col-xl-5"><div class="card card-kpi h-100"><div class="card-header fw-semibold">Accesos denegados por módulo</div><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0"><thead><tr><th>Módulo</th><th class="text-end">Denegados</th></tr></thead><tbody>
    <?php if (!$report['denied']): ?><tr><td colspan="2" class="text-muted p-3">No se registraron accesos denegados.</td></tr><?php endif; ?>
    <?php foreach ($report['denied'] as $row): ?><tr><td><?= ad_e($row['modulo']) ?></td><td class="text-end"><span class="badge text-bg-danger"><?= number_format((int)$row['total'],0,',','.') ?></span></td></tr><?php endforeach; ?>
    </tbody></table></div></div></div>
</div>

<div class="card card-kpi"><div class="card-header d-flex justify-content-between align-items-center"><span class="fw-semibold">Sesiones recientes</span><span class="small text-muted">Activa: actividad en los últimos 30 minutos</span></div><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0 audit-sessions-table"><thead><tr><th>Usuario</th><th>Rol</th><th>IP</th><th>Inicio</th><th>Última actividad</th><th>Estado</th><th>Sesión</th></tr></thead><tbody>
<?php if (!$report['sessions']): ?><tr><td colspan="7" class="text-muted p-3">Aún no hay sesiones registradas.</td></tr><?php endif; ?>
<?php foreach ($report['sessions'] as $session): ?>
<?php $active = $session['estado']==='ABIERTA' && strtotime((string)$session['ultima_actividad_at']) >= time()-1800; $status = $session['estado']==='CERRADA' ? 'Cerrada' : ($active ? 'Activa' : 'Inactiva'); ?>
<tr><td><strong><?= ad_e($session['usuario_nombre'] ?: 'Sin identificar') ?></strong><div class="small text-muted"><?= ad_e($session['usuario_email']) ?></div></td><td><?= ad_e($session['rol'] ?: '—') ?></td><td><?= ad_e($session['ip'] ?: '—') ?></td><td><?= ad_e($session['iniciada_at']) ?></td><td><?= ad_e($session['ultima_actividad_at']) ?></td><td><span class="badge text-bg-<?= $status==='Activa'?'success':($status==='Cerrada'?'secondary':'warning') ?>"><?= ad_e($status) ?></span></td><td class="audit-session-cell"><code class="audit-session-hash" title="Seleccione para copiar el identificador completo"><?= ad_e($session['session_hash']) ?></code></td></tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
