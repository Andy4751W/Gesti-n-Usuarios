<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/bootstrap.php';
ad_require_permission('usuarios.administrar');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Método no permitido.');}
ad_verify_csrf();
$id=max(0,(int)($_POST['id']??0));
try{
    $pdo=db();$statement=$pdo->prepare('SELECT * FROM ad_clientes_dashboard WHERE id=:id LIMIT 1');$statement->execute([':id'=>$id]);$before=$statement->fetch(PDO::FETCH_ASSOC);
    if(!$before){throw new RuntimeException('El cliente no existe.');}
    if(!ad_is_valid_dashboard_client((string)$before['nombre'])){throw new RuntimeException('Los valores pendientes de reasignación no pueden activarse como clientes.');}
    $active=(int)$before['activo']===1?0:1;$pdo->prepare('UPDATE ad_clientes_dashboard SET activo=:activo WHERE id=:id')->execute([':activo'=>$active,':id'=>$id]);
    AuditService::log($pdo,'CLIENTE_DASHBOARD',$id,$active?'ACTIVAR':'INACTIVAR',$before,array_merge($before,['activo'=>$active]));
    ad_flash('success',$active?'Cliente activado.':'Cliente inactivado. Sus asignaciones se conservaron.');
}catch(Throwable $e){ad_flash('danger',$e->getMessage());}
ad_redirect('usuarios/usuarios.php');
