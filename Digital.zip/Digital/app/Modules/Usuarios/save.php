<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('usuarios.administrar');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método no permitido.'); }
ad_verify_csrf();

$pdo = db();
$id = max(0,(int)($_POST['id'] ?? 0));
$name = trim((string)($_POST['nombre'] ?? ''));
$email = ad_email_normalize((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$role = mb_strtoupper(trim((string)($_POST['rol'] ?? 'CONSULTOR')),'UTF-8');
$active = isset($_POST['activo']) ? 1 : 0;
$roles = ['ADMIN','TECNICO','CONSULTOR'];

try {
    if ($name === '' || mb_strlen($name,'UTF-8') > 180) { throw new RuntimeException('Ingrese un nombre válido.'); }
    if (!filter_var($email,FILTER_VALIDATE_EMAIL) || mb_strlen($email,'UTF-8') > 190) { throw new RuntimeException('Ingrese un correo válido.'); }
    if (!in_array($role,$roles,true)) { throw new RuntimeException('El rol indicado no es válido.'); }
    if ($id===0 && strlen($password)<8) { throw new RuntimeException('La contraseña debe tener al menos 8 caracteres.'); }
    if ($password!=='' && strlen($password)<8) { throw new RuntimeException('La nueva contraseña debe tener al menos 8 caracteres.'); }

    $before = null;
    if ($id>0) {
        $statement=$pdo->prepare('SELECT id,nombre,email,rol,activo,todos_clientes_dashboard FROM ad_usuarios WHERE id=:id LIMIT 1');
        $statement->execute([':id'=>$id]);
        $before=$statement->fetch(PDO::FETCH_ASSOC);
        if (!$before) { throw new RuntimeException('El usuario que intenta modificar no existe.'); }
        if ($id===(int)ad_current_user_id() && ($role!=='ADMIN' || $active!==1)) { throw new RuntimeException('No puede retirar su propio rol de administrador ni inactivar su usuario.'); }
    }

    $duplicate=$pdo->prepare('SELECT id FROM ad_usuarios WHERE email=:email AND id<>:id LIMIT 1');
    $duplicate->execute([':email'=>$email,':id'=>$id]);
    if ($duplicate->fetchColumn()!==false) { throw new RuntimeException('El correo ya está registrado en otro usuario.'); }

    $pdo->beginTransaction();
    if ($id===0) {
        $statement=$pdo->prepare('INSERT INTO ad_usuarios (nombre,email,password_hash,rol,activo,todos_clientes_dashboard) VALUES (:nombre,:email,:password,:rol,:activo,:todos)');
        $statement->execute([':nombre'=>$name,':email'=>$email,':password'=>password_hash($password,PASSWORD_DEFAULT),':rol'=>$role,':activo'=>$active,':todos'=>$role==='ADMIN'?1:0]);
        $id=(int)$pdo->lastInsertId();
    } else {
        $sql='UPDATE ad_usuarios SET nombre=:nombre,email=:email,rol=:rol,activo=:activo';
        $parameters=[':nombre'=>$name,':email'=>$email,':rol'=>$role,':activo'=>$active,':id'=>$id];
        if ($password!=='') { $sql.=',password_hash=:password'; $parameters[':password']=password_hash($password,PASSWORD_DEFAULT); }
        $sql.=' WHERE id=:id';
        $statement=$pdo->prepare($sql);$statement->execute($parameters);
    }

    $permissionRows=$pdo->query("SELECT id,codigo FROM ad_permisos WHERE activo=1 AND (modulo <> 'Novedades' OR codigo='novedades.ver') AND codigo NOT IN ('dashboard.ver','resumen.ver') AND modulo <> 'Dashboard' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $validCodes=array_column($permissionRows,'codigo');
    $selectedInput=is_array($_POST['permisos'] ?? null)?$_POST['permisos']:[];
    $selected=array_values(array_intersect($validCodes,array_map('strval',$selectedInput)));
    $pdo->prepare('DELETE FROM ad_usuario_permisos WHERE usuario_id=:id')->execute([':id'=>$id]);
    if ($role!=='ADMIN') {
        $insertPermission=$pdo->prepare('INSERT INTO ad_usuario_permisos (usuario_id,permiso_id,permitido,updated_by) VALUES (:usuario,:permiso,:permitido,:autor)');
        foreach($permissionRows as $permission) {
            $insertPermission->execute([':usuario'=>$id,':permiso'=>(int)$permission['id'],':permitido'=>in_array($permission['codigo'],$selected,true)?1:0,':autor'=>ad_current_user_id()]);
        }
    }

    $allClients = $role === 'ADMIN'
        || ($role !== 'CONSULTOR' && isset($_POST['todos_clientes']));
    $pdo->prepare('UPDATE ad_usuarios SET todos_clientes_dashboard=:todos WHERE id=:id')->execute([':todos'=>$allClients?1:0,':id'=>$id]);
    $pdo->prepare('DELETE FROM ad_usuario_clientes_dashboard WHERE usuario_id=:id')->execute([':id'=>$id]);
    if (!$allClients) {
        $clientIds=array_values(array_unique(array_filter(array_map('intval',is_array($_POST['clientes'] ?? null)?$_POST['clientes']:[]))));
        if ($clientIds) {
            $availableRows = $pdo->query('SELECT id,nombre FROM ad_clientes_dashboard WHERE activo=1')->fetchAll(PDO::FETCH_ASSOC);
            $available=[];
            foreach ($availableRows as $availableRow) {
                if (ad_is_valid_dashboard_client((string)$availableRow['nombre'])) {
                    $available[] = (int)$availableRow['id'];
                }
            }
            $insertClient=$pdo->prepare('INSERT INTO ad_usuario_clientes_dashboard (usuario_id,cliente_id,updated_by) VALUES (:usuario,:cliente,:autor)');
            foreach($clientIds as $clientId) { if(in_array($clientId,$available,true)){$insertClient->execute([':usuario'=>$id,':cliente'=>$clientId,':autor'=>ad_current_user_id()]);} }
        }
    }

    $after=['nombre'=>$name,'email'=>$email,'rol'=>$role,'activo'=>$active,'permisos'=>$role==='ADMIN'?['*']:$selected,'todos_clientes'=>$allClients];
    AuditService::log($pdo,'USUARIO',$id,$before?'ACTUALIZAR_PERMISOS':'CREAR',$before?:null,$after);
    $pdo->commit();
    ad_flash('success',$before?'Usuario y permisos actualizados.':'Usuario creado correctamente.');
} catch(Throwable $e) {
    if($pdo->inTransaction()){$pdo->rollBack();}
    ad_flash('danger',$e->getMessage());
    ad_redirect('usuarios/form.php'.($id>0?'?id='.$id:''));
}
ad_redirect('usuarios/usuarios.php');
