<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/bootstrap.php';
ad_require_permission('usuarios.administrar');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Método no permitido.');}
ad_verify_csrf();
$name=trim((string)($_POST['nombre']??''));
$code=mb_strtoupper(trim((string)($_POST['codigo']??'')),'UTF-8');
$code=preg_replace('/[^A-Z0-9_]+/','_',$code)??'';$code=trim($code,'_');
try{
    if(!ad_is_valid_dashboard_client($name)||mb_strlen($name,'UTF-8')>150||$code===''||strlen($code)>80){throw new RuntimeException('Ingrese un código y un nombre de cliente válidos.');}
    $pdo=db();$statement=$pdo->prepare('INSERT INTO ad_clientes_dashboard (codigo,nombre,activo) VALUES (:codigo,:nombre,1)');$statement->execute([':codigo'=>$code,':nombre'=>$name]);
    $id=(int)$pdo->lastInsertId();AuditService::log($pdo,'CLIENTE_DASHBOARD',$id,'CREAR',null,['codigo'=>$code,'nombre'=>$name,'activo'=>1]);
    ad_flash('success','Cliente agregado al catálogo de informes.');
}catch(Throwable $e){ad_flash('danger',$e instanceof PDOException?'El código o el nombre del cliente ya existe.':$e->getMessage());}
ad_redirect('usuarios/usuarios.php');
