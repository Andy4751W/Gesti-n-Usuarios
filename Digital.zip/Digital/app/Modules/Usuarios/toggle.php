<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/bootstrap.php';
ad_require_permission('usuarios.administrar');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Método no permitido.');}
ad_verify_csrf();
$id=max(0,(int)($_POST['id']??0));
if($id<=0||$id===(int)ad_current_user_id()){ad_flash('danger','No puede modificar el estado de este usuario.');ad_redirect('usuarios/usuarios.php');}
try{
    $pdo=db();
    $statement=$pdo->prepare('SELECT id,nombre,email,rol,activo FROM ad_usuarios WHERE id=:id LIMIT 1');$statement->execute([':id'=>$id]);$before=$statement->fetch(PDO::FETCH_ASSOC);
    if(!$before){throw new RuntimeException('El usuario no existe.');}
    $active=(int)$before['activo']===1?0:1;
    $pdo->prepare('UPDATE ad_usuarios SET activo=:activo WHERE id=:id')->execute([':activo'=>$active,':id'=>$id]);
    AuditService::log($pdo,'USUARIO',$id,$active?'ACTIVAR':'INACTIVAR',$before,array_merge($before,['activo'=>$active]));
    ad_flash('success',$active?'Usuario activado.':'Usuario inactivado; no podrá volver a iniciar sesión.');
}catch(Throwable $e){ad_flash('danger',$e->getMessage());}
ad_redirect('usuarios/usuarios.php');
