<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('usuarios.administrar');
$pdo = db();
(new ClientDashboardService($pdo))->syncClientCatalogFromProfiles();
$id = max(0, (int)($_GET['id'] ?? 0));
$userRow = null;
if ($id > 0) {
    $statement = $pdo->prepare('SELECT * FROM ad_usuarios WHERE id=:id LIMIT 1');
    $statement->execute([':id'=>$id]);
    $userRow = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$userRow) { ad_flash('danger','El usuario no existe.'); ad_redirect('usuarios/usuarios.php'); }
}
$role = (string)($userRow['rol'] ?? 'CONSULTOR');
$permissions = $pdo->query("SELECT * FROM ad_permisos WHERE activo=1 AND (modulo <> 'Novedades' OR codigo='novedades.ver') AND codigo NOT IN ('dashboard.ver','resumen.ver') AND modulo <> 'Dashboard' ORDER BY orden,modulo,nombre")->fetchAll(PDO::FETCH_ASSOC);
$overrideStatement = $pdo->prepare("SELECT p.codigo,up.permitido FROM ad_usuario_permisos up INNER JOIN ad_permisos p ON p.id=up.permiso_id WHERE up.usuario_id=:id AND (p.modulo <> 'Novedades' OR p.codigo='novedades.ver') AND p.codigo NOT IN ('dashboard.ver','resumen.ver') AND p.modulo <> 'Dashboard'");
$overrideStatement->execute([':id'=>$id]);
$overrides = [];
foreach ($overrideStatement->fetchAll(PDO::FETCH_ASSOC) as $override) { $overrides[$override['codigo']] = (int)$override['permitido']===1; }
$basePermissions = (ad_config('roles')[$role] ?? []);
$selectedPermissions = [];
foreach ($permissions as $permission) {
    $code = (string)$permission['codigo'];
    if ($role === 'ADMIN' || in_array('*',$basePermissions,true) || ($overrides[$code] ?? in_array($code,$basePermissions,true))) { $selectedPermissions[]=$code; }
}
$clients = array_values(array_filter(
    $pdo->query('SELECT * FROM ad_clientes_dashboard WHERE activo=1 ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC),
    static function (array $client): bool { return ad_is_valid_dashboard_client((string)$client['nombre']); }
));
$clientStatement = $pdo->prepare('SELECT cliente_id FROM ad_usuario_clientes_dashboard WHERE usuario_id=:id');
$clientStatement->execute([':id'=>$id]);
$selectedClients = array_map('intval',$clientStatement->fetchAll(PDO::FETCH_COLUMN));
$allClients = $role === 'ADMIN'
    || ($role !== 'CONSULTOR' && (int)($userRow['todos_clientes_dashboard'] ?? 0) === 1);
$permissionGroups = [];
foreach ($permissions as $permission) { $permissionGroups[$permission['modulo']][]=$permission; }
$roleDefaults = [];
foreach (['ADMIN','TECNICO','CONSULTOR'] as $roleName) {
    $defaults = ad_config('roles')[$roleName] ?? [];
    $roleDefaults[$roleName] = in_array('*',$defaults,true) ? array_column($permissions,'codigo') : array_values($defaults);
}
$title = $id>0 ? 'Editar usuario' : 'Nuevo usuario';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h1 class="h3 mb-1"><?= $id>0?'Editar usuario y permisos':'Crear usuario' ?></h1><div class="text-muted">El rol define una base que puede personalizarse para este usuario.</div></div><a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('usuarios/usuarios.php')) ?>">Volver</a></div>
<form method="post" action="<?= ad_e(ad_url('usuarios/save.php')) ?>" id="userForm">
<input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>">
<div class="card card-kpi mb-3"><div class="card-header fw-semibold">1. Información del usuario</div><div class="card-body"><div class="row g-3">
<div class="col-md-5"><label class="form-label">Nombre completo *</label><input class="form-control" name="nombre" maxlength="180" required value="<?= ad_e($userRow['nombre'] ?? '') ?>"></div>
<div class="col-md-4"><label class="form-label">Correo *</label><input class="form-control" type="email" name="email" maxlength="190" required value="<?= ad_e($userRow['email'] ?? '') ?>"></div>
<div class="col-md-3"><label class="form-label">Rol base *</label><select class="form-select" name="rol" id="roleSelect" <?= $id===(int)ad_current_user_id()?'disabled':'' ?>><?php foreach(['ADMIN'=>'Administrador','TECNICO'=>'Técnico','CONSULTOR'=>'Consultor'] as $value=>$label): ?><option value="<?= $value ?>" <?= $role===$value?'selected':'' ?>><?= $label ?></option><?php endforeach; ?></select><?php if($id===(int)ad_current_user_id()): ?><input type="hidden" name="rol" value="<?= ad_e($role) ?>"><?php endif; ?></div>
<div class="col-md-5"><label class="form-label"><?= $id>0?'Nueva contraseña (opcional)':'Contraseña *' ?></label><input class="form-control" type="password" name="password" minlength="8" <?= $id>0?'':'required' ?> autocomplete="new-password"><div class="form-text">Mínimo 8 caracteres. Déjela vacía para conservar la actual.</div></div>
<div class="col-md-3"><div class="form-check form-switch mt-4"><input class="form-check-input" type="checkbox" name="activo" value="1" id="activeUser" <?= !$userRow || (int)$userRow['activo']===1?'checked':'' ?> <?= $id===(int)ad_current_user_id()?'disabled':'' ?>><label class="form-check-label" for="activeUser">Usuario activo</label></div><?php if($id===(int)ad_current_user_id()): ?><input type="hidden" name="activo" value="1"><?php endif; ?></div>
<div class="col-md-4 d-grid align-items-end"><button type="button" class="btn btn-outline-primary mt-auto" id="applyRole">Aplicar permisos base del rol</button></div>
</div></div></div>

<div class="card card-kpi mb-3"><div class="card-header fw-semibold">2. Permisos particulares</div><div class="card-body"><div class="alert alert-info">Puede agregar o retirar permisos sin eliminar el usuario. El Administrador siempre conserva acceso total.</div><div class="row g-3">
<?php foreach($permissionGroups as $module=>$items): ?><div class="col-lg-4 col-md-6"><div class="border rounded p-3 h-100"><div class="fw-semibold mb-2"><?= ad_e($module) ?></div><?php foreach($items as $permission): ?><div class="form-check mb-2"><input class="form-check-input permission-check" type="checkbox" name="permisos[]" value="<?= ad_e($permission['codigo']) ?>" id="permission_<?= (int)$permission['id'] ?>" <?= in_array($permission['codigo'],$selectedPermissions,true)?'checked':'' ?> <?= $role==='ADMIN'?'disabled':'' ?>><label class="form-check-label" for="permission_<?= (int)$permission['id'] ?>"><strong><?= ad_e($permission['nombre']) ?></strong><span class="d-block small text-muted"><?= ad_e($permission['descripcion']) ?></span></label></div><?php endforeach; ?></div></div><?php endforeach; ?>
</div></div></div>

<div class="card card-kpi mb-3"><div class="card-header fw-semibold">3. Clientes visibles en informes</div><div class="card-body"><div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="todos_clientes" value="1" id="allClients" <?= $allClients?'checked':'' ?> <?= $role==='ADMIN'||$role==='CONSULTOR'?'disabled':'' ?>><label class="form-check-label" for="allClients">Puede ver informes de todos los clientes</label></div><?php if($role==='ADMIN'): ?><input type="hidden" name="todos_clientes" value="1"><?php endif; ?><div class="row g-2" id="clientList"><?php foreach($clients as $client): ?><div class="col-lg-3 col-md-4 col-6"><div class="form-check border rounded p-2 ps-4"><input class="form-check-input client-check" type="checkbox" name="clientes[]" value="<?= (int)$client['id'] ?>" id="client_<?= (int)$client['id'] ?>" <?= in_array((int)$client['id'],$selectedClients,true)?'checked':'' ?>><label class="form-check-label" for="client_<?= (int)$client['id'] ?>"><?= ad_e($client['nombre']) ?></label></div></div><?php endforeach; ?></div><div class="form-text mt-2">Los clientes provienen de SHAREPOINT → CU3-CLIENTE. Para CONSULTOR, marque únicamente los clientes que podrá consultar.</div></div></div>
<div class="d-flex gap-2"><button class="btn btn-primary">Guardar usuario y permisos</button><a class="btn btn-outline-secondary" href="<?= ad_e(ad_url('usuarios/usuarios.php')) ?>">Cancelar</a></div>
</form>
<script>
(function(){
const defaults=<?= json_encode($roleDefaults,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
const role=document.getElementById('roleSelect');const checks=[...document.querySelectorAll('.permission-check')];const all=document.getElementById('allClients');const clients=[...document.querySelectorAll('.client-check')];
function clientState(){clients.forEach(function(item){item.disabled=all.checked;});}
function roleState(){const isAdmin=role.value==='ADMIN';const isConsultant=role.value==='CONSULTOR';checks.forEach(function(item){item.disabled=isAdmin;if(isAdmin)item.checked=true;});all.disabled=isAdmin||isConsultant;if(isAdmin)all.checked=true;if(isConsultant)all.checked=false;clientState();}
document.getElementById('applyRole').addEventListener('click',function(){const allowed=defaults[role.value]||[];checks.forEach(function(item){item.checked=allowed.indexOf(item.value)!==-1;});if(role.value==='ADMIN')all.checked=true;roleState();});
role.addEventListener('change',roleState);all.addEventListener('change',clientState);roleState();
})();
</script>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
