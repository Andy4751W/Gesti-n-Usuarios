<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/bootstrap.php';
ad_require_permission('usuarios.administrar');

$pdo = db();
(new ClientDashboardService($pdo))->syncClientCatalogFromProfiles();
$search = trim((string)($_GET['q'] ?? ''));
$where = '';
$parameters = [];
if ($search !== '') {
    $where = 'WHERE u.nombre LIKE :q OR u.email LIKE :q OR u.rol LIKE :q';
    $parameters[':q'] = '%' . $search . '%';
}
$statement = $pdo->prepare(
    'SELECT u.*,
        (SELECT COUNT(*) FROM ad_usuario_permisos up WHERE up.usuario_id=u.id AND up.permitido=1) permisos_activos,
        (SELECT COUNT(*) FROM ad_usuario_permisos up WHERE up.usuario_id=u.id) permisos_personalizados,
        (SELECT GROUP_CONCAT(c.nombre ORDER BY c.nombre SEPARATOR ", ")
         FROM ad_usuario_clientes_dashboard uc
         INNER JOIN ad_clientes_dashboard c ON c.id=uc.cliente_id
         WHERE uc.usuario_id=u.id AND c.activo=1) clientes
     FROM ad_usuarios u ' . $where . '
     ORDER BY FIELD(u.rol,"ADMIN","TECNICO","CONSULTOR"),u.nombre'
);
$statement->execute($parameters);
$users = $statement->fetchAll(PDO::FETCH_ASSOC);
$clients = $pdo->query(
    'SELECT c.*,
        (SELECT COUNT(*) FROM ad_usuario_clientes_dashboard uc WHERE uc.cliente_id=c.id) usuarios_asignados
     FROM ad_clientes_dashboard c WHERE c.activo=1 ORDER BY c.nombre'
)->fetchAll(PDO::FETCH_ASSOC);
$clients = array_values(array_filter($clients, static function (array $client): bool {
    return ad_is_valid_dashboard_client((string)$client['nombre']);
}));

$title = 'Usuarios y permisos';
require dirname(__DIR__, 2) . '/Views/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div><h1 class="h3 mb-1">Usuarios y permisos</h1><div class="text-muted">Administre accesos funcionales y visibilidad de informes por cliente.</div></div>
    <a class="btn btn-primary" href="<?= ad_e(ad_url('usuarios/form.php')) ?>">Nuevo usuario</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="audit-kpi audit-kpi-primary"><div class="small text-muted">Administradores</div><strong><?= count(array_filter($users, static function(array $u): bool { return $u['rol']==='ADMIN'; })) ?></strong><div class="small text-muted">Acceso general</div></div></div>
    <div class="col-md-4"><div class="audit-kpi audit-kpi-success"><div class="small text-muted">Técnicos</div><strong><?= count(array_filter($users, static function(array $u): bool { return $u['rol']==='TECNICO'; })) ?></strong><div class="small text-muted">Consulta y gestión</div></div></div>
    <div class="col-md-4"><div class="audit-kpi audit-kpi-info"><div class="small text-muted">Consultores</div><strong><?= count(array_filter($users, static function(array $u): bool { return $u['rol']==='CONSULTOR'; })) ?></strong><div class="small text-muted">Consulta controlada</div></div></div>
</div>

<form class="module-filter-card mb-3" method="get"><div class="row g-2"><div class="col-md-9"><label class="form-label">Buscar usuario</label><input class="form-control" name="q" value="<?= ad_e($search) ?>" placeholder="Nombre, correo o rol"></div><div class="col-md-3 d-grid align-items-end"><button class="btn btn-dark mt-auto">Buscar</button></div></div></form>

<div class="card card-kpi mb-4">
    <div class="card-header fw-semibold">Usuarios registrados</div>
    <div class="table-responsive"><table class="table table-hover align-middle mb-0" style="min-width:1100px"><thead><tr><th>Usuario</th><th>Rol base</th><th>Permisos</th><th>Informes permitidos</th><th>Último acceso</th><th>Estado</th><th class="text-end">Acciones</th></tr></thead><tbody>
    <?php if (!$users): ?><tr><td colspan="7" class="text-muted p-4">No se encontraron usuarios.</td></tr><?php endif; ?>
    <?php foreach ($users as $item): ?>
    <tr>
        <td><strong><?= ad_e($item['nombre']) ?></strong><div class="small text-muted"><?= ad_e($item['email']) ?> · ID <?= (int)$item['id'] ?></div></td>
        <td><span class="badge text-bg-<?= $item['rol']==='ADMIN'?'danger':($item['rol']==='TECNICO'?'success':'info') ?>"><?= ad_e($item['rol']) ?></span></td>
        <td><?= $item['rol']==='ADMIN' ? 'Todos' : ((int)$item['permisos_personalizados']>0 ? (int)$item['permisos_activos'].' personalizados' : 'Base del rol') ?></td>
        <td><?= $item['rol']==='ADMIN' || (int)$item['todos_clientes_dashboard']===1 ? '<span class="badge text-bg-primary">Todos los clientes</span>' : ad_e($item['clientes'] ?: 'Sin clientes asignados') ?></td>
        <td class="text-nowrap"><?= ad_e($item['ultimo_acceso'] ?: 'Nunca') ?></td>
        <td><span class="badge text-bg-<?= (int)$item['activo']===1?'success':'secondary' ?>"><?= (int)$item['activo']===1?'Activo':'Inactivo' ?></span></td>
        <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?= ad_e(ad_url('usuarios/form.php?id='.(int)$item['id'])) ?>">Editar permisos</a><?php if ((int)$item['id'] !== (int)ad_current_user_id()): ?><form class="d-inline" method="post" action="<?= ad_e(ad_url('usuarios/toggle.php')) ?>"><input type="hidden" name="_token" value="<?= ad_e(ad_csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-sm btn-outline-<?= (int)$item['activo']===1?'danger':'success' ?>"><?= (int)$item['activo']===1?'Inactivar':'Activar' ?></button></form><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody></table></div>
</div>

<div class="card card-kpi">
    <div class="card-header fw-semibold">Clientes disponibles para informes</div>
    <div class="card-body py-2 small text-muted">Catálogo sincronizado automáticamente con los valores únicos de <strong>SHAREPOINT → CU3-CLIENTE</strong>. Cada valor se conserva como un cliente independiente.</div>
    <div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0"><thead><tr><th>Cliente</th><th>Código</th><th>Usuarios asignados</th></tr></thead><tbody><?php foreach($clients as $client): ?><tr><td><?= ad_e($client['nombre']) ?></td><td><code><?= ad_e($client['codigo']) ?></code></td><td><?= (int)$client['usuarios_asignados'] ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php require dirname(__DIR__, 2) . '/Views/footer.php'; ?>
