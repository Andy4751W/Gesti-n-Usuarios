<?php
declare(strict_types=1);

final class SessionAuditReportService
{
    public static function filters(array $input): array
    {
        $limit = (int)($input['limit'] ?? 50);
        if (!in_array($limit, [25, 50, 100, 200], true)) {
            $limit = 50;
        }
        return [
            'desde' => self::dateValue($input['desde'] ?? null, date('Y-m-d', strtotime('-29 days'))),
            'hasta' => self::dateValue($input['hasta'] ?? null, date('Y-m-d')),
            'evento' => self::text($input['evento'] ?? '', 40),
            'metodo' => self::text($input['metodo'] ?? '', 10),
            'modulo' => self::text($input['modulo'] ?? '', 100),
            'usuario_id' => max(0, (int)($input['usuario_id'] ?? 0)),
            'usuario' => self::text($input['usuario'] ?? '', 190),
            'ip' => self::text($input['ip'] ?? '', 64),
            'sesion_estado' => in_array(($input['sesion_estado'] ?? ''), ['ABIERTA','CERRADA','INACTIVA'], true)
                ? (string)$input['sesion_estado'] : '',
            'q' => self::text($input['q'] ?? '', 190),
            'limit' => $limit,
            'page' => max(1, (int)($input['page'] ?? 1)),
        ];
    }

    public static function detailed(PDO $pdo, array $filters): array
    {
        list($where, $parameters) = self::where($filters);
        $joins = ' FROM ad_auditoria_sesiones e LEFT JOIN ad_sesiones_usuario s ON s.session_hash=e.session_hash ';
        $metricsStatement = $pdo->prepare(
            'SELECT COUNT(*) eventos,COUNT(DISTINCT e.usuario_id) usuarios,
                    COUNT(DISTINCT NULLIF(e.modulo,"")) modulos,COUNT(DISTINCT NULLIF(e.ip,"")) ips,
                    SUM(e.evento="LOGIN_SUCCESS") ingresos_exitosos,
                    SUM(e.evento="LOGIN_FAILED") ingresos_fallidos,
                    SUM(e.evento="PAGE_VIEW") vistas,
                    SUM(e.evento="ACCESS_DENIED") denegados' . $joins . $where
        );
        $metricsStatement->execute($parameters);
        $metrics = $metricsStatement->fetch(PDO::FETCH_ASSOC) ?: [];

        $countStatement = $pdo->prepare('SELECT COUNT(*)' . $joins . $where);
        $countStatement->execute($parameters);
        $total = (int)$countStatement->fetchColumn();
        $pages = max(1, (int)ceil($total / $filters['limit']));
        $page = min($filters['page'], $pages);
        $offset = ($page - 1) * $filters['limit'];

        $rowsStatement = $pdo->prepare(
            'SELECT e.*,s.estado sesion_estado,s.ultima_actividad_at,s.cerrada_at'
            . $joins . $where . ' ORDER BY e.id DESC LIMIT ' . (int)$filters['limit'] . ' OFFSET ' . (int)$offset
        );
        $rowsStatement->execute($parameters);

        return [
            'metrics' => $metrics,
            'rows' => $rowsStatement->fetchAll(PDO::FETCH_ASSOC),
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'top_modules' => self::top($pdo, 'COALESCE(NULLIF(e.modulo,""),"Sin módulo")', $joins, $where, $parameters),
            'top_users' => self::top($pdo, 'COALESCE(NULLIF(e.usuario_nombre,""),NULLIF(e.usuario_email,""),"Anónimo")', $joins, $where, $parameters),
        ];
    }

    public static function exportRows(PDO $pdo, array $filters): array
    {
        list($where, $parameters) = self::where($filters);
        $statement = $pdo->prepare(
            'SELECT e.created_at,e.evento,e.usuario_id,e.usuario_nombre,e.usuario_email,e.rol,
                    e.modulo,e.ruta,e.metodo,e.ip,e.session_hash,e.codigo_http,
                    s.estado sesion_estado,s.ultima_actividad_at,s.cerrada_at
             FROM ad_auditoria_sesiones e
             LEFT JOIN ad_sesiones_usuario s ON s.session_hash=e.session_hash '
             . $where . ' ORDER BY e.id DESC LIMIT 50000'
        );
        $statement->execute($parameters);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function general(PDO $pdo, array $filters): array
    {
        $periodWhere = ' WHERE e.created_at>=:desde AND e.created_at<DATE_ADD(:hasta,INTERVAL 1 DAY)';
        $parameters = [':desde'=>$filters['desde'], ':hasta'=>$filters['hasta']];
        $statement = $pdo->prepare(
            'SELECT COUNT(*) eventos,COUNT(DISTINCT e.usuario_id) usuarios,
                    COUNT(DISTINCT NULLIF(e.modulo,"")) modulos,
                    SUM(e.evento="LOGIN_SUCCESS") ingresos_exitosos,
                    SUM(e.evento="LOGIN_FAILED") ingresos_fallidos,
                    SUM(e.evento="ACCESS_DENIED") denegados,
                    SUM(e.metodo="GET") eventos_get,SUM(e.metodo="POST") eventos_post
             FROM ad_auditoria_sesiones e' . $periodWhere
        );
        $statement->execute($parameters);
        $metrics = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
        $metrics['usuarios_registrados'] = (int)$pdo->query('SELECT COUNT(*) FROM ad_usuarios WHERE activo=1')->fetchColumn();
        $metrics['sesiones_activas'] = (int)$pdo->query(
            'SELECT COUNT(*) FROM ad_sesiones_usuario WHERE estado="ABIERTA"
             AND ultima_actividad_at>=DATE_SUB(NOW(),INTERVAL 30 MINUTE)'
        )->fetchColumn();

        $daily = $pdo->prepare(
            'SELECT DATE(e.created_at) fecha,COUNT(DISTINCT e.usuario_id) usuarios,
                    COUNT(DISTINCT NULLIF(e.modulo,"")) modulos,COUNT(*) eventos
             FROM ad_auditoria_sesiones e' . $periodWhere . '
             GROUP BY DATE(e.created_at) ORDER BY fecha DESC LIMIT 62'
        );
        $daily->execute($parameters);
        $denied = $pdo->prepare(
            'SELECT COALESCE(NULLIF(e.modulo,""),"Sin módulo") modulo,COUNT(*) total
             FROM ad_auditoria_sesiones e' . $periodWhere . ' AND e.evento="ACCESS_DENIED"
             GROUP BY e.modulo ORDER BY total DESC,modulo LIMIT 15'
        );
        $denied->execute($parameters);
        $sessions = $pdo->query(
            'SELECT * FROM ad_sesiones_usuario
             ORDER BY ultima_actividad_at DESC LIMIT 20'
        )->fetchAll(PDO::FETCH_ASSOC);
        return [
            'metrics'=>$metrics,
            'daily'=>$daily->fetchAll(PDO::FETCH_ASSOC),
            'denied'=>$denied->fetchAll(PDO::FETCH_ASSOC),
            'sessions'=>$sessions,
        ];
    }

    public static function events(PDO $pdo): array
    {
        return $pdo->query('SELECT DISTINCT evento FROM ad_auditoria_sesiones ORDER BY evento')->fetchAll(PDO::FETCH_COLUMN);
    }

    private static function where(array $filters): array
    {
        $conditions = ['e.created_at>=:desde','e.created_at<DATE_ADD(:hasta,INTERVAL 1 DAY)'];
        $parameters = [':desde'=>$filters['desde'], ':hasta'=>$filters['hasta']];
        if ($filters['evento'] !== '') {
            $conditions[] = 'e.evento=:evento'; $parameters[':evento'] = $filters['evento'];
        }
        if ($filters['metodo'] !== '') {
            $conditions[] = 'e.metodo=:metodo'; $parameters[':metodo'] = $filters['metodo'];
        }
        if ($filters['modulo'] !== '') {
            $conditions[] = 'e.modulo LIKE :modulo'; $parameters[':modulo'] = '%' . $filters['modulo'] . '%';
        }
        if ($filters['usuario_id'] > 0) {
            $conditions[] = 'e.usuario_id=:usuario_id'; $parameters[':usuario_id'] = $filters['usuario_id'];
        }
        if ($filters['usuario'] !== '') {
            $conditions[] = '(e.usuario_nombre LIKE :usuario_nombre OR e.usuario_email LIKE :usuario_email)';
            $parameters[':usuario_nombre'] = '%' . $filters['usuario'] . '%';
            $parameters[':usuario_email'] = '%' . $filters['usuario'] . '%';
        }
        if ($filters['ip'] !== '') {
            $conditions[] = 'e.ip LIKE :ip'; $parameters[':ip'] = '%' . $filters['ip'] . '%';
        }
        if ($filters['sesion_estado'] === 'ABIERTA') {
            $conditions[] = 's.estado="ABIERTA" AND s.ultima_actividad_at>=DATE_SUB(NOW(),INTERVAL 30 MINUTE)';
        } elseif ($filters['sesion_estado'] === 'INACTIVA') {
            $conditions[] = 's.estado="ABIERTA" AND s.ultima_actividad_at<DATE_SUB(NOW(),INTERVAL 30 MINUTE)';
        } elseif ($filters['sesion_estado'] === 'CERRADA') {
            $conditions[] = 's.estado="CERRADA"';
        }
        if ($filters['q'] !== '') {
            $like = '%' . $filters['q'] . '%';
            $conditions[] = '(e.usuario_nombre LIKE :q1 OR e.usuario_email LIKE :q2 OR e.modulo LIKE :q3
                              OR e.ruta LIKE :q4 OR e.ip LIKE :q5 OR e.evento LIKE :q6 OR e.session_hash LIKE :q7)';
            foreach ([':q1',':q2',':q3',':q4',':q5',':q6',':q7'] as $key) { $parameters[$key] = $like; }
        }
        return [' WHERE ' . implode(' AND ', $conditions), $parameters];
    }

    private static function top(PDO $pdo, string $expression, string $joins, string $where, array $parameters): array
    {
        $statement = $pdo->prepare(
            'SELECT ' . $expression . ' etiqueta,COUNT(*) total' . $joins . $where
            . ' GROUP BY etiqueta ORDER BY total DESC,etiqueta LIMIT 5'
        );
        $statement->execute($parameters);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    private static function dateValue($value, string $default): string
    {
        $value = trim((string)$value);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : $default;
    }

    private static function text($value, int $length): string
    {
        return mb_substr(trim((string)$value), 0, $length, 'UTF-8');
    }
}
