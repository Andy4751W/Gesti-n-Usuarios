<?php
declare(strict_types=1);

final class SessionAuditService
{
    private static $requestRegistered = false;
    private static $suppressRequestEvent = false;

    public static function captureRequest(): void
    {
        if (PHP_SAPI === 'cli' || self::$requestRegistered) {
            return;
        }
        if (preg_match('~/api/session_status\\.php$~', self::route())) {
            return;
        }
        self::$requestRegistered = true;
        register_shutdown_function(static function (): void {
            if (self::$suppressRequestEvent) {
                return;
            }
            $route = self::route();
            $method = self::method();
            if (preg_match('~/login\.php$~', $route)) {
                if ($method === 'GET') {
                    self::log('LOGIN_FORM');
                }
                return;
            }
            if (preg_match('~/logout\.php$~', $route)) {
                return;
            }
            self::log($method === 'GET' ? 'PAGE_VIEW' : 'ACTION');
        });
    }

    public static function loginSuccess(array $user): void
    {
        self::log('LOGIN_SUCCESS', null, $user);
    }

    /**
     * Registra esta sesión como la única sesión activa del usuario. Las
     * sesiones anteriores se cierran antes de abrir la nueva, de modo que un
     * navegador que conserve una cookie deja de estar autenticado en su
     * siguiente solicitud.
     */
    public static function claimUserSession(array $user): void
    {
        $pdo = db();
        $hash = self::sessionHash();
        $startedTransaction = false;
        try {
            if (!$pdo->inTransaction()) {
                $pdo->beginTransaction();
                $startedTransaction = true;
            }

            // Serializa dos inicios de sesión simultáneos del mismo usuario.
            $lock = $pdo->prepare('SELECT id FROM ad_usuarios WHERE id=:id FOR UPDATE');
            $lock->execute([':id' => (int)$user['id']]);

            $close = $pdo->prepare(
                'UPDATE ad_sesiones_usuario
                 SET estado="CERRADA",cerrada_at=NOW(),ultima_actividad_at=NOW()
                 WHERE usuario_id=:usuario AND estado="ABIERTA" AND session_hash<>:hash'
            );
            $close->execute([
                ':usuario' => (int)$user['id'],
                ':hash' => $hash,
            ]);

            self::touchSession($pdo, $hash, self::userSnapshot($user));

            if ($startedTransaction) {
                $pdo->commit();
            }
        } catch (Throwable $exception) {
            if ($startedTransaction && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    public static function currentSessionHash(): string
    {
        return self::sessionHash();
    }

    public static function heartbeat(array $user): void
    {
        try {
            $statement = db()->prepare(
                'UPDATE ad_sesiones_usuario
                 SET ultima_actividad_at=NOW(),updated_at=NOW()
                 WHERE session_hash=:hash AND usuario_id=:usuario AND estado="ABIERTA"'
            );
            $statement->execute([
                ':hash' => self::sessionHash(),
                ':usuario' => (int)$user['id'],
            ]);
        } catch (Throwable $ignored) {
            // El latido no debe interrumpir una solicitud válida.
        }
    }

    public static function loginFailed(string $email): void
    {
        self::log('LOGIN_FAILED', ['email_intentado' => ad_email_normalize($email)]);
    }

    public static function logout(?array $user): void
    {
        self::log('LOGOUT', null, $user);
        self::closeCurrentSession();
    }

    public static function accessDenied(string $permission): void
    {
        self::$suppressRequestEvent = true;
        self::log('ACCESS_DENIED', ['permiso' => $permission]);
    }

    public static function log(string $event, ?array $details = null, ?array $userOverride = null): void
    {
        if (PHP_SAPI === 'cli') {
            return;
        }
        try {
            $pdo = db();
            $user = $userOverride ?? ad_current_user();
            $hash = self::sessionHash();
            $snapshot = self::userSnapshot($user);
            if ($snapshot['id'] !== null && $event !== 'LOGOUT') {
                self::touchSession($pdo, $hash, $snapshot);
            }
            $statement = $pdo->prepare(
                'INSERT INTO ad_auditoria_sesiones
                 (session_hash,usuario_id,usuario_nombre,usuario_email,rol,evento,modulo,
                  ruta,metodo,ip,user_agent,codigo_http,detalles)
                 VALUES
                 (:session_hash,:usuario_id,:usuario_nombre,:usuario_email,:rol,:evento,:modulo,
                  :ruta,:metodo,:ip,:user_agent,:codigo_http,:detalles)'
            );
            $statement->execute([
                ':session_hash' => $hash,
                ':usuario_id' => $snapshot['id'],
                ':usuario_nombre' => $snapshot['nombre'],
                ':usuario_email' => $snapshot['email'],
                ':rol' => $snapshot['rol'],
                ':evento' => mb_strtoupper(substr(trim($event), 0, 40), 'UTF-8'),
                ':modulo' => self::module(),
                ':ruta' => self::route(),
                ':metodo' => self::method(),
                ':ip' => self::ip(),
                ':user_agent' => self::userAgent(),
                ':codigo_http' => self::statusCode(),
                ':detalles' => $details === null ? null : json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
        } catch (Throwable $ignored) {
            // La auditoría nunca debe impedir el uso de la aplicación.
        }
    }

    private static function touchSession(PDO $pdo, string $hash, array $user): void
    {
        $statement = $pdo->prepare(
            'INSERT INTO ad_sesiones_usuario
             (session_hash,usuario_id,usuario_nombre,usuario_email,rol,ip,user_agent,
              iniciada_at,ultima_actividad_at,estado)
             VALUES (:hash,:usuario,:nombre,:email,:rol,:ip,:agente,NOW(),NOW(),"ABIERTA")
             ON DUPLICATE KEY UPDATE usuario_id=VALUES(usuario_id),usuario_nombre=VALUES(usuario_nombre),
              usuario_email=VALUES(usuario_email),rol=VALUES(rol),ip=VALUES(ip),
              user_agent=VALUES(user_agent),ultima_actividad_at=NOW(),cerrada_at=NULL,estado="ABIERTA"'
        );
        $statement->execute([
            ':hash' => $hash,
            ':usuario' => $user['id'],
            ':nombre' => $user['nombre'],
            ':email' => $user['email'],
            ':rol' => $user['rol'],
            ':ip' => self::ip(),
            ':agente' => self::userAgent(),
        ]);
    }

    private static function closeCurrentSession(): void
    {
        try {
            $statement = db()->prepare(
                'UPDATE ad_sesiones_usuario
                 SET estado="CERRADA",cerrada_at=NOW(),ultima_actividad_at=NOW()
                 WHERE session_hash=:hash'
            );
            $statement->execute([':hash' => self::sessionHash()]);
        } catch (Throwable $ignored) {
        }
    }

    private static function userSnapshot(?array $user): array
    {
        return [
            'id' => isset($user['id']) ? (int)$user['id'] : null,
            'nombre' => isset($user['nombre']) ? substr((string)$user['nombre'], 0, 180) : null,
            'email' => isset($user['email']) ? substr((string)$user['email'], 0, 190) : null,
            'rol' => isset($user['rol']) ? substr((string)$user['rol'], 0, 100) : null,
        ];
    }

    private static function sessionHash(): string
    {
        $sessionId = session_id();
        if ($sessionId === '') {
            $sessionId = 'sin-sesion|' . self::ip() . '|' . self::userAgent();
        }
        return hash('sha256', $sessionId);
    }

    private static function route(): string
    {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
        $path = parse_url($uri, PHP_URL_PATH);
        return substr(is_string($path) && $path !== '' ? $path : '/', 0, 500);
    }

    private static function module(): string
    {
        $route = trim(str_replace('\\', '/', self::route()), '/');
        $parts = array_values(array_filter(explode('/', $route), static function ($part): bool {
            return $part !== '';
        }));
        $publicIndex = array_search('public', $parts, true);
        if ($publicIndex !== false) {
            $candidate = $parts[$publicIndex + 1] ?? 'inicio';
        } else {
            $candidate = $parts[count($parts) - 2] ?? ($parts[0] ?? 'inicio');
        }
        if (substr($candidate, -4) === '.php') {
            $candidate = pathinfo($candidate, PATHINFO_FILENAME);
        }
        if ($candidate === 'dashboards') {
            $candidate = 'informe';
        }
        return substr($candidate === '' ? 'inicio' : $candidate, 0, 100);
    }

    private static function method(): string
    {
        return substr(mb_strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'), 'UTF-8'), 0, 10);
    }

    private static function ip(): ?string
    {
        $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
        return $ip === '' ? null : substr($ip, 0, 64);
    }

    private static function userAgent(): ?string
    {
        $agent = trim((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
        return $agent === '' ? null : substr($agent, 0, 500);
    }

    private static function statusCode(): int
    {
        $code = http_response_code();
        return is_int($code) && $code >= 100 ? $code : 200;
    }
}
