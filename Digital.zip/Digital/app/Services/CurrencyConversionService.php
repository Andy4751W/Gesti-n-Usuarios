<?php
declare(strict_types=1);

final class CurrencyConversionService
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function status(): array
    {
        $this->ensureConfigurationTable();
        $row = $this->pdo->query(
            'SELECT * FROM ad_configuracion_moneda WHERE id=1'
        )->fetch(PDO::FETCH_ASSOC);

        return $row ?: [
            'estado' => 'PENDIENTE',
            'moneda_origen' => 'COP',
            'moneda_destino' => 'USD',
            'tasa_cop_por_usd' => null,
            'fecha_tasa' => null,
            'resumen' => null,
            'convertido_at' => null,
        ];
    }

    public function convertCopToUsd(float $rate, string $rateDate, ?int $userId): array
    {
        if ($rate < 100 || $rate > 100000) {
            throw new InvalidArgumentException(
                'La tasa COP por USD debe estar entre 100 y 100.000. Revise que escribió COP por 1 USD.'
            );
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $rateDate);
        if (!$date || $date->format('Y-m-d') !== $rateDate) {
            throw new InvalidArgumentException('La fecha de la tasa no es válida.');
        }

        $this->ensureCurrencySchema();
        $this->pdo->beginTransaction();
        try {
            $state = $this->pdo->query(
                'SELECT estado FROM ad_configuracion_moneda WHERE id=1 FOR UPDATE'
            )->fetchColumn();
            if ($state === false) {
                throw new RuntimeException('No existe la configuración de moneda. Ejecute primero bin\\update.php.');
            }
            if ($state === 'COMPLETADA') {
                throw new RuntimeException('La conversión a USD ya fue realizada. No se modificó ningún valor.');
            }

            $summary = [];
            $updates = [
                'detalles_factura' => 'UPDATE ad_factura_detalles d INNER JOIN ad_facturas f ON f.id=d.factura_id SET d.valor_unitario=ROUND(d.valor_unitario/:rate,4),d.descuento=ROUND(d.descuento/:rate,2),d.impuesto=ROUND(d.impuesto/:rate,2),d.subtotal=ROUND(d.subtotal/:rate,2),d.total=ROUND(d.total/:rate,2) WHERE f.moneda="COP"',
                'conciliaciones' => 'UPDATE ad_conciliaciones c INNER JOIN ad_factura_detalles d ON d.id=c.factura_detalle_id INNER JOIN ad_facturas f ON f.id=d.factura_id SET c.tarifa_contratada=IF(c.tarifa_contratada IS NULL,NULL,ROUND(c.tarifa_contratada/:rate,4)),c.tarifa_facturada=ROUND(c.tarifa_facturada/:rate,4),c.diferencia_tarifa=IF(c.diferencia_tarifa IS NULL,NULL,ROUND(c.diferencia_tarifa/:rate,4)) WHERE f.moneda="COP"',
                'distribuciones_factura' => 'UPDATE ad_distribuciones_factura x INNER JOIN ad_factura_detalles d ON d.id=x.factura_detalle_id INNER JOIN ad_facturas f ON f.id=d.factura_id SET x.valor=ROUND(x.valor/:rate,2) WHERE f.moneda="COP"',
                'importaciones_distribucion' => 'UPDATE ad_importaciones_distribucion i INNER JOIN ad_facturas f ON f.id=i.factura_id SET i.total_fuente=ROUND(i.total_fuente/:rate,2),i.total_distribuido=ROUND(i.total_distribuido/:rate,2),i.diferencia_factura=ROUND(i.diferencia_factura/:rate,2) WHERE f.moneda="COP"',
                'distribuciones_usuario' => 'UPDATE ad_distribuciones_usuario_factura d INNER JOIN ad_importaciones_distribucion i ON i.id=d.importacion_id INNER JOIN ad_facturas f ON f.id=i.factura_id SET d.valor_base=ROUND(d.valor_base/:rate,2),d.valor_distribuido=ROUND(d.valor_distribuido/:rate,2) WHERE f.moneda="COP"',
                'facturas' => 'UPDATE ad_facturas SET subtotal=ROUND(subtotal/:rate,2),descuentos=ROUND(descuentos/:rate,2),impuestos=ROUND(impuestos/:rate,2),retenciones=ROUND(retenciones/:rate,2),total_pagar=ROUND(total_pagar/:rate,2),moneda="USD" WHERE moneda="COP"',
                'dominios' => 'UPDATE ad_dominios SET valor_renovacion=IF(valor_renovacion IS NULL,NULL,ROUND(valor_renovacion/:rate,2)),moneda="USD" WHERE moneda="COP"',
                'suscripciones' => 'UPDATE ad_suscripciones SET valor_unitario=ROUND(valor_unitario/:rate,4),moneda="USD" WHERE moneda="COP"',
                'asignaciones_licencia' => 'UPDATE ad_asignaciones_licencia SET valor_unitario_asignado=ROUND(valor_unitario_asignado/:rate,4),moneda="USD" WHERE moneda="COP"',
                'perfiles_distribucion' => 'UPDATE ad_perfiles_distribucion_cuenta SET costo_mensual=IF(costo_mensual IS NULL,NULL,ROUND(costo_mensual/:rate,4)),moneda="USD" WHERE moneda="COP"',
                'reglas_integrales' => 'UPDATE ad_reglas_integrales SET ingresos=ROUND(ingresos/:rate,2),moneda="USD" WHERE moneda="COP"',
                'proveedores' => 'UPDATE ad_proveedores SET moneda_principal="USD" WHERE moneda_principal="COP"',
            ];

            $rateSql = number_format($rate, 6, '.', '');
            foreach ($updates as $name => $sql) {
                $affected = $this->pdo->exec(str_replace(':rate', $rateSql, $sql));
                $summary[$name] = $affected === false ? 0 : $affected;
            }

            $save = $this->pdo->prepare(
                'UPDATE ad_configuracion_moneda
                 SET tasa_cop_por_usd=:rate,fecha_tasa=:date,estado="COMPLETADA",
                     resumen=:summary,convertido_por=:user,convertido_at=NOW()
                 WHERE id=1'
            );
            $save->execute([
                ':rate' => $rate,
                ':date' => $rateDate,
                ':summary' => json_encode($summary, JSON_UNESCAPED_UNICODE),
                ':user' => $userId,
            ]);
            $this->pdo->commit();
            return $summary;
        } catch (Throwable $exception) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $exception;
        }
    }

    public function legacyCopAmountToUsd(float $amount): float
    {
        $status = $this->status();
        if (($status['estado'] ?? '') !== 'COMPLETADA' || (float)($status['tasa_cop_por_usd'] ?? 0) <= 0) {
            throw new RuntimeException(
                'Antes de importar valores históricos del Excel debe completar la conversión de moneda a USD.'
            );
        }
        return round($amount / (float)$status['tasa_cop_por_usd'], 4);
    }

    private function ensureConfigurationTable(): void
    {
        $this->pdo->exec(
            'CREATE TABLE IF NOT EXISTS ad_configuracion_moneda (
                id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                moneda_origen CHAR(3) NOT NULL DEFAULT "COP",
                moneda_destino CHAR(3) NOT NULL DEFAULT "USD",
                tasa_cop_por_usd DECIMAL(18,6) NULL,
                fecha_tasa DATE NULL,
                estado ENUM("PENDIENTE","COMPLETADA") NOT NULL DEFAULT "PENDIENTE",
                resumen JSON NULL,
                convertido_por BIGINT UNSIGNED NULL,
                convertido_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
        $this->pdo->exec(
            'INSERT IGNORE INTO ad_configuracion_moneda
             (id,moneda_origen,moneda_destino,estado)
             VALUES (1,"COP","USD","PENDIENTE")'
        );
    }

    private function ensureCurrencySchema(): void
    {
        $this->ensureConfigurationTable();

        $column = $this->pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME="ad_reglas_integrales"
               AND COLUMN_NAME="moneda"'
        );
        $column->execute();
        if ((int)$column->fetchColumn() === 0) {
            $this->pdo->exec(
                'ALTER TABLE ad_reglas_integrales
                 ADD COLUMN moneda CHAR(3) NOT NULL DEFAULT "COP" AFTER ingresos'
            );
        }

        foreach ([
            'ALTER TABLE ad_proveedores MODIFY moneda_principal CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_dominios MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_suscripciones MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_asignaciones_licencia MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_facturas MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_perfiles_distribucion_cuenta MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
            'ALTER TABLE ad_reglas_integrales MODIFY moneda CHAR(3) NOT NULL DEFAULT "USD"',
        ] as $statement) {
            $this->pdo->exec($statement);
        }
    }
}
