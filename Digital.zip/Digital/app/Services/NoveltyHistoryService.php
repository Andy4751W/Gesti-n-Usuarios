<?php
declare(strict_types=1);

final class NoveltyHistoryService
{
    public static function record(
        PDO $pdo,
        ?int $accountId,
        string $type,
        string $description,
        array $data = [],
        string $origin = 'SISTEMA',
        ?int $userId = null,
        ?string $date = null
    ): void {
        $payload = $data;
        $payload['origen'] = strtoupper(trim($origin)) ?: 'SISTEMA';
        $payload['usuario_id'] = $userId;
        $payload['registrado_en'] = date('c');

        $statement = $pdo->prepare(
            'INSERT INTO ad_novedades
             (cuenta_id,tipo,estado,fecha_novedad,descripcion,datos_origen,created_by)
             VALUES (:cuenta,:tipo,"CERRADA",:fecha,:descripcion,:datos,:usuario)'
        );
        $statement->execute([
            ':cuenta' => $accountId,
            ':tipo' => strtoupper(trim($type)),
            ':fecha' => $date ?: date('Y-m-d'),
            ':descripcion' => $description,
            ':datos' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ':usuario' => $userId,
        ]);
    }
}
