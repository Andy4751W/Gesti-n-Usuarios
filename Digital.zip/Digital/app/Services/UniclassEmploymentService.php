<?php
declare(strict_types=1);

final class UniclassEmploymentService
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function lookupDocument(string $document): array
    {
        $document = $this->normalizeDocument($document);
        $consultedAt = date('c');
        try {
            $connection = $this->connection();
            $rows = $this->queryDocuments($connection, [$document]);
            $employees = $this->employeesByDocument($rows);
            if (!isset($employees[$document])) {
                return $this->lookupResult(false, 'NO_ENCONTRADO', null, 'La persona no se encuentra registrada en UNICLASS.', $consultedAt);
            }
            $employee = $employees[$document];
            if ($employee['estado_uniclass'] === 'A') {
                $active = $this->queryActiveDocument($connection, $document);
                if ($active !== null) {
                    $employee = $this->mapEmployeeRow($active, $document);
                }
            }
            $status = $employee['estado_uniclass'] === 'R' ? 'RETIRADO' : 'ACTIVO';
            return $this->lookupResult(true, $status, $employee, $status === 'RETIRADO'
                ? 'La persona figura retirada en UNICLASS.'
                : 'Funcionario activo en UNICLASS.', $consultedAt);
        } catch (Throwable $exception) {
            error_log('No fue posible consultar UNICLASS: ' . $exception->getMessage());
            return $this->lookupResult(false, 'ERROR_CONEXION', null, 'No fue posible consultar UNICLASS.', $consultedAt);
        }
    }

    public function pendingValidationAccounts(): array
    {
        if (ad_user_role() !== 'ADMIN') {
            return ['available' => false, 'forbidden' => true, 'accounts' => [], 'sync' => []];
        }
        $sql = 'SELECT c.id cuenta_id,c.correo,per.numero_documento,per.nombre_completo nombre,per.cargo,
                       pd.cliente,v.estado AS estado_validacion,v.est_uniclass AS estado_uniclass,v.ultima_validacion,
                       GROUP_CONCAT(DISTINCT p.nombre ORDER BY p.nombre SEPARATOR " · ") licencias_detalle,
                       ROUND(SUM(al.valor_unitario_asignado),2) costo_total
                FROM ad_validaciones_uniclass_cuenta v
                INNER JOIN ad_cuentas c ON c.id=v.cuenta_id
                INNER JOIN ad_asignaciones_licencia al ON al.cuenta_id=c.id AND al.estado="ACTIVA" AND al.moneda="USD"
                INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
                INNER JOIN ad_planes p ON p.id=s.plan_id
                LEFT JOIN ad_asignaciones_cuenta ac ON ac.id=(SELECT MAX(x.id) FROM ad_asignaciones_cuenta x WHERE x.cuenta_id=c.id AND x.estado="ACTIVA")
                LEFT JOIN ad_personas per ON per.id=ac.persona_id
                LEFT JOIN ad_perfiles_distribucion_cuenta pd ON pd.cuenta_id=c.id
                WHERE v.estado IN ("PENDIENTE_REGISTRO_UNICLASS","RETIRADO_CON_LICENCIA")
                GROUP BY c.id,c.correo,per.numero_documento,per.nombre_completo,per.cargo,pd.cliente,v.estado,v.est_uniclass,v.ultima_validacion
                ORDER BY c.correo';
        $accounts = $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        if ($accounts !== []) {
            try {
                $documents = array_values(array_unique(array_filter(array_map(
                    fn (array $account): string => $this->normalizeDocument((string)$account['numero_documento']),
                    $accounts
                ))));
                $employees = $this->employeesByDocument($this->queryDocuments($this->connection(), $documents));
                $accounts = array_values(array_filter($accounts, static function (array $account) use ($employees): bool {
                    $document = preg_replace('/\D+/', '', trim((string)$account['numero_documento'])) ?? '';
                    return !isset($employees[$document]) || $employees[$document]['estado_uniclass'] !== 'A';
                }));
            } catch (Throwable $exception) {
                error_log('No fue posible actualizar la alerta UNICLASS: ' . $exception->getMessage());
                return ['available' => false, 'forbidden' => false, 'accounts' => [], 'sync' => $this->latestSync()];
            }
        }
        foreach ($accounts as &$account) {
            $account['motivo'] = $account['estado_validacion'] === 'RETIRADO_CON_LICENCIA' ? 'Retirado con licencia' : 'Pendiente de registro UNICLASS';
            if (!ad_is_valid_dashboard_client((string)$account['cliente'])) {
                $account['cliente'] = null;
            }
        }
        unset($account);
        return ['available' => true, 'forbidden' => false, 'accounts' => $accounts, 'sync' => $this->latestSync()];
    }

    public function syncPendingLicensedAccounts(): array
    {
        $accounts = $this->licensedAccountsWithDocument();
        $syncId = $this->startSync(count($accounts));
        $summary = ['total_cuentas' => count($accounts), 'cuentas_actualizadas' => 0, 'lotes_fallidos' => 0, 'fallos' => []];
        try {
            $connection = $this->connection();
            foreach (array_chunk($accounts, 300) as $batchNumber => $batch) {
                try {
                    $documents = array_values(array_unique(array_column($batch, 'documento')));
                    if ($documents === []) {
                        continue;
                    }
                    $employees = $this->employeesByDocument($this->queryDocuments($connection, $documents));
                    $this->pdo->beginTransaction();
                    foreach ($batch as $account) {
                        $employee = $employees[$account['documento']] ?? null;
                        $state = $employee === null ? 'PENDIENTE_REGISTRO_UNICLASS' : ($employee['estado_uniclass'] === 'R' ? 'RETIRADO_CON_LICENCIA' : 'ACTIVO');
                        $this->saveValidation((int)$account['cuenta_id'], $state, $employee['estado_uniclass'] ?? null);
                        if ($employee !== null) {
                            $this->updatePersonFromUniclass((int)$account['cuenta_id'], $employee, $state);
                        }
                        $summary['cuentas_actualizadas']++;
                    }
                    $this->pdo->commit();
                } catch (Throwable $exception) {
                    if ($this->pdo->inTransaction()) {
                        $this->pdo->rollBack();
                    }
                    $summary['lotes_fallidos']++;
                    $failure = [
                        'lote' => $batchNumber + 1,
                        'documentos' => count($batch),
                        'clase' => get_class($exception),
                        'mensaje' => $this->safeSyncError($exception->getMessage()),
                    ];
                    $summary['fallos'][] = $failure;
                    error_log('Falló el lote UNICLASS ' . ($batchNumber + 1) . ' (' . count($batch) . ' documentos): ' . $failure['clase'] . ': ' . $failure['mensaje']);
                }
            }
            $allFailed = $summary['total_cuentas'] > 0
                && $summary['cuentas_actualizadas'] === 0
                && $summary['lotes_fallidos'] === count(array_chunk($accounts, 300));
            $state = $allFailed ? 'FALLIDA' : ($summary['lotes_fallidos'] ? 'COMPLETADA_CON_ERRORES' : 'COMPLETADA');
            $message = $summary['lotes_fallidos'] ? 'Uno o más lotes no pudieron sincronizarse.' : null;
            $this->finishSync($syncId, $state, $summary, $message);
            return $summary + ['estado' => $state];
        } catch (Throwable $exception) {
            $this->finishSync($syncId, 'FALLIDA', $summary, 'No fue posible iniciar la sincronización UNICLASS.');
            throw $exception;
        }
    }

    private function licensedAccountsWithDocument(): array
    {
        $sql = 'SELECT DISTINCT c.id cuenta_id,p.numero_documento
                FROM ad_cuentas c
                INNER JOIN ad_asignaciones_licencia al ON al.cuenta_id=c.id AND al.estado="ACTIVA" AND al.moneda="USD"
                INNER JOIN ad_asignaciones_cuenta ac ON ac.id=(SELECT MAX(x.id) FROM ad_asignaciones_cuenta x WHERE x.cuenta_id=c.id AND x.estado="ACTIVA")
                INNER JOIN ad_personas p ON p.id=ac.persona_id
                WHERE NULLIF(TRIM(p.numero_documento),"") IS NOT NULL';
        $accounts = [];
        foreach ($this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $document = $this->normalizeDocument((string)$row['numero_documento']);
            if ($document !== '') {
                $accounts[] = ['cuenta_id' => (int)$row['cuenta_id'], 'documento' => $document];
            }
        }
        return $accounts;
    }

    private function latestSync(): array
    {
        $row = $this->pdo->query('SELECT s.estado,s.finished_at,s.mensaje,
                                         (SELECT MAX(completed.finished_at)
                                            FROM ad_sincronizaciones_uniclass completed
                                           WHERE completed.estado="COMPLETADA") ultima_completada_at
                                    FROM ad_sincronizaciones_uniclass s
                                   ORDER BY s.id DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
        return $row ?: ['estado' => 'NUNCA_SINCRONIZADA', 'finished_at' => null, 'mensaje' => null, 'ultima_completada_at' => null];
    }

    private function startSync(int $total): int
    {
        $stmt = $this->pdo->prepare('INSERT INTO ad_sincronizaciones_uniclass (estado,total_cuentas) VALUES ("INICIADA",:total)');
        $stmt->execute([':total' => $total]);
        return (int)$this->pdo->lastInsertId();
    }

    private function finishSync(int $id, string $state, array $summary, ?string $message): void
    {
        $stmt = $this->pdo->prepare('UPDATE ad_sincronizaciones_uniclass SET estado=:estado,cuentas_actualizadas=:actualizadas,lotes_fallidos=:fallidos,mensaje=:mensaje,finished_at=NOW() WHERE id=:id');
        $stmt->execute([':estado'=>$state, ':actualizadas'=>$summary['cuentas_actualizadas'], ':fallidos'=>$summary['lotes_fallidos'], ':mensaje'=>$message, ':id'=>$id]);
    }

    private function safeSyncError(string $message): string
    {
        return preg_replace('/(password|passwd|pwd)\s*[=:]\s*[^\s;,]+/i', '$1=[oculto]', $message) ?? '[error no disponible]';
    }

    private function connection()
    {
        $path = dirname(__DIR__, 2) . '/conexion.php';
        $pdo = $conexion = $conn = $mysqli = $con = null;
        $returned = require $path;
        foreach ([$returned, $pdo, $conexion, $conn, $mysqli, $con] as $candidate) {
            if ($candidate instanceof PDO || $this->isMysqli($candidate)) {
                return $candidate;
            }
        }
        throw new RuntimeException('La conexión empresarial no está disponible.');
    }

    private function queryDocuments($connection, array $documents): array
    {
        if ($documents === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($documents), '?'));
        if (substr_count($placeholders, '?') !== count($documents)) {
            throw new RuntimeException('La cantidad de placeholders de UNICLASS no coincide con los documentos.');
        }
           $sql = 'SELECT u.IDENTIFICACION,
                       u.APELLIDOS_Y_NOMBRES AS nombre,
                       u.NOMBRE_PUESTO AS cargo,
                       u.CIUDAD AS ciudad,
                       u.CU_Proceso AS proceso,
                       u.CU_Cliente AS cliente,
                       u.CU_Proyecto AS proyecto,
                       u.CU_Linea AS linea,
                       u.UNIDAD_3_COD AS cu3,
                       u.SUCURSAL AS empresa,
                       u.EMP AS empresa_codigo,
                       u.EST AS estado_uniclass,
                       u.`TIMESTAMP` AS actualizado_uniclass,
                       u.INGRESO,
                       u.ID_EMP,
                       u.id
                   FROM mae_data_uniclass u
                  WHERE TRIM(u.IDENTIFICACION) IN (' . $placeholders . ')';
        if ($connection instanceof PDO) {
            $stmt = $connection->prepare($sql);
            $stmt->execute($documents);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        $stmt = $connection->prepare($sql);
        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la consulta empresarial.');
        }
        $references = [str_repeat('s', count($documents))];
        foreach ($documents as $index => $document) {
            $references[] = &$documents[$index];
        }
        if (!call_user_func_array([$stmt, 'bind_param'], $references) || !$stmt->execute() || !($result = $stmt->get_result())) {
            $stmt->close();
            throw new RuntimeException('No se pudo consultar UNICLASS.');
        }
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    private function queryActiveDocument($connection, string $document): ?array
    {
                $sql = 'SELECT u.IDENTIFICACION,
                                             u.APELLIDOS_Y_NOMBRES AS nombre,
                                             u.NOMBRE_PUESTO AS cargo,
                                             u.CIUDAD AS ciudad,
                                             u.CU_Proceso AS proceso,
                                             u.CU_Cliente AS cliente,
                                             u.CU_Proyecto AS proyecto,
                                             u.CU_Linea AS linea,
                                             u.UNIDAD_3_COD AS cu3,
                                             u.SUCURSAL AS empresa,
                                             u.EMP AS empresa_codigo,
                                             u.EST AS estado_uniclass,
                                             u.`TIMESTAMP` AS actualizado_uniclass,
                                             u.INGRESO,
                                             u.ID_EMP,
                                             u.id
                                    FROM mae_data_uniclass u
                                 WHERE TRIM(u.IDENTIFICACION) = ?
                                     AND UPPER(TRIM(u.EST)) = \'A\'
                                 ORDER BY u.INGRESO DESC, u.ID_EMP DESC, u.id DESC
                                 LIMIT 1';
        if ($connection instanceof PDO) {
            $stmt = $connection->prepare($sql);
            $stmt->execute([$document]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        }
        $stmt = $connection->prepare($sql);
        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la consulta activa empresarial.');
        }
        $stmt->bind_param('s', $document);
        if (!$stmt->execute() || !($result = $stmt->get_result())) {
            $stmt->close();
            throw new RuntimeException('No se pudo consultar el estado activo de UNICLASS.');
        }
        $row = $result->fetch_assoc() ?: null;
        $stmt->close();
        return $row;
    }

    private function employeesByDocument(array $rows): array
    {
        $grouped = [];
        foreach ($rows as $row) {
            $document = $this->normalizeDocument((string)($row['IDENTIFICACION'] ?? ''));
            if ($document !== '') {
                $grouped[$document][] = $row;
            }
        }
        $employees = [];
        foreach ($grouped as $document => $documentRows) {
            $hayActivo = 0;
            foreach ($documentRows as $row) {
                if (mb_strtoupper(trim((string)($row['estado_uniclass'] ?? '')), 'UTF-8') === 'A') {
                    $hayActivo = 1;
                    break;
                }
            }
            $candidates = array_values(array_filter($documentRows, static function (array $row) use ($hayActivo): bool {
                $state = mb_strtoupper(trim((string)($row['estado_uniclass'] ?? '')), 'UTF-8');
                return $hayActivo === 1 ? $state === 'A' : $state === 'R';
            }));
            if ($candidates !== []) {
                usort($candidates, static function (array $left, array $right): int {
                    foreach (['INGRESO', 'ID_EMP', 'id'] as $column) {
                        $comparison = strcmp((string)($right[$column] ?? ''), (string)($left[$column] ?? ''));
                        if ($comparison !== 0) {
                            return $comparison;
                        }
                    }
                    return 0;
                });
                $row = $candidates[0];
                $documentString = $this->normalizeDocument(
                    (string)($row['IDENTIFICACION'] ?? $row['documento'] ?? $document)
                );
                $mappedEmployee = $this->mapEmployeeRow($row, $documentString);
                $employees[$document] = $mappedEmployee;
            }
        }
        return $employees;
    }

    private function saveValidation(int $accountId, string $state, ?string $est): void
    {
        $stmt = $this->pdo->prepare('INSERT INTO ad_validaciones_uniclass_cuenta (cuenta_id,estado,est_uniclass,ultima_validacion) VALUES (:cuenta,:estado,:est,NOW()) ON DUPLICATE KEY UPDATE estado=VALUES(estado),est_uniclass=VALUES(est_uniclass),ultima_validacion=VALUES(ultima_validacion)');
        $stmt->execute([':cuenta' => $accountId, ':estado' => $state, ':est' => $est]);
    }

    private function updatePersonFromUniclass(int $accountId, array $employee, string $state): void
    {
        $stmt = $this->pdo->prepare('SELECT ac.persona_id FROM ad_asignaciones_cuenta ac WHERE ac.cuenta_id=:cuenta AND ac.estado="ACTIVA" ORDER BY ac.id DESC LIMIT 1');
        $stmt->execute([':cuenta' => $accountId]);
        $personId = (int)$stmt->fetchColumn();
        if ($personId <= 0) {
            return;
        }
        $reasonId = null;
        if ($employee['empresa'] !== '') {
            $reason = $this->pdo->prepare('SELECT id FROM ad_razones_sociales WHERE nombre=:nombre AND pais=:pais LIMIT 1');
            $reason->execute([':nombre' => $employee['empresa'], ':pais' => $employee['pais'] ?: 'CO']);
            $reasonId = $reason->fetchColumn() ?: null;
        }
        $update = $this->pdo->prepare('UPDATE ad_personas SET pais=:pais,nombre_completo=:nombre,cargo=:cargo,ciudad=:ciudad,proceso=:proceso,cliente=:cliente,proyecto=:proyecto,razon_social_id=:razon,estado_laboral=:estado,fuente="UNICLASS",fuente_id=:documento WHERE id=:id');
        $update->execute([
            ':pais' => $employee['pais'] ?: 'CO', ':nombre' => $employee['nombre'] ?: null,
            ':cargo' => $employee['cargo'] ?: null, ':ciudad' => $employee['ciudad'] ?: null,
            ':proceso' => $employee['proceso'] ?: null, ':cliente' => $employee['cliente'] ?: null,
            ':proyecto' => $employee['proyecto'] ?: null, ':razon' => $reasonId,
            ':estado' => $state === 'RETIRADO_CON_LICENCIA' ? 'RETIRADO' : 'ACTIVO',
            ':documento' => $employee['documento'] ?? null, ':id' => $personId,
        ]);
        if ($employee['cu3'] !== '' || $employee['linea'] !== '' || $employee['empresa'] !== '') {
            $profile = $this->pdo->prepare('INSERT INTO ad_perfiles_distribucion_cuenta (cuenta_id,cu3,cliente,linea_negocio,proyecto,ciudad,empresa,proceso_cu1,fuente) VALUES (:cuenta,:cu3,:cliente,:linea,:proyecto,:ciudad,:empresa,:proceso,"UNICLASS") ON DUPLICATE KEY UPDATE cu3=VALUES(cu3),cliente=VALUES(cliente),linea_negocio=VALUES(linea_negocio),proyecto=VALUES(proyecto),ciudad=VALUES(ciudad),empresa=VALUES(empresa),proceso_cu1=VALUES(proceso_cu1),fuente=VALUES(fuente)');
            $profile->execute([':cuenta'=>$accountId, ':cu3'=>$employee['cu3'] ?: null, ':cliente'=>$employee['cliente'] ?: null, ':linea'=>$employee['linea'] ?: null, ':proyecto'=>$employee['proyecto'] ?: null, ':ciudad'=>$employee['ciudad'] ?: null, ':empresa'=>$employee['empresa'] ?: null, ':proceso'=>$employee['proceso'] ?: null]);
        }
    }

    private function isMysqli($connection): bool
    {
        return class_exists('mysqli', false) && $connection instanceof mysqli;
    }

    private function normalizeDocument(string $document): string
    {
        return preg_replace('/\D+/', '', trim($document)) ?? '';
    }

    private function mapEmployeeRow(array $row, string $document): array
    {
        $value = static function (array $row, string $key): ?string {
            if (!array_key_exists($key, $row) || $row[$key] === null) {
                return null;
            }
            return trim((string)$row[$key]);
        };
        $estado = $value($row, 'estado_uniclass');
        $estado = $estado !== null && $estado !== ''
            ? mb_strtoupper($estado, 'UTF-8')
            : null;
        return [
            'documento' => $document,
            'nombre' => $value($row, 'nombre'),
            'cargo' => $value($row, 'cargo'),
            'ciudad' => $value($row, 'ciudad'),
            'proceso' => $value($row, 'proceso'),
            'cliente' => $value($row, 'cliente'),
            'proyecto' => $value($row, 'proyecto'),
            'cu3' => $value($row, 'cu3'),
            'linea' => $value($row, 'linea'),
            'empresa' => $value($row, 'empresa'),
            'empresa_codigo' => $value($row, 'empresa_codigo'),
            'pais' => $this->countryFromCompanyCode($value($row, 'empresa_codigo')),
            'estado_uniclass' => $estado,
            'actualizado_uniclass' => $value($row, 'actualizado_uniclass'),
            'est' => $estado,
        ];
    }

    private function countryFromCompanyCode(?string $companyCode): ?string
    {
        $codes = [
            'CT' => 'CO',
        ];
        $code = $companyCode !== null ? mb_strtoupper(trim($companyCode), 'UTF-8') : '';
        return $codes[$code] ?? null;
    }

    private function lookupResult(bool $available, string $status, ?array $data, string $message, string $consultedAt): array
    {
        return [
            'available' => $available,
            'status' => $status,
            'estado_validacion' => $status === 'ACTIVO' ? 'ACTIVO' : ($status === 'RETIRADO' ? 'RETIRADO_CON_LICENCIA' : 'PENDIENTE_REGISTRO_UNICLASS'),
            'origen' => 'UNICLASS_DIRECTO',
            'consulta_directa' => true,
            'consultado_en' => $consultedAt,
            'estado_uniclass' => $data['estado_uniclass'] ?? null,
            'datos' => $data,
            'employee' => $data,
            'message' => $message,
        ];
    }
}
