<?php
declare(strict_types=1);

final class ClientDashboardService
{
    private PDO $pdo;
    private BasePpalReportService $basePpalReport;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
        $this->basePpalReport = new BasePpalReportService($pdo);
    }

    public function visibleClients(): array
    {
        return $this->basePpalReport->visibleClients();
        /*
        $this->syncClientCatalogFromProfiles();
        $ids = ad_dashboard_client_ids();
        $sql = 'SELECT id,codigo,nombre FROM ad_clientes_dashboard WHERE activo=1';
        $parameters = [];
        if ($ids !== null) {
            if (!$ids) {
                return [];
            }
            $marks = [];
            foreach ($ids as $index => $id) {
                $key = ':visible_' . $index;
                $marks[] = $key;
                $parameters[$key] = (int)$id;
            }
            $sql .= ' AND id IN (' . implode(',', $marks) . ')';
        }
        $sql .= ' ORDER BY nombre';
        $statement = $this->pdo->prepare($sql);
        $statement->execute($parameters);
        return array_values(array_filter($statement->fetchAll(PDO::FETCH_ASSOC), static function (array $client): bool {
            return ad_is_valid_dashboard_client((string)$client['nombre']);
        }));
        */
    }

    /**
     * Mantiene el catálogo exactamente igual a los valores únicos almacenados
     * desde SHAREPOINT.CU3-CLIENTE. No agrupa alias ni conserva clientes que no
     * estén presentes en esa columna.
     */
    public function syncClientCatalogFromProfiles(): void
    {
        $names = $this->pdo->query(
            'SELECT DISTINCT TRIM(cliente) nombre
             FROM ad_perfiles_distribucion_cuenta
               WHERE NULLIF(TRIM(cliente),"") IS NOT NULL
             ORDER BY nombre'
        )->fetchAll(PDO::FETCH_COLUMN);
        $this->syncClientCatalog($names, false);
    }

    /**
     * Sincroniza nombres exactos. Cuando la lista procede directamente de la
     * hoja SHAREPOINT es autoritativa y desactiva cualquier valor ausente.
     * La sincronización desde perfiles sirve para actualizar instalaciones
     * existentes, sin borrar clientes válidos que aún no tengan cuenta ligada.
     */
    public function syncClientCatalog(array $names, bool $authoritative = false): void
    {
        if (!$names) {
            return;
        }

        $existing = $this->pdo->query(
            'SELECT id,codigo,nombre FROM ad_clientes_dashboard ORDER BY id'
        )->fetchAll(PDO::FETCH_ASSOC);
        $byName = [];
        $usedCodes = [];
        foreach ($existing as $item) {
            $byName[ad_normalize_text((string)$item['nombre'])] = $item;
            $usedCodes[ad_normalize_text((string)$item['codigo'])] = (int)$item['id'];
        }

        $activate = $this->pdo->prepare(
            'UPDATE ad_clientes_dashboard SET nombre=:nombre,activo=1 WHERE id=:id'
        );
        $insert = $this->pdo->prepare(
            'INSERT INTO ad_clientes_dashboard (codigo,nombre,activo) VALUES (:codigo,:nombre,1)'
        );
        $activeIds = [];
        $seenNames = [];
        foreach ($names as $rawName) {
            $name = trim((string)$rawName);
            $normalized = ad_normalize_text($name);
            if (!ad_is_valid_dashboard_client($name) || isset($seenNames[$normalized])) {
                continue;
            }
            $seenNames[$normalized] = true;
            if (isset($byName[$normalized])) {
                $id = (int)$byName[$normalized]['id'];
                $activate->execute([':nombre' => mb_substr($name, 0, 150), ':id' => $id]);
                $activeIds[] = $id;
                continue;
            }

            $baseCode = trim((string)preg_replace('/[^A-Z0-9]+/', '_', $normalized), '_');
            if ($baseCode === '') {
                $baseCode = 'CLIENTE_' . substr(hash('sha256', $normalized), 0, 10);
            }
            $code = substr($baseCode, 0, 80);
            if (isset($usedCodes[$code])) {
                $suffix = '_' . substr(hash('sha256', $normalized), 0, 8);
                $code = substr($baseCode, 0, 80 - strlen($suffix)) . $suffix;
            }
            $insert->execute([':codigo' => $code, ':nombre' => mb_substr($name, 0, 150)]);
            $id = (int)$this->pdo->lastInsertId();
            $activeIds[] = $id;
            $usedCodes[$code] = $id;
        }

        if ($activeIds && $authoritative) {
            $marks = implode(',', array_fill(0, count($activeIds), '?'));
            $deactivate = $this->pdo->prepare(
                'UPDATE ad_clientes_dashboard SET activo=0 WHERE id NOT IN (' . $marks . ')'
            );
            $deactivate->execute($activeIds);
        } elseif ($activeIds) {
            // Retira únicamente el catálogo genérico incluido en versiones
            // anteriores. Otros valores exactos importados se conservan.
            $legacy = ['CLARO','ETB','ONNET','AZTECA','TABASCO','FIBERHOME','WIN / FIBRAMAS'];
            $legacyIds = [];
            foreach ($existing as $item) {
                $normalized = ad_normalize_text((string)$item['nombre']);
                if (in_array($normalized, $legacy, true) && !isset($seenNames[$normalized])) {
                    $legacyIds[] = (int)$item['id'];
                }
            }
            if ($legacyIds) {
                $marks = implode(',', array_fill(0, count($legacyIds), '?'));
                $deactivate = $this->pdo->prepare(
                    'UPDATE ad_clientes_dashboard SET activo=0 WHERE id IN (' . $marks . ')'
                );
                $deactivate->execute($legacyIds);
            }
        }

        $invalidClientIds = [];
        foreach ($existing as $item) {
            if (!ad_is_valid_dashboard_client((string)$item['nombre'])) {
                $invalidClientIds[] = (int)$item['id'];
            }
        }
        if ($invalidClientIds) {
            $marks = implode(',', array_fill(0, count($invalidClientIds), '?'));
            $deactivate = $this->pdo->prepare(
                'UPDATE ad_clientes_dashboard SET activo=0 WHERE id IN (' . $marks . ')'
            );
            $deactivate->execute($invalidClientIds);
        }
    }

    public function findVisibleClient(int $id): ?array
    {
        if ($id <= 0 || !ad_can_view_dashboard_client($id)) {
            return null;
        }
        return $this->basePpalReport->findVisibleClient($id);
        /*
        $statement = $this->pdo->prepare(
            'SELECT id,codigo,nombre FROM ad_clientes_dashboard WHERE id=:id AND activo=1 LIMIT 1'
        );
        $statement->execute([':id' => $id]);
        $client = $statement->fetch(PDO::FETCH_ASSOC) ?: null;
        return $client && ad_is_valid_dashboard_client((string)$client['nombre']) ? $client : null;
        */
    }

    /**
     * Totales del informe de licencias por cliente. No depende del estado de
     * la cuenta: una licencia activa en USD se incluye porque continúa
     * representando un costo mensual.
     */
    public function licenseReport(array $client): array
    {
        return $this->basePpalReport->licenseReport($client);
        $parameters = [];
        $predicate = $this->valuePredicate('pd.cliente', $client, 'report_license', $parameters);
        $statement = $this->pdo->prepare(
            'SELECT al.id asignacion_id,c.id cuenta_id,c.correo,c.pais,
                    pd.cu3,pd.cliente,pd.linea_negocio,pd.proyecto,pd.ciudad,
                    COALESCE(NULLIF(TRIM(per.nombre_completo),""),NULLIF(TRIM(c.responsable_funcional),""),"Sin nombre asociado") nombre,
                    per.numero_documento,per.cargo,
                    p.id plan_id,p.nombre licencia,p.fabricante,
                    al.valor_unitario_asignado valor_usd
             FROM ad_perfiles_distribucion_cuenta pd
             INNER JOIN ad_cuentas c ON c.id=pd.cuenta_id
             INNER JOIN ad_asignaciones_licencia al ON al.cuenta_id=c.id
                    AND al.estado="ACTIVA" AND al.moneda="USD"
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             INNER JOIN ad_planes p ON p.id=s.plan_id
             LEFT JOIN ad_asignaciones_cuenta ac ON ac.id=(
                 SELECT MAX(ac_current.id) FROM ad_asignaciones_cuenta ac_current
                 WHERE ac_current.cuenta_id=c.id AND ac_current.estado="ACTIVA"
             )
             LEFT JOIN ad_personas per ON per.id=ac.persona_id
             WHERE (' . $predicate . ')
               AND NOT (' . $this->pendingReassignmentPredicate('pd.cliente') . ')
             ORDER BY p.nombre,c.correo,al.id'
        );
        $statement->execute($parameters);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $rows = $this->normalizeLicenseManufacturers($rows);

        $groups = [];
        $licensedAccounts = [];
        $accountLicenseSummary = [];
        $totalCost = 0.0;
        foreach ($rows as $row) {
            $planId = (int)$row['plan_id'];
            if (!isset($groups[$planId])) {
                $groups[$planId] = [
                    'licencia' => (string)$row['licencia'],
                    'fabricante' => (string)($row['fabricante'] ?? ''),
                    'licencias' => 0,
                    'cuentas' => [],
                    'usuarios' => [],
                    'costo_total' => 0.0,
                    'valor_minimo' => null,
                    'valor_maximo' => null,
                ];
            }
            $accountId = (int)$row['cuenta_id'];
            $value = round((float)$row['valor_usd'], 4);
            $groups[$planId]['licencias']++;
            $groups[$planId]['cuentas'][$accountId] = true;
            $groups[$planId]['usuarios'][] = $row;
            $groups[$planId]['costo_total'] += $value;
            $groups[$planId]['valor_minimo'] = $groups[$planId]['valor_minimo'] === null
                ? $value : min((float)$groups[$planId]['valor_minimo'], $value);
            $groups[$planId]['valor_maximo'] = $groups[$planId]['valor_maximo'] === null
                ? $value : max((float)$groups[$planId]['valor_maximo'], $value);
            $licensedAccounts[$accountId] = true;
            $email = ad_email_normalize((string)$row['correo']);
            if (!isset($accountLicenseSummary[$email])) {
                $accountLicenseSummary[$email] = [
                    'correo' => (string)$row['correo'],
                    'nombre' => (string)$row['nombre'],
                    'cliente' => (string)($row['cliente'] ?? ''),
                    'cantidad_licencias' => 0,
                    'licencias' => [],
                    'costo_total' => 0.0,
                    'asignaciones' => [],
                ];
            }
            $assignmentId = (int)$row['asignacion_id'];
            if (isset($accountLicenseSummary[$email]['asignaciones'][$assignmentId])) {
                continue;
            }
            $accountLicenseSummary[$email]['asignaciones'][$assignmentId] = true;
            $licenseName = (string)$row['licencia'];
            $accountLicenseSummary[$email]['cantidad_licencias']++;
            $accountLicenseSummary[$email]['licencias'][$licenseName]
                = ($accountLicenseSummary[$email]['licencias'][$licenseName] ?? 0) + 1;
            $accountLicenseSummary[$email]['costo_total'] += $value;
            $totalCost += $value;
        }
        foreach ($groups as &$group) {
            $group['cuentas_licenciadas'] = count($group['cuentas']);
            unset($group['cuentas']);
            $group['costo_total'] = round((float)$group['costo_total'], 2);
        }
        unset($group);

        $multipleAccounts = [];
        foreach ($accountLicenseSummary as $account) {
            if ((int)$account['cantidad_licencias'] <= 1) {
                continue;
            }
            $labels = [];
            foreach ($account['licencias'] as $licenseName => $quantity) {
                $labels[] = ((int)$quantity > 1 ? (int)$quantity . ' × ' : '') . $licenseName;
            }
            $account['licencias_detalle'] = implode(' · ', $labels);
            $account['costo_total'] = round((float)$account['costo_total'], 2);
            unset($account['licencias'], $account['asignaciones']);
            $multipleAccounts[] = $account;
        }
        usort($multipleAccounts, static function (array $left, array $right): int {
            return strcmp((string)$left['correo'], (string)$right['correo']);
        });

        $pendingLicenses = ad_user_role() === 'CONSULTOR'
            ? [] : $this->pendingReassignmentLicenses();

        return [
            'cuentas_licenciadas' => count($licensedAccounts),
            'licencias_asignadas' => count($rows),
            'costo_mensual' => round($totalCost, 2),
            'grupos' => array_values($groups),
            'cuentas_multiples' => $multipleAccounts,
            'pendientes_reasignacion' => $pendingLicenses,
        ];
    }

    /**
     * Asignaciones activas en USD que SHAREPOINT marcó para reasignación.
     * No recibe cliente: es un control global y su identidad es al.id.
     */
    public function pendingReassignmentLicenses(string $search = ''): array
    {
        $sharepointProfiles = $this->sharepointPendingProfiles();
        if (!$sharepointProfiles) {
            return [];
        }

        $parameters = [];
        $emailMarks = [];
        foreach (array_keys($sharepointProfiles) as $index => $email) {
            $key = ':pending_email_' . $index;
            $emailMarks[] = $key;
            $parameters[$key] = $email;
        }
        $where = [
            'al.estado="ACTIVA"',
            'al.moneda="USD"',
            'LOWER(TRIM(c.correo)) IN (' . implode(',', $emailMarks) . ')',
        ];
        $search = trim($search);
        if ($search !== '') {
            $needle = '%' . mb_substr($search, 0, 160, 'UTF-8') . '%';
            foreach (range(1, 4) as $index) {
                $parameters[':pending_q' . $index] = $needle;
            }
            $where[] = '(c.correo LIKE :pending_q1
                         OR COALESCE(NULLIF(TRIM(per.nombre_completo),""),NULLIF(TRIM(c.responsable_funcional),""),"Sin nombre asociado") LIKE :pending_q2
                         OR per.numero_documento LIKE :pending_q3
                         OR p.nombre LIKE :pending_q4)';
        }

        $statement = $this->pdo->prepare(
            'SELECT al.id asignacion_id,c.id cuenta_id,c.correo,c.pais,
                    COALESCE(NULLIF(TRIM(per.nombre_completo),""),NULLIF(TRIM(c.responsable_funcional),""),"Sin nombre asociado") nombre,
                    per.numero_documento,per.cargo,
                    p.id plan_id,p.nombre licencia,al.valor_unitario_asignado valor_usd
             FROM ad_asignaciones_licencia al
             INNER JOIN ad_cuentas c ON c.id=al.cuenta_id
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             INNER JOIN ad_planes p ON p.id=s.plan_id
             LEFT JOIN ad_asignaciones_cuenta ac ON ac.id=(
                 SELECT MAX(ac_current.id) FROM ad_asignaciones_cuenta ac_current
                 WHERE ac_current.cuenta_id=c.id AND ac_current.estado="ACTIVA"
             )
             LEFT JOIN ad_personas per ON per.id=ac.persona_id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY c.correo,p.nombre,al.id'
        );
        $statement->execute($parameters);

        $licenses = [];
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $profile = $sharepointProfiles[ad_email_normalize((string)$row['correo'])] ?? null;
            if ($profile === null) {
                continue;
            }
            $row['cu3'] = $profile['cu3'];
            $row['cliente'] = $profile['cliente'];
            $row['linea_negocio'] = $profile['linea_negocio'];
            $row['proyecto'] = $profile['proyecto'];
            $row['ciudad'] = $profile['ciudad'];
            $licenses[(int)$row['asignacion_id']] = $row;
        }
        return array_values($licenses);
    }

    public function overview(array $clients, string $from, string $to): array
    {
        $result = [];
        foreach ($clients as $client) {
            $summary = $this->summary($client, $from, $to);
            $summary['id'] = (int)$client['id'];
            $summary['codigo'] = (string)$client['codigo'];
            $summary['nombre'] = (string)$client['nombre'];
            $result[] = $summary;
        }
        return $result;
    }

    public function dashboard(array $client, string $from, string $to): array
    {
        $summary = $this->summary($client, $from, $to);

        $planParameters = [];
        $planPredicate = $this->accountPredicate('c', $client, 'plan', $planParameters);
        $planStatement = $this->pdo->prepare(
            'SELECT p.nombre etiqueta,COUNT(al.id) valor,
                    ROUND(SUM(al.valor_unitario_asignado),2) costo
             FROM ad_asignaciones_licencia al
             INNER JOIN ad_cuentas c ON c.id=al.cuenta_id
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             INNER JOIN ad_planes p ON p.id=s.plan_id
             WHERE al.estado="ACTIVA" AND al.moneda="USD" AND (' . $planPredicate . ')
             GROUP BY p.id,p.nombre ORDER BY valor DESC,p.nombre LIMIT 10'
        );
        $planStatement->execute($planParameters);

        $stateParameters = [];
        $statePredicate = $this->accountPredicate('c', $client, 'state', $stateParameters);
        $stateStatement = $this->pdo->prepare(
            'SELECT CASE c.estado WHEN "ACTIVA" THEN "Activas"
                    WHEN "GESTION_DE_BAJA" THEN "En gestión de baja"
                    WHEN "ELIMINADA" THEN "Eliminadas" ELSE c.estado END etiqueta,
                    COUNT(*) valor
             FROM ad_cuentas c WHERE (' . $statePredicate . ')
             GROUP BY c.estado ORDER BY valor DESC'
        );
        $stateStatement->execute($stateParameters);

        $backupParameters = [];
        $backupPredicate = $this->accountPredicate('c', $client, 'backup', $backupParameters);
        $backupStatement = $this->pdo->prepare(
            'SELECT CASE r.estado WHEN "REGISTRADO" THEN "Registrados"
                    WHEN "VALIDADO" THEN "Validados" WHEN "PENDIENTE" THEN "Pendientes"
                    WHEN "ELIMINADO" THEN "Eliminados" ELSE r.estado END etiqueta,
                    COUNT(*) valor
             FROM ad_respaldos r INNER JOIN ad_cuentas c ON c.id=r.cuenta_id
             WHERE (' . $backupPredicate . ') GROUP BY r.estado ORDER BY valor DESC'
        );
        $backupStatement->execute($backupParameters);

        $lineParameters = [];
        $linePredicate = $this->valuePredicate('pd.cliente', $client, 'line', $lineParameters);
        $lineStatement = $this->pdo->prepare(
            'SELECT COALESCE(NULLIF(TRIM(pd.linea_negocio),""),"Sin línea definida") etiqueta,
                    COUNT(*) valor
             FROM ad_perfiles_distribucion_cuenta pd
             WHERE (' . $linePredicate . ')
             GROUP BY etiqueta ORDER BY valor DESC LIMIT 8'
        );
        $lineStatement->execute($lineParameters);

        $trendFrom = (new DateTimeImmutable($to))->modify('first day of this month')->modify('-11 months')->format('Y-m-d');
        $months = $this->months($trendFrom, $to);
        $newsParameters = [':trend_from' => $trendFrom, ':trend_to' => $to];
        $newsPredicate = $this->accountPredicate('c', $client, 'trendnews', $newsParameters);
        $newsStatement = $this->pdo->prepare(
            'SELECT DATE_FORMAT(n.fecha_novedad,"%Y-%m") periodo,COUNT(*) valor
             FROM ad_novedades n INNER JOIN ad_cuentas c ON c.id=n.cuenta_id
             WHERE n.fecha_novedad BETWEEN :trend_from AND :trend_to
               AND (' . $newsPredicate . ')
             GROUP BY periodo ORDER BY periodo'
        );
        $newsStatement->execute($newsParameters);

        $costParameters = [':cost_from' => $trendFrom, ':cost_to' => $to];
        $costPredicate = $this->valuePredicate('pd_cost.cliente', $client, 'trendcost', $costParameters);
        $costStatement = $this->pdo->prepare(
            'SELECT DATE_FORMAT(i.periodo,"%Y-%m") periodo,
                    ROUND(SUM(d.valor_distribuido),2) valor
             FROM ad_distribuciones_usuario_factura d
             INNER JOIN ad_importaciones_distribucion i ON i.id=d.importacion_id
             INNER JOIN ad_perfiles_distribucion_cuenta pd_cost ON pd_cost.cuenta_id=d.cuenta_id
             WHERE i.periodo BETWEEN :cost_from AND :cost_to
               AND i.estado IN ("COMPLETADA","CON_PENDIENTES")
               AND (' . $costPredicate . ')
             GROUP BY periodo ORDER BY periodo'
        );
        $costStatement->execute($costParameters);

        return [
            'summary' => $summary,
            'plans' => $this->chartRows($planStatement->fetchAll(PDO::FETCH_ASSOC)),
            'states' => $this->chartRows($stateStatement->fetchAll(PDO::FETCH_ASSOC)),
            'backups' => $this->chartRows($backupStatement->fetchAll(PDO::FETCH_ASSOC)),
            'lines' => $this->chartRows($lineStatement->fetchAll(PDO::FETCH_ASSOC)),
            'months' => array_values($months),
            'newsTrend' => $this->trendValues($months, $newsStatement->fetchAll(PDO::FETCH_ASSOC)),
            'costTrend' => $this->trendValues($months, $costStatement->fetchAll(PDO::FETCH_ASSOC)),
        ];
    }

    /**
     * Licencias disponibles dentro del cliente seleccionado. El cliente se
     * obtiene exclusivamente del campo SHAREPOINT.CU3-CLIENTE, persistido en
     * ad_perfiles_distribucion_cuenta.cliente.
     */
    public function licenseOptions(array $client): array
    {
        return $this->basePpalReport->licenseOptions($client);
        $parameters = [];
        $predicate = $this->valuePredicate('pd.cliente', $client, 'license_option', $parameters);
        $statement = $this->pdo->prepare(
            'SELECT DISTINCT p.id,p.nombre
             FROM ad_perfiles_distribucion_cuenta pd
             INNER JOIN ad_cuentas c ON c.id=pd.cuenta_id
             INNER JOIN ad_asignaciones_licencia al ON al.cuenta_id=pd.cuenta_id AND al.estado="ACTIVA" AND al.moneda="USD"
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             INNER JOIN ad_planes p ON p.id=s.plan_id
             WHERE (' . $predicate . ')
               AND NOT (' . $this->pendingReassignmentPredicate('pd.cliente') . ')
             ORDER BY p.nombre'
        );
        $statement->execute($parameters);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row['nombre'] = $this->canonicalLicenseName((string)$row['nombre']);
        }
        unset($row);
        return $rows;
    }

    /**
     * Detalle paginado de las licencias activas del cliente. No consulta el
     * catálogo CONCATEN ALMACENES ni el cliente de ad_personas para definir el
     * alcance del informe.
     */
    public function licenseDetail(
        array $client,
        int $planId = 0,
        string $search = '',
        int $page = 1,
        int $perPage = 50
    ): array {
        return $this->basePpalReport->licenseDetail($client, $planId, $search, $page, $perPage);
        $parameters = [];
        $where = [
            $this->valuePredicate('pd.cliente', $client, 'detail_client', $parameters),
            'NOT (' . $this->pendingReassignmentPredicate('pd.cliente') . ')',
        ];
        if ($planId > 0) {
            $where[] = 'p.id=:detail_plan';
            $parameters[':detail_plan'] = $planId;
        }
        $search = trim($search);
        if ($search !== '') {
            $needle = '%' . $search . '%';
            $searchParts = [
                'c.correo LIKE :detail_q1',
                'per.nombre_completo LIKE :detail_q2',
                'c.responsable_funcional LIKE :detail_q3',
                'per.numero_documento LIKE :detail_q4',
                'per.cargo LIKE :detail_q5',
                'p.nombre LIKE :detail_q6',
                'pd.cu3 LIKE :detail_q7',
                'pd.cliente LIKE :detail_q8',
                'pd.linea_negocio LIKE :detail_q9',
                'pd.proyecto LIKE :detail_q10',
                'pd.ciudad LIKE :detail_q11',
                'c.pais LIKE :detail_q12',
            ];
            foreach (range(1, 12) as $index) {
                $parameters[':detail_q' . $index] = $needle;
            }
            $where[] = '(' . implode(' OR ', $searchParts) . ')';
        }

        $joins = ' FROM ad_perfiles_distribucion_cuenta pd
                   INNER JOIN ad_cuentas c ON c.id=pd.cuenta_id
                   INNER JOIN ad_asignaciones_licencia al ON al.cuenta_id=c.id AND al.estado="ACTIVA" AND al.moneda="USD"
                   INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
                   INNER JOIN ad_planes p ON p.id=s.plan_id
                   LEFT JOIN ad_asignaciones_cuenta ac ON ac.id=(
                       SELECT MAX(ac_current.id) FROM ad_asignaciones_cuenta ac_current
                       WHERE ac_current.cuenta_id=c.id AND ac_current.estado="ACTIVA"
                   )
                   LEFT JOIN ad_personas per ON per.id=ac.persona_id';
        $whereSql = ' WHERE ' . implode(' AND ', $where);

        $count = $this->pdo->prepare('SELECT COUNT(*)' . $joins . $whereSql);
        $count->execute($parameters);
        $total = (int)$count->fetchColumn();
        $perPage = max(10, min(100, $perPage));
        $pages = max(1, (int)ceil($total / $perPage));
        $page = max(1, min($page, $pages));
        $offset = ($page - 1) * $perPage;

        $sql = 'SELECT c.id cuenta_id,c.correo,c.estado cuenta_estado,c.pais,
                       pd.cu3,pd.cliente,pd.linea_negocio,pd.proyecto,pd.ciudad,
                       COALESCE(NULLIF(TRIM(per.nombre_completo),""),NULLIF(TRIM(c.responsable_funcional),""),"Sin funcionario asignado") funcionario,
                       per.numero_documento,per.cargo,
                       p.id plan_id,p.nombre licencia,p.fabricante,p.categoria,
                       al.valor_unitario_asignado valor_usd,al.moneda,
                       al.fecha_inicio,al.fecha_fin,al.estado licencia_estado'
             . $joins . $whereSql
             . ' ORDER BY p.nombre,c.correo,al.id LIMIT ' . $perPage . ' OFFSET ' . $offset;
        $statement = $this->pdo->prepare($sql);
        $statement->execute($parameters);

        return [
            'rows' => $this->normalizeLicenseManufacturers($statement->fetchAll(PDO::FETCH_ASSOC)),
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'perPage' => $perPage,
        ];
    }

    private function summary(array $client, string $from, string $to): array
    {
        $accountParameters = [];
        $accountPredicate = $this->accountPredicate('c', $client, 'account', $accountParameters);
        $accountStatement = $this->pdo->prepare(
            'SELECT COUNT(*) total,
                    COALESCE(SUM(c.estado="ACTIVA"),0) activas,
                    COALESCE(SUM(c.estado="GESTION_DE_BAJA"),0) en_baja
             FROM ad_cuentas c WHERE (' . $accountPredicate . ')'
        );
        $accountStatement->execute($accountParameters);
        $accounts = $accountStatement->fetch(PDO::FETCH_ASSOC) ?: [];

        $licenseParameters = [];
        $licensePredicate = $this->accountPredicate('c', $client, 'license', $licenseParameters);
        $licenseStatement = $this->pdo->prepare(
            'SELECT COUNT(al.id) licencias,
                    COUNT(DISTINCT al.cuenta_id) cuentas_licenciadas,
                    COALESCE(SUM(al.valor_unitario_asignado),0) costo_mensual
             FROM ad_asignaciones_licencia al
             INNER JOIN ad_cuentas c ON c.id=al.cuenta_id
             WHERE al.estado="ACTIVA" AND al.moneda="USD" AND (' . $licensePredicate . ')'
        );
        $licenseStatement->execute($licenseParameters);
        $licenses = $licenseStatement->fetch(PDO::FETCH_ASSOC) ?: [];

        $newsParameters = [':news_from' => $from, ':news_to' => $to];
        $newsPredicate = $this->accountPredicate('c', $client, 'news', $newsParameters);
        $newsStatement = $this->pdo->prepare(
            'SELECT COUNT(*) periodo,
                    COALESCE(SUM(n.estado IN ("ABIERTA","EN_GESTION")),0) abiertas,
                    COALESCE(SUM(UPPER(TRIM(n.tipo))="ELIMINACION SIN BACKUP"),0) sin_backup
             FROM ad_novedades n INNER JOIN ad_cuentas c ON c.id=n.cuenta_id
             WHERE n.fecha_novedad BETWEEN :news_from AND :news_to
               AND (' . $newsPredicate . ')'
        );
        $newsStatement->execute($newsParameters);
        $news = $newsStatement->fetch(PDO::FETCH_ASSOC) ?: [];

        $backupParameters = [];
        $backupPredicate = $this->accountPredicate('c', $client, 'coverage', $backupParameters);
        $backupStatement = $this->pdo->prepare(
            'SELECT COUNT(DISTINCT CASE WHEN r.estado<>"ELIMINADO" THEN r.cuenta_id END) respaldadas
             FROM ad_cuentas c LEFT JOIN ad_respaldos r ON r.cuenta_id=c.id
             WHERE c.estado="ACTIVA" AND (' . $backupPredicate . ')'
        );
        $backupStatement->execute($backupParameters);
        $backedUp = (int)$backupStatement->fetchColumn();

        $distributedParameters = [':dist_from' => $from, ':dist_to' => $to];
        $distributedPredicate = $this->valuePredicate('pd_distributed.cliente', $client, 'distributed', $distributedParameters);
        $distributedStatement = $this->pdo->prepare(
            'SELECT COALESCE(SUM(d.valor_distribuido),0)
             FROM ad_distribuciones_usuario_factura d
             INNER JOIN ad_importaciones_distribucion i ON i.id=d.importacion_id
             INNER JOIN ad_perfiles_distribucion_cuenta pd_distributed ON pd_distributed.cuenta_id=d.cuenta_id
             WHERE i.periodo BETWEEN :dist_from AND :dist_to
               AND i.estado IN ("COMPLETADA","CON_PENDIENTES")
               AND (' . $distributedPredicate . ')'
        );
        $distributedStatement->execute($distributedParameters);

        $active = (int)($accounts['activas'] ?? 0);
        return [
            'cuentas' => (int)($accounts['total'] ?? 0),
            'cuentas_activas' => $active,
            'cuentas_en_baja' => (int)($accounts['en_baja'] ?? 0),
            'licencias' => (int)($licenses['licencias'] ?? 0),
            'cuentas_licenciadas' => (int)($licenses['cuentas_licenciadas'] ?? 0),
            'costo_mensual' => round((float)($licenses['costo_mensual'] ?? 0), 2),
            'costo_distribuido' => round((float)$distributedStatement->fetchColumn(), 2),
            'novedades_periodo' => (int)($news['periodo'] ?? 0),
            'novedades_abiertas' => (int)($news['abiertas'] ?? 0),
            'eliminaciones_sin_backup' => (int)($news['sin_backup'] ?? 0),
            'cuentas_respaldadas' => $backedUp,
            'cobertura_backup' => $active > 0 ? round(($backedUp / $active) * 100, 1) : 0.0,
        ];
    }

    private function accountPredicate(string $accountAlias, array $client, string $prefix, array &$parameters): string
    {
        $profile = $this->valuePredicate('pd_cliente.cliente', $client, $prefix . '_pd', $parameters);
        return 'EXISTS (SELECT 1 FROM ad_perfiles_distribucion_cuenta pd_cliente
                         WHERE pd_cliente.cuenta_id=' . $accountAlias . '.id AND (' . $profile . '))';
    }

    private function valuePredicate(string $column, array $client, string $prefix, array &$parameters): string
    {
        $values = $this->clientAliases($client);
        if (!$values) {
            return '0=1';
        }
        $marks = [];
        foreach ($values as $index => $value) {
            $key = ':' . preg_replace('/[^a-z0-9_]/i', '_', $prefix) . '_' . $index;
            $marks[] = $key;
            $parameters[$key] = $value;
        }
        return 'UPPER(TRIM(COALESCE(' . $column . ',""))) IN (' . implode(',', $marks) . ')';
    }

    private function pendingReassignmentPredicate(string $column): string
    {
        return 'REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(' . $column . ',""))),"/",""),".","")," ","")="NA"';
    }

    /**
     * Lee el último archivo importado que contiene la hoja SHAREPOINT. La
     * columna P (CU3-CLIENTE) es la fuente autoritativa de este control.
     */
    private function sharepointPendingProfiles(): array
    {
        $statement = $this->pdo->query(
            'SELECT archivo_ruta FROM ad_importaciones_distribucion
             WHERE NULLIF(TRIM(archivo_ruta),"") IS NOT NULL
             ORDER BY created_at DESC,id DESC LIMIT 1'
        );
        $relativePath = (string)$statement->fetchColumn();
        if ($relativePath === '') {
            return [];
        }

        $storagePath = realpath((string)ad_config('storage_path'));
        $filePath = realpath((string)ad_config('storage_path') . DIRECTORY_SEPARATOR . ltrim($relativePath, '/\\'));
        if ($storagePath === false || $filePath === false || !is_file($filePath)) {
            return [];
        }
        $storagePrefix = rtrim(str_replace('\\', '/', $storagePath), '/') . '/';
        $normalizedFile = str_replace('\\', '/', $filePath);
        if (strpos(mb_strtolower($normalizedFile, 'UTF-8'), mb_strtolower($storagePrefix, 'UTF-8')) !== 0) {
            return [];
        }

        try {
            $reader = new SimpleXlsxReader($filePath);
            $sheetName = null;
            foreach ($reader->sheetNames() as $name) {
                if (mb_strtoupper(trim($name), 'UTF-8') === 'SHAREPOINT') {
                    $sheetName = $name;
                    break;
                }
            }
            if ($sheetName === null) {
                return [];
            }

            $profiles = [];
            foreach ($reader->rawRows($sheetName) as $row) {
                if ((int)($row['_row'] ?? 0) <= 1) {
                    continue;
                }
                $client = (string)($row['P'] ?? '');
                if (!ad_is_pending_reassignment_client($client)) {
                    continue;
                }
                $email = ad_email_normalize((string)($row['G'] ?? ''));
                if ($email === '' || strpos($email, '@') === false) {
                    continue;
                }
                $profiles[$email] = [
                    'cu3' => trim((string)($row['O'] ?? '')),
                    'cliente' => 'N/A',
                    'linea_negocio' => trim((string)($row['Q'] ?? '')),
                    'proyecto' => trim((string)($row['R'] ?? '')),
                    'ciudad' => trim((string)($row['N'] ?? '')),
                ];
            }
            return $profiles;
        } catch (Throwable $exception) {
            return [];
        }
    }

    private function clientAliases(array $client): array
    {
        if (isset($client['aliases']) && is_array($client['aliases'])) {
            $aliases = [];
            foreach ($client['aliases'] as $alias) {
                $normalized = ad_normalize_text((string)$alias);
                if (ad_is_valid_dashboard_client($normalized)) {
                    $aliases[$normalized] = $normalized;
                }
            }
            return array_values($aliases);
        }
        $name = ad_normalize_text((string)$client['nombre']);
        return ad_is_valid_dashboard_client($name) ? [$name] : [];
    }

    /**
     * Completa únicamente fabricantes faltantes de planes históricos a partir
     * de su nombre normalizado.
     */
    public static function normalizeLicenseManufacturer(?string $manufacturer, string $licenseName): string
    {
        $manufacturer = trim((string)$manufacturer);
        if ($manufacturer !== '' && ad_normalize_text($manufacturer) !== 'SIN FABRICANTE') {
            return $manufacturer;
        }

        $license = ad_normalize_text($licenseName);
        $microsoftProducts = [
            'MICROSOFT 365', 'OFFICE 365', 'EXCHANGE ONLINE', 'ONEDRIVE',
            'PLANNER', 'PROJECT', 'POWER BI',
        ];
        foreach ($microsoftProducts as $product) {
            if (strpos($license, $product) !== false) {
                return 'MICROSOFT';
            }
        }

        $googleProducts = ['G SUITE', 'GOOGLE WORKSPACE', 'GOOGLE DRIVE', 'GOOGLE MEET', 'GOOGLE VAULT'];
        foreach ($googleProducts as $product) {
            if (strpos($license, $product) !== false) {
                return 'GOOGLE';
            }
        }

        return $manufacturer;
    }

    private function normalizeLicenseManufacturers(array $rows): array
    {
        foreach ($rows as &$row) {
            $row['licencia'] = $this->canonicalLicenseName((string)($row['licencia'] ?? ''));
            $row['fabricante'] = self::normalizeLicenseManufacturer(
                isset($row['fabricante']) ? (string)$row['fabricante'] : null,
                (string)($row['licencia'] ?? '')
            );
        }
        unset($row);
        return $rows;
    }

    private function canonicalLicenseName(string $license): string
    {
        $normalized = ad_normalize_text($license);
        if (in_array($normalized, ['EXCHANGE ONLINE PLAN 1', 'EXCHANGE ONLINE (PLAN 1)'], true)) {
            return 'EXCHANGE ONLINE (PLAN 1)';
        }
        return $license;
    }

    private function chartRows(array $rows): array
    {
        return array_map(static function (array $row): array {
            $item = ['label' => (string)$row['etiqueta'], 'value' => (float)$row['valor']];
            if (array_key_exists('costo', $row)) {
                $item['cost'] = (float)$row['costo'];
            }
            return $item;
        }, $rows);
    }

    private function months(string $from, string $to): array
    {
        $months = [];
        $names = [1=>'Ene',2=>'Feb',3=>'Mar',4=>'Abr',5=>'May',6=>'Jun',7=>'Jul',8=>'Ago',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dic'];
        $cursor = (new DateTimeImmutable($from))->modify('first day of this month');
        $end = (new DateTimeImmutable($to))->modify('first day of this month');
        while ($cursor <= $end) {
            $months[$cursor->format('Y-m')] = $names[(int)$cursor->format('n')] . ' ' . $cursor->format('y');
            $cursor = $cursor->modify('+1 month');
        }
        return $months;
    }

    private function trendValues(array $months, array $rows): array
    {
        $values = array_fill_keys(array_keys($months), 0.0);
        foreach ($rows as $row) {
            $key = (string)$row['periodo'];
            if (array_key_exists($key, $values)) {
                $values[$key] = (float)$row['valor'];
            }
        }
        return array_values($values);
    }
}
