<?php
declare(strict_types=1);

final class InvoiceDistributionService
{
    private PDO $pdo;
    private bool $reprocessed = false;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function wasReprocessed(): bool
    {
        return $this->reprocessed;
    }

    public function importWorkbook(
        int $invoiceId,
        string $filePath,
        string $originalName,
        string $relativePath,
        ?int $userId
    ): int {
        $invoice = $this->invoice($invoiceId);
        $hash = hash_file('sha256', $filePath);
        if ($hash === false) {
            throw new RuntimeException('No fue posible calcular la huella del archivo.');
        }

        $this->reprocessed = false;
        $duplicate = $this->pdo->prepare(
            'SELECT id, archivo_ruta FROM ad_importaciones_distribucion
             WHERE factura_id=:factura AND archivo_hash=:hash LIMIT 1'
        );
        $duplicate->execute([':factura' => $invoiceId, ':hash' => $hash]);
        $existingImport = $duplicate->fetch(PDO::FETCH_ASSOC) ?: null;

        $reader = new SimpleXlsxReader($filePath);
        $sharepointSheet = $this->sheetName($reader, ['SHAREPOINT']);
        $adminSheet = $this->sheetName($reader, ['BASE ADMIN', 'BASE_ADMIN']);
        if ($sharepointSheet === null || $adminSheet === null) {
            throw new RuntimeException(
                'El archivo debe contener las hojas SHAREPOINT y BASE ADMIN.'
            );
        }

        $cuSheet = $this->sheetName($reader, ['CUS', 'CU']);
        $warehouseSheet = $this->sheetName($reader, ['CONCATEN ALMACENES', 'ALMACENES']);
        $integralSheet = $this->sheetName($reader, ['INTEGRALES R3', 'INTEGRALES']);

        $sharepoint = $this->sharepointRows($reader, $sharepointSheet);
        [$cu1Catalog, $cu3Catalog] = $cuSheet === null
            ? [[], []]
            : $this->costCenterCatalogs($reader, $cuSheet);
        $warehouses = $warehouseSheet === null
            ? []
            : $this->warehouseCatalog($reader, $warehouseSheet);
        $integralRules = $integralSheet === null
            ? []
            : $this->integralRules($reader, $integralSheet);
        $accounts = $this->accountCatalog();
        $adminEmailCounts = $this->adminEmailCounts($reader, $adminSheet);

        $this->pdo->beginTransaction();
        try {
            $this->syncMasterData(
                $reader,
                $adminSheet,
                $sharepoint,
                $cu1Catalog,
                $cu3Catalog,
                $warehouses,
                $integralRules,
                $accounts,
                $userId
            );
            $sharepointClients = [];
            foreach ($sharepoint as $sharepointRow) {
                $clientName = $this->text($sharepointRow['P'] ?? '');
                if ($clientName !== '') {
                    $sharepointClients[] = $clientName;
                }
            }
            (new ClientDashboardService($this->pdo))->syncClientCatalog($sharepointClients, true);
            if ($existingImport !== null) {
                $importId = (int)$existingImport['id'];
                $this->reprocessed = true;
                $deleteRows = $this->pdo->prepare(
                    'DELETE FROM ad_distribuciones_usuario_factura
                     WHERE importacion_id=:id'
                );
                $deleteRows->execute([':id' => $importId]);
                $resetImport = $this->pdo->prepare(
                    'UPDATE ad_importaciones_distribucion
                     SET periodo=:periodo, archivo_nombre=:nombre,
                         estado="PROCESANDO", usuarios_fuente=0, usuarios_ok=0,
                         usuarios_pendientes=0, registros_distribucion=0,
                         total_fuente=0, total_distribuido=0,
                         diferencia_factura=0, mensaje=NULL, created_by=:usuario
                     WHERE id=:id'
                );
                $resetImport->execute([
                    ':periodo' => $invoice['periodo_desde'] ?: $invoice['fecha_emision'],
                    ':nombre' => mb_substr($originalName, 0, 255),
                    ':usuario' => $userId,
                    ':id' => $importId,
                ]);
            } else {
                $create = $this->pdo->prepare(
                    'INSERT INTO ad_importaciones_distribucion
                     (factura_id, periodo, archivo_nombre, archivo_ruta, archivo_hash,
                      estado, created_by)
                     VALUES (:factura, :periodo, :nombre, :ruta, :hash, "PROCESANDO", :usuario)'
                );
                $create->execute([
                    ':factura' => $invoiceId,
                    ':periodo' => $invoice['periodo_desde'] ?: $invoice['fecha_emision'],
                    ':nombre' => mb_substr($originalName, 0, 255),
                    ':ruta' => $relativePath,
                    ':hash' => $hash,
                    ':usuario' => $userId,
                ]);
                $importId = (int)$this->pdo->lastInsertId();
            }

            $insert = $this->distributionInsertStatement();
            $sourceUsers = 0;
            $okUsers = 0;
            $pendingUsers = 0;
            $distributionRows = 0;
            $sourceTotal = 0.0;
            $distributedTotal = 0.0;

            foreach ($reader->rawRows($adminSheet) as $adminRow) {
                $rowNumber = (int)($adminRow['_row'] ?? 0);
                if ($rowNumber <= 1) {
                    continue;
                }

                $email = ad_email_normalize($this->text($adminRow['D'] ?? ''));
                if ($email === '' || strpos($email, '@') === false) {
                    continue;
                }

                $sourceUsers++;
                $cost = $this->money($adminRow['C'] ?? 0);
                $sourceTotal += $cost;
                $planOriginal = $this->text($adminRow['B'] ?? '');
                $planNormalized = $this->normalizePlan($planOriginal);
                $isDuplicate = ($adminEmailCounts[$email] ?? 0) > 1;

                $sp = $sharepoint[$email] ?? [];
                $cu1 = $this->code($sp['K'] ?? '');
                $cu3 = $this->code($sp['O'] ?? '');
                $cu1Data = $cu1Catalog[$cu1] ?? [];
                $cu3Data = $cu3Catalog[$cu3] ?? [];

                $process = $this->firstText([$sp['L'] ?? '', $cu1Data['proceso'] ?? '', $adminRow['O'] ?? '']);
                $regional = $this->firstText([$sp['M'] ?? '', $cu1Data['regional'] ?? '']);
                $city = $this->firstText([$sp['N'] ?? '', $cu1Data['ciudad'] ?? '', $adminRow['M'] ?? '']);
                // El cliente de la cuenta es autoritativo desde SHAREPOINT,
                // columna P (CU3-CLIENTE). CONCATEN ALMACENES se usa solamente
                // para resolver el código de almacén.
                $client = $this->text($sp['P'] ?? '');
                $businessLine = $this->firstText([$sp['Q'] ?? '', $cu3Data['linea'] ?? '']);
                $project = $this->firstText([$sp['R'] ?? '', $cu3Data['proyecto'] ?? '']);
                $warehouseKey = $cu1 . $cu3;
                $warehouse = $warehouses[$warehouseKey]['codigo'] ?? '';
                $accountId = $accounts[$email] ?? null;

                $status = $this->status(
                    $cu1,
                    $cu3,
                    $accountId,
                    $warehouse,
                    $isDuplicate
                );
                if ($status === 'OK') {
                    $okUsers++;
                } else {
                    $pendingUsers++;
                }

                $base = [
                    'importacion_id' => $importId,
                    'cuenta_id' => $accountId,
                    'fila_origen' => $rowNumber,
                    'fila_sharepoint' => isset($sp['_row']) ? (int)$sp['_row'] : null,
                    'correo' => $email,
                    'plan_original' => $planOriginal,
                    'plan_normalizado' => $planNormalized,
                    'valor_base' => $cost,
                    'cu1' => $cu1,
                    'proceso_cu1' => $process,
                    'regional' => $regional,
                    'ciudad' => $city,
                    'cu3' => $cu3,
                    'cliente' => $client,
                    'linea_negocio' => $businessLine,
                    'proyecto' => $project,
                    'grupo' => $this->text($sp['S'] ?? ''),
                    'empresa' => $this->text($sp['T'] ?? ''),
                    'proceso_general' => $this->text($sp['U'] ?? ''),
                    'tipo_proyecto' => $this->firstText([$sp['V'] ?? '', $cu3Data['linea_temp'] ?? '']),
                    'almacen' => $warehouse,
                    'estado' => $status,
                    'observaciones' => $this->text($sp['H'] ?? ''),
                ];

                $isIntegral = $this->isClaroIntegral($base, $cu3Data) && $integralRules !== [];
                if ($isIntegral) {
                    $allocated = 0.0;
                    $lastIndex = count($integralRules) - 1;
                    foreach ($integralRules as $index => $rule) {
                        $value = $index === $lastIndex
                            ? round($cost - $allocated, 2)
                            : round($cost * (float)$rule['porcentaje'], 2);
                        $allocated += $value;
                        $row = $base;
                        $row['tipo_distribucion'] = 'INTEGRAL_R3';
                        $row['porcentaje'] = (float)$rule['porcentaje'];
                        $row['valor_distribuido'] = $value;
                        $row['cliente'] = (string)$rule['cliente'];
                        $row['linea_negocio'] = (string)$rule['linea'];
                        $row['ciudad'] = (string)$rule['ciudad'];
                        $row['proyecto'] = (string)$rule['proyecto'];
                        $this->insertDistribution($insert, $row);
                        $distributionRows++;
                        $distributedTotal += $value;
                    }
                } else {
                    $base['tipo_distribucion'] = 'DIRECTA';
                    $base['porcentaje'] = 1.0;
                    $base['valor_distribuido'] = round($cost, 2);
                    $this->insertDistribution($insert, $base);
                    $distributionRows++;
                    $distributedTotal += round($cost, 2);
                }
            }

            if ($sourceUsers === 0) {
                throw new RuntimeException('La hoja BASE ADMIN no contiene usuarios válidos para distribuir.');
            }

            $difference = round($sourceTotal - (float)$invoice['subtotal'], 2);
            $hasPending = $pendingUsers > 0 || abs($difference) > 0.02;
            $message = abs($difference) > 0.02
                ? 'El total del archivo presenta una diferencia de ' . ad_money($difference, (string)$invoice['moneda']) . ' frente al subtotal de la factura.'
                : null;

            $update = $this->pdo->prepare(
                'UPDATE ad_importaciones_distribucion
                 SET estado=:estado, usuarios_fuente=:fuente, usuarios_ok=:ok,
                     usuarios_pendientes=:pendientes, registros_distribucion=:registros,
                     total_fuente=:total_fuente, total_distribuido=:total_distribuido,
                     diferencia_factura=:diferencia, mensaje=:mensaje
                 WHERE id=:id'
            );
            $update->execute([
                ':estado' => $hasPending ? 'CON_PENDIENTES' : 'COMPLETADA',
                ':fuente' => $sourceUsers,
                ':ok' => $okUsers,
                ':pendientes' => $pendingUsers,
                ':registros' => $distributionRows,
                ':total_fuente' => round($sourceTotal, 2),
                ':total_distribuido' => round($distributedTotal, 2),
                ':diferencia' => $difference,
                ':mensaje' => $message,
                ':id' => $importId,
            ]);

            $invoiceStatus = $hasPending ? 'CON_NOVEDAD' : 'EN_VALIDACION';
            $statusUpdate = $this->pdo->prepare(
                'UPDATE ad_facturas SET estado=:estado
                 WHERE id=:id AND estado IN ("RECIBIDA","EN_VALIDACION","CON_NOVEDAD")'
            );
            $statusUpdate->execute([':estado' => $invoiceStatus, ':id' => $invoiceId]);

            AuditService::log(
                $this->pdo,
                'ad_importaciones_distribucion',
                $importId,
                'IMPORTAR_DISTRIBUCION',
                null,
                [
                    'factura_id' => $invoiceId,
                    'reprocesada' => $this->reprocessed,
                    'usuarios' => $sourceUsers,
                    'pendientes' => $pendingUsers,
                    'total_fuente' => round($sourceTotal, 2),
                    'diferencia_factura' => $difference,
                ]
            );

            $this->pdo->commit();
            return $importId;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $e;
        }
    }

    public function generateFromDatabase(int $invoiceId, ?int $userId): int
    {
        $invoice = $this->invoice($invoiceId);
        $integralRules = $this->databaseIntegralRules();
        $rowsStatement = $this->pdo->prepare(
            'SELECT c.id cuenta_id, c.correo,
                    COALESCE(NULLIF(pd.plan_fuente,""),p.nombre) plan_original,
                    COALESCE(pd.costo_mensual,al.valor_unitario_asignado) valor_base,
                    COALESCE(NULLIF(pd.moneda,""),al.moneda) moneda,
                    pd.cu1, pd.proceso_cu1, pd.regional, pd.ciudad,
                    pd.cu3, pd.cliente, pd.linea_negocio, pd.proyecto,
                    pd.grupo, pd.empresa, pd.proceso_general, pd.tipo_proyecto,
                    pd.observaciones,
                    c1.proceso proceso_catalogo, c1.regional regional_catalogo,
                    c1.ciudad ciudad_catalogo,
                    c3.cliente cliente_catalogo, c3.linea_negocio linea_catalogo,
                    c3.proyecto proyecto_catalogo, c3.linea_temp
             FROM ad_asignaciones_licencia al
             INNER JOIN ad_cuentas c ON c.id=al.cuenta_id
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             INNER JOIN ad_planes p ON p.id=s.plan_id
             LEFT JOIN ad_perfiles_distribucion_cuenta pd ON pd.cuenta_id=c.id
             LEFT JOIN ad_cu1_catalogo c1 ON c1.codigo=pd.cu1 AND c1.activo=1
             LEFT JOIN ad_cu3_catalogo c3 ON c3.codigo=pd.cu3 AND c3.activo=1
             WHERE al.estado="ACTIVA" AND c.estado="ACTIVA"
               AND (s.proveedor_id=:proveedor OR s.proveedor_id IS NULL)
               AND (
                    pd.costo_mensual IS NULL
                    OR al.id=(
                        SELECT MIN(al2.id)
                        FROM ad_asignaciones_licencia al2
                        INNER JOIN ad_suscripciones s2 ON s2.id=al2.suscripcion_id
                        WHERE al2.cuenta_id=c.id AND al2.estado="ACTIVA"
                          AND (s2.proveedor_id=:proveedor_perfil OR s2.proveedor_id IS NULL)
                    )
               )
             ORDER BY c.correo, al.id'
        );
        $rowsStatement->execute([
            ':proveedor' => (int)$invoice['proveedor_id'],
            ':proveedor_perfil' => (int)$invoice['proveedor_id'],
        ]);
        $sourceRows = $rowsStatement->fetchAll(PDO::FETCH_ASSOC);
        if ($sourceRows === []) {
            throw new RuntimeException('No existen licencias activas para generar la distribución de esta factura.');
        }

        $warehouseStatement = $this->pdo->query(
            'SELECT clave, codigo_almacen codigo FROM ad_almacenes_distribucion WHERE activo=1'
        );
        $warehouses = [];
        foreach ($warehouseStatement->fetchAll(PDO::FETCH_ASSOC) as $warehouseRow) {
            $warehouses[$this->code($warehouseRow['clave'])] = (string)$warehouseRow['codigo'];
        }

        $this->pdo->beginTransaction();
        try {
            $hash = hash('sha256', 'DB|' . $invoiceId . '|' . microtime(true) . '|' . bin2hex(random_bytes(12)));
            $create = $this->pdo->prepare(
                'INSERT INTO ad_importaciones_distribucion
                 (factura_id, periodo, archivo_nombre, archivo_ruta, archivo_hash, estado, created_by)
                 VALUES (:factura, :periodo, "GENERADO DESDE BASE DE DATOS", "", :hash, "PROCESANDO", :usuario)'
            );
            $create->execute([
                ':factura' => $invoiceId,
                ':periodo' => $invoice['periodo_desde'] ?: $invoice['fecha_emision'],
                ':hash' => $hash,
                ':usuario' => $userId,
            ]);
            $importId = (int)$this->pdo->lastInsertId();
            $insert = $this->distributionInsertStatement();
            $sourceUsers = 0;
            $okUsers = 0;
            $pendingUsers = 0;
            $distributionRows = 0;
            $sourceTotal = 0.0;
            $distributedTotal = 0.0;

            foreach ($sourceRows as $index => $source) {
                $cost = round((float)$source['valor_base'], 2);
                $sourceTotal += $cost;
                $sourceUsers++;
                $cu1 = $this->code($source['cu1'] ?? '');
                $cu3 = $this->code($source['cu3'] ?? '');
                $warehouse = $warehouses[$cu1 . $cu3] ?? '';
                $status = $this->status($cu1, $cu3, (int)$source['cuenta_id'], $warehouse, false);
                if ($status === 'OK') {
                    $okUsers++;
                } else {
                    $pendingUsers++;
                }
                $base = [
                    'importacion_id' => $importId,
                    'cuenta_id' => (int)$source['cuenta_id'],
                    'fila_origen' => $index + 1,
                    'fila_sharepoint' => null,
                    'correo' => ad_email_normalize((string)$source['correo']),
                    'plan_original' => (string)$source['plan_original'],
                    'plan_normalizado' => $this->normalizePlan((string)$source['plan_original']),
                    'valor_base' => $cost,
                    'cu1' => $cu1,
                    'proceso_cu1' => $this->firstText([$source['proceso_cu1'] ?? '', $source['proceso_catalogo'] ?? '']),
                    'regional' => $this->firstText([$source['regional'] ?? '', $source['regional_catalogo'] ?? '']),
                    'ciudad' => $this->firstText([$source['ciudad'] ?? '', $source['ciudad_catalogo'] ?? '']),
                    'cu3' => $cu3,
                    'cliente' => $this->firstText([$source['cliente'] ?? '', $source['cliente_catalogo'] ?? '']),
                    'linea_negocio' => $this->firstText([$source['linea_negocio'] ?? '', $source['linea_catalogo'] ?? '']),
                    'proyecto' => $this->firstText([$source['proyecto'] ?? '', $source['proyecto_catalogo'] ?? '']),
                    'grupo' => $this->text($source['grupo'] ?? ''),
                    'empresa' => $this->text($source['empresa'] ?? ''),
                    'proceso_general' => $this->text($source['proceso_general'] ?? ''),
                    'tipo_proyecto' => $this->firstText([$source['tipo_proyecto'] ?? '', $source['linea_temp'] ?? '']),
                    'almacen' => $warehouse,
                    'estado' => $status,
                    'observaciones' => $this->text($source['observaciones'] ?? ''),
                ];
                $isIntegral = $this->isClaroIntegral($base, ['linea_temp' => $source['linea_temp'] ?? ''])
                    && $integralRules !== [];
                if ($isIntegral) {
                    $allocated = 0.0;
                    $lastIndex = count($integralRules) - 1;
                    foreach ($integralRules as $ruleIndex => $rule) {
                        $value = $ruleIndex === $lastIndex
                            ? round($cost - $allocated, 2)
                            : round($cost * (float)$rule['porcentaje'], 2);
                        $allocated += $value;
                        $row = $base;
                        $row['tipo_distribucion'] = 'INTEGRAL_R3';
                        $row['porcentaje'] = (float)$rule['porcentaje'];
                        $row['valor_distribuido'] = $value;
                        $row['cliente'] = (string)$rule['cliente'];
                        $row['linea_negocio'] = (string)$rule['linea'];
                        $row['ciudad'] = (string)$rule['ciudad'];
                        $row['proyecto'] = (string)$rule['proyecto'];
                        $this->insertDistribution($insert, $row);
                        $distributionRows++;
                        $distributedTotal += $value;
                    }
                } else {
                    $base['tipo_distribucion'] = 'DIRECTA';
                    $base['porcentaje'] = 1.0;
                    $base['valor_distribuido'] = $cost;
                    $this->insertDistribution($insert, $base);
                    $distributionRows++;
                    $distributedTotal += $cost;
                }
            }

            $difference = round($sourceTotal - (float)$invoice['subtotal'], 2);
            $hasPending = $pendingUsers > 0 || abs($difference) > 0.02;
            $message = abs($difference) > 0.02
                ? 'La base de datos presenta una diferencia de ' . ad_money($difference, (string)$invoice['moneda']) . ' frente al subtotal de la factura.'
                : null;
            $update = $this->pdo->prepare(
                'UPDATE ad_importaciones_distribucion
                 SET estado=:estado, usuarios_fuente=:fuente, usuarios_ok=:ok,
                     usuarios_pendientes=:pendientes, registros_distribucion=:registros,
                     total_fuente=:total_fuente, total_distribuido=:total_distribuido,
                     diferencia_factura=:diferencia, mensaje=:mensaje WHERE id=:id'
            );
            $update->execute([
                ':estado' => $hasPending ? 'CON_PENDIENTES' : 'COMPLETADA',
                ':fuente' => $sourceUsers,
                ':ok' => $okUsers,
                ':pendientes' => $pendingUsers,
                ':registros' => $distributionRows,
                ':total_fuente' => round($sourceTotal, 2),
                ':total_distribuido' => round($distributedTotal, 2),
                ':diferencia' => $difference,
                ':mensaje' => $message,
                ':id' => $importId,
            ]);
            $invoiceUpdate = $this->pdo->prepare(
                'UPDATE ad_facturas SET estado=:estado
                 WHERE id=:id AND estado IN ("RECIBIDA","EN_VALIDACION","CON_NOVEDAD")'
            );
            $invoiceUpdate->execute([
                ':estado' => $hasPending ? 'CON_NOVEDAD' : 'EN_VALIDACION',
                ':id' => $invoiceId,
            ]);
            AuditService::log($this->pdo, 'ad_importaciones_distribucion', $importId, 'GENERAR_DISTRIBUCION_BD', null, [
                'factura_id' => $invoiceId,
                'registros_fuente' => $sourceUsers,
                'pendientes' => $pendingUsers,
                'total_fuente' => round($sourceTotal, 2),
            ]);
            $this->pdo->commit();
            return $importId;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $e;
        }
    }

    public function updateDistribution(int $importId, int $rowId, array $data): void
    {
        $rowStatement = $this->pdo->prepare(
            'SELECT d.*, i.factura_id
             FROM ad_distribuciones_usuario_factura d
             INNER JOIN ad_importaciones_distribucion i ON i.id=d.importacion_id
             WHERE d.id=:row AND d.importacion_id=:importacion'
        );
        $rowStatement->execute([':row' => $rowId, ':importacion' => $importId]);
        $row = $rowStatement->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException('No se encontró el registro de distribución.');
        }

        $email = ad_email_normalize((string)($data['correo'] ?? $row['correo']));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('El correo indicado no es válido.');
        }
        $cu1 = $this->code($data['cu1'] ?? $row['cu1']);
        $cu3 = $this->code($data['cu3'] ?? $row['cu3']);
        $warehouse = $this->code($data['almacen'] ?? $row['almacen']);
        $account = $this->pdo->prepare('SELECT id FROM ad_cuentas WHERE correo_normalizado=:correo LIMIT 1');
        $account->execute([':correo' => $email]);
        $accountId = $account->fetchColumn();
        $accountId = $accountId === false ? null : (int)$accountId;
        $duplicates = $this->pdo->prepare(
            'SELECT COUNT(DISTINCT fila_origen)
             FROM ad_distribuciones_usuario_factura
             WHERE importacion_id=:importacion AND correo=:correo
               AND fila_origen<>:fila'
        );
        $duplicates->execute([
            ':importacion' => $importId,
            ':correo' => $email,
            ':fila' => (int)$row['fila_origen'],
        ]);
        $status = $this->status($cu1, $cu3, $accountId, $warehouse, (int)$duplicates->fetchColumn() > 0);

        $this->pdo->beginTransaction();
        try {
            $updateGroup = $this->pdo->prepare(
                'UPDATE ad_distribuciones_usuario_factura
                 SET cuenta_id=:cuenta, correo=:correo, cu1=:cu1, proceso_cu1=:proceso,
                     regional=:regional, cu3=:cu3, almacen=:almacen, estado=:estado
                 WHERE importacion_id=:importacion AND fila_origen=:fila'
            );
            $updateGroup->execute([
                ':cuenta' => $accountId,
                ':correo' => $email,
                ':cu1' => $cu1,
                ':proceso' => $this->text($data['proceso_cu1'] ?? $row['proceso_cu1']),
                ':regional' => $this->text($data['regional'] ?? $row['regional']),
                ':cu3' => $cu3,
                ':almacen' => $warehouse,
                ':estado' => $status,
                ':importacion' => $importId,
                ':fila' => (int)$row['fila_origen'],
            ]);

            $update = $this->pdo->prepare(
                'UPDATE ad_distribuciones_usuario_factura
                 SET ciudad=:ciudad, cliente=:cliente, linea_negocio=:linea,
                     proyecto=:proyecto, observaciones=:observaciones
                 WHERE id=:id AND importacion_id=:importacion'
            );
            $update->execute([
                ':ciudad' => $this->text($data['ciudad'] ?? $row['ciudad']),
                ':cliente' => $this->text($data['cliente'] ?? $row['cliente']),
                ':linea' => $this->text($data['linea_negocio'] ?? $row['linea_negocio']),
                ':proyecto' => $this->text($data['proyecto'] ?? $row['proyecto']),
                ':observaciones' => mb_substr($this->text($data['observaciones'] ?? $row['observaciones']), 0, 500),
                ':id' => $rowId,
                ':importacion' => $importId,
            ]);

            $this->refreshEmailStatuses($importId, [(string)$row['correo'], $email]);
            $this->refreshImport($importId);
            AuditService::log($this->pdo, 'ad_distribuciones_usuario_factura', $rowId, 'CORREGIR_DISTRIBUCION', $row, $data);
            $this->pdo->commit();
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $e;
        }
    }

    private function refreshImport(int $importId): void
    {
        $groups = $this->pdo->prepare(
            'SELECT fila_origen, SUM(CASE WHEN estado="OK" THEN 0 ELSE 1 END) pendientes
             FROM ad_distribuciones_usuario_factura
             WHERE importacion_id=:id GROUP BY fila_origen'
        );
        $groups->execute([':id' => $importId]);
        $ok = 0;
        $pending = 0;
        foreach ($groups->fetchAll(PDO::FETCH_ASSOC) as $group) {
            if ((int)$group['pendientes'] === 0) {
                $ok++;
            } else {
                $pending++;
            }
        }

        $import = $this->pdo->prepare('SELECT diferencia_factura, factura_id FROM ad_importaciones_distribucion WHERE id=:id');
        $import->execute([':id' => $importId]);
        $importRow = $import->fetch(PDO::FETCH_ASSOC);
        if (!$importRow) {
            return;
        }
        $hasPending = $pending > 0 || abs((float)$importRow['diferencia_factura']) > 0.02;
        $update = $this->pdo->prepare(
            'UPDATE ad_importaciones_distribucion
             SET usuarios_ok=:ok, usuarios_pendientes=:pendientes, estado=:estado
             WHERE id=:id'
        );
        $update->execute([
            ':ok' => $ok,
            ':pendientes' => $pending,
            ':estado' => $hasPending ? 'CON_PENDIENTES' : 'COMPLETADA',
            ':id' => $importId,
        ]);
        $invoice = $this->pdo->prepare(
            'UPDATE ad_facturas SET estado=:estado
             WHERE id=:id AND estado IN ("RECIBIDA","EN_VALIDACION","CON_NOVEDAD")'
        );
        $invoice->execute([
            ':estado' => $hasPending ? 'CON_NOVEDAD' : 'EN_VALIDACION',
            ':id' => (int)$importRow['factura_id'],
        ]);
    }

    private function refreshEmailStatuses(int $importId, array $emails): void
    {
        $select = $this->pdo->prepare(
            'SELECT id, cu1, cu3, cuenta_id, almacen
             FROM ad_distribuciones_usuario_factura
             WHERE importacion_id=:importacion AND correo=:correo'
        );
        $update = $this->pdo->prepare(
            'UPDATE ad_distribuciones_usuario_factura SET estado=:estado WHERE id=:id'
        );
        foreach (array_unique($emails) as $email) {
            $normalizedEmail = ad_email_normalize((string)$email);
            if ($normalizedEmail === '') {
                continue;
            }
            $select->execute([':importacion' => $importId, ':correo' => $normalizedEmail]);
            $emailRows = $select->fetchAll(PDO::FETCH_ASSOC);
            $sourceCountStatement = $this->pdo->prepare(
                'SELECT COUNT(DISTINCT fila_origen)
                 FROM ad_distribuciones_usuario_factura
                 WHERE importacion_id=:importacion AND correo=:correo'
            );
            $sourceCountStatement->execute([':importacion' => $importId, ':correo' => $normalizedEmail]);
            $duplicate = (int)$sourceCountStatement->fetchColumn() > 1;
            foreach ($emailRows as $emailRow) {
                $newStatus = $this->status(
                    $this->code($emailRow['cu1'] ?? ''),
                    $this->code($emailRow['cu3'] ?? ''),
                    $emailRow['cuenta_id'] === null ? null : (int)$emailRow['cuenta_id'],
                    $this->code($emailRow['almacen'] ?? ''),
                    $duplicate
                );
                $update->execute([':estado' => $newStatus, ':id' => (int)$emailRow['id']]);
            }
        }
    }

    private function invoice(int $invoiceId): array
    {
        $statement = $this->pdo->prepare(
            'SELECT id, proveedor_id, numero_factura, periodo_desde, fecha_emision, moneda, subtotal
             FROM ad_facturas WHERE id=:id'
        );
        $statement->execute([':id' => $invoiceId]);
        $invoice = $statement->fetch(PDO::FETCH_ASSOC);
        if (!$invoice) {
            throw new RuntimeException('No se encontró la factura seleccionada.');
        }
        return $invoice;
    }

    private function accountCatalog(): array
    {
        $result = [];
        $rows = $this->pdo->query('SELECT id, correo_normalizado FROM ad_cuentas')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $result[ad_email_normalize((string)$row['correo_normalizado'])] = (int)$row['id'];
        }
        return $result;
    }

    private function syncMasterData(
        SimpleXlsxReader $reader,
        string $adminSheet,
        array $sharepoint,
        array $cu1Catalog,
        array $cu3Catalog,
        array $warehouses,
        array $integralRules,
        array $accounts,
        ?int $userId
    ): void {
        $this->pdo->exec('UPDATE ad_cu1_catalogo SET activo=0 WHERE fuente="EXCEL"');
        $this->pdo->exec('UPDATE ad_cu3_catalogo SET activo=0 WHERE fuente="EXCEL"');
        $this->pdo->exec('UPDATE ad_almacenes_distribucion SET activo=0 WHERE fuente="EXCEL"');
        $this->pdo->exec('UPDATE ad_reglas_integrales SET activo=0 WHERE fuente="EXCEL"');

        $cu1Statement = $this->pdo->prepare(
            'INSERT INTO ad_cu1_catalogo
             (codigo, descripcion_corta, descripcion, proceso, regional, ciudad, activo, fuente, updated_by)
             VALUES (:codigo,:corta,:descripcion,:proceso,:regional,:ciudad,1,"EXCEL",:usuario)
             ON DUPLICATE KEY UPDATE
              descripcion_corta=IF(fuente="MANUAL",descripcion_corta,VALUES(descripcion_corta)),
              descripcion=IF(fuente="MANUAL",descripcion,VALUES(descripcion)),
              proceso=IF(fuente="MANUAL",proceso,VALUES(proceso)),
              regional=IF(fuente="MANUAL",regional,VALUES(regional)),
              ciudad=IF(fuente="MANUAL",ciudad,VALUES(ciudad)),
              activo=IF(fuente="MANUAL",activo,1),
              fuente=IF(fuente="MANUAL",fuente,"EXCEL"), updated_by=VALUES(updated_by)'
        );
        foreach ($cu1Catalog as $code => $row) {
            $cu1Statement->execute([
                ':codigo' => $code,
                ':corta' => $row['descripcion_corta'] ?? null,
                ':descripcion' => $row['descripcion'] ?? null,
                ':proceso' => $row['proceso'] ?? null,
                ':regional' => $row['regional'] ?? null,
                ':ciudad' => $row['ciudad'] ?? null,
                ':usuario' => $userId,
            ]);
        }

        $cu3Statement = $this->pdo->prepare(
            'INSERT INTO ad_cu3_catalogo
             (codigo, descripcion_corta, descripcion, cliente, linea_negocio, proyecto, linea_temp, activo, fuente, updated_by)
             VALUES (:codigo,:corta,:descripcion,:cliente,:linea,:proyecto,:linea_temp,1,"EXCEL",:usuario)
             ON DUPLICATE KEY UPDATE
              descripcion_corta=IF(fuente="MANUAL",descripcion_corta,VALUES(descripcion_corta)),
              descripcion=IF(fuente="MANUAL",descripcion,VALUES(descripcion)),
              cliente=IF(fuente="MANUAL",cliente,VALUES(cliente)),
              linea_negocio=IF(fuente="MANUAL",linea_negocio,VALUES(linea_negocio)),
              proyecto=IF(fuente="MANUAL",proyecto,VALUES(proyecto)),
              linea_temp=IF(fuente="MANUAL",linea_temp,VALUES(linea_temp)),
              activo=IF(fuente="MANUAL",activo,1),
              fuente=IF(fuente="MANUAL",fuente,"EXCEL"), updated_by=VALUES(updated_by)'
        );
        foreach ($cu3Catalog as $code => $row) {
            $cu3Statement->execute([
                ':codigo' => $code,
                ':corta' => $row['descripcion_corta'] ?? null,
                ':descripcion' => $row['descripcion'] ?? null,
                ':cliente' => $row['cliente'] ?? null,
                ':linea' => $row['linea'] ?? null,
                ':proyecto' => $row['proyecto'] ?? null,
                ':linea_temp' => $row['linea_temp'] ?? null,
                ':usuario' => $userId,
            ]);
        }

        $warehouseStatement = $this->pdo->prepare(
            'INSERT INTO ad_almacenes_distribucion
             (clave, cu1, cu3, codigo_almacen, descripcion, cliente, activo, fuente, updated_by)
             VALUES (:clave,:cu1,:cu3,:codigo,:descripcion,:cliente,1,"EXCEL",:usuario)
             ON DUPLICATE KEY UPDATE
              cu1=IF(fuente="MANUAL",cu1,VALUES(cu1)),
              cu3=IF(fuente="MANUAL",cu3,VALUES(cu3)),
              codigo_almacen=IF(fuente="MANUAL",codigo_almacen,VALUES(codigo_almacen)),
              descripcion=IF(fuente="MANUAL",descripcion,VALUES(descripcion)),
              cliente=IF(fuente="MANUAL",cliente,VALUES(cliente)),
              activo=IF(fuente="MANUAL",activo,1),
              fuente=IF(fuente="MANUAL",fuente,"EXCEL"), updated_by=VALUES(updated_by)'
        );
        foreach ($warehouses as $key => $row) {
            $warehouseStatement->execute([
                ':clave' => $key,
                ':cu1' => substr($key, 0, 4),
                ':cu3' => substr($key, 4),
                ':codigo' => $row['codigo'],
                ':descripcion' => $row['descripcion'] ?? null,
                ':cliente' => $row['cliente'] ?? null,
                ':usuario' => $userId,
            ]);
        }

        $integralStatement = $this->pdo->prepare(
            'INSERT INTO ad_reglas_integrales
             (clave, cliente, linea_negocio, ciudad, proyecto, ingresos, moneda, porcentaje, activo, fuente, updated_by)
             VALUES (:clave,:cliente,:linea,:ciudad,:proyecto,:ingresos,"USD",:porcentaje,1,"EXCEL",:usuario)
             ON DUPLICATE KEY UPDATE
              cliente=IF(fuente="MANUAL",cliente,VALUES(cliente)),
              linea_negocio=IF(fuente="MANUAL",linea_negocio,VALUES(linea_negocio)),
              ciudad=IF(fuente="MANUAL",ciudad,VALUES(ciudad)),
              proyecto=IF(fuente="MANUAL",proyecto,VALUES(proyecto)),
              ingresos=IF(fuente="MANUAL",ingresos,VALUES(ingresos)),
              moneda=IF(fuente="MANUAL",moneda,"USD"),
              porcentaje=IF(fuente="MANUAL",porcentaje,VALUES(porcentaje)),
              activo=IF(fuente="MANUAL",activo,1),
              fuente=IF(fuente="MANUAL",fuente,"EXCEL"), updated_by=VALUES(updated_by)'
        );
        foreach ($integralRules as $rule) {
            $ruleKey = hash('sha256', ad_normalize_text(
                $rule['cliente'] . '|' . $rule['linea'] . '|' . $rule['ciudad'] . '|' . $rule['proyecto']
            ));
            $integralStatement->execute([
                ':clave' => $ruleKey,
                ':cliente' => $rule['cliente'],
                ':linea' => $rule['linea'],
                ':ciudad' => $rule['ciudad'],
                ':proyecto' => $rule['proyecto'],
                ':ingresos' => $rule['ingresos'],
                ':porcentaje' => $rule['porcentaje'],
                ':usuario' => $userId,
            ]);
        }

        $admin = [];
        foreach ($reader->rawRows($adminSheet) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $email = ad_email_normalize($this->text($row['D'] ?? ''));
            if ($email !== '' && strpos($email, '@') !== false) {
                $admin[$email] = [
                    'plan' => $this->normalizePlan($this->text($row['B'] ?? '')),
                    'costo' => $this->money($row['C'] ?? 0),
                ];
            }
        }
        $profileStatement = $this->pdo->prepare(
            'INSERT INTO ad_perfiles_distribucion_cuenta
             (cuenta_id, plan_fuente, costo_mensual, moneda, cu1, proceso_cu1, regional, ciudad,
              cu3, cliente, linea_negocio, proyecto, grupo, empresa, proceso_general,
              tipo_proyecto, observaciones, fuente, updated_by)
             VALUES (:cuenta,:plan,:costo,"USD",:cu1,:proceso,:regional,:ciudad,
              :cu3,:cliente,:linea,:proyecto,:grupo,:empresa,:proceso_general,
              :tipo_proyecto,:observaciones,"EXCEL",:usuario)
             ON DUPLICATE KEY UPDATE
              plan_fuente=IF(fuente IN ("MANUAL","MOVIMIENTO"),plan_fuente,VALUES(plan_fuente)),
              costo_mensual=IF(fuente IN ("MANUAL","MOVIMIENTO"),costo_mensual,VALUES(costo_mensual)),
              moneda=IF(fuente IN ("MANUAL","MOVIMIENTO"),moneda,VALUES(moneda)),
              cu1=IF(fuente="MANUAL",cu1,VALUES(cu1)),
              proceso_cu1=IF(fuente="MANUAL",proceso_cu1,VALUES(proceso_cu1)),
              regional=IF(fuente="MANUAL",regional,VALUES(regional)),
              ciudad=IF(fuente="MANUAL",ciudad,VALUES(ciudad)),
              cu3=IF(fuente="MANUAL",cu3,VALUES(cu3)),
              cliente=VALUES(cliente),
              linea_negocio=IF(fuente="MANUAL",linea_negocio,VALUES(linea_negocio)),
              proyecto=IF(fuente="MANUAL",proyecto,VALUES(proyecto)),
              grupo=IF(fuente="MANUAL",grupo,VALUES(grupo)),
              empresa=IF(fuente="MANUAL",empresa,VALUES(empresa)),
              proceso_general=IF(fuente="MANUAL",proceso_general,VALUES(proceso_general)),
              tipo_proyecto=IF(fuente="MANUAL",tipo_proyecto,VALUES(tipo_proyecto)),
              observaciones=IF(fuente="MANUAL",observaciones,VALUES(observaciones)),
              fuente=IF(fuente IN ("MANUAL","MOVIMIENTO"),fuente,"EXCEL"),
              updated_by=VALUES(updated_by)'
        );
        foreach ($sharepoint as $email => $row) {
            if (!isset($accounts[$email])) {
                continue;
            }
            $adminRow = $admin[$email] ?? [];
            $profileStatement->execute([
                ':cuenta' => $accounts[$email],
                ':plan' => $adminRow['plan'] ?? $this->normalizePlan($this->text($row['E'] ?? '')),
                ':costo' => $adminRow['costo'] ?? null,
                ':cu1' => $this->code($row['K'] ?? '') ?: null,
                ':proceso' => $this->text($row['L'] ?? '') ?: null,
                ':regional' => $this->text($row['M'] ?? '') ?: null,
                ':ciudad' => $this->text($row['N'] ?? '') ?: null,
                ':cu3' => $this->code($row['O'] ?? '') ?: null,
                ':cliente' => $this->text($row['P'] ?? '') ?: null,
                ':linea' => $this->text($row['Q'] ?? '') ?: null,
                ':proyecto' => $this->text($row['R'] ?? '') ?: null,
                ':grupo' => $this->text($row['S'] ?? '') ?: null,
                ':empresa' => $this->text($row['T'] ?? '') ?: null,
                ':proceso_general' => $this->text($row['U'] ?? '') ?: null,
                ':tipo_proyecto' => $this->text($row['V'] ?? '') ?: null,
                ':observaciones' => $this->text($row['H'] ?? '') ?: null,
                ':usuario' => $userId,
            ]);
        }
    }

    private function databaseIntegralRules(): array
    {
        $rows = $this->pdo->query(
            'SELECT cliente, linea_negocio linea, ciudad, proyecto, ingresos
             FROM ad_reglas_integrales WHERE activo=1 AND ingresos>0 ORDER BY id'
        )->fetchAll(PDO::FETCH_ASSOC);
        $total = 0.0;
        foreach ($rows as $row) {
            $total += (float)$row['ingresos'];
        }
        if ($total <= 0) {
            return [];
        }
        foreach ($rows as &$row) {
            $row['porcentaje'] = (float)$row['ingresos'] / $total;
        }
        unset($row);
        return $rows;
    }

    private function sharepointRows(SimpleXlsxReader $reader, string $sheetName): array
    {
        $result = [];
        foreach ($reader->rawRows($sheetName) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $email = ad_email_normalize($this->text($row['G'] ?? ''));
            if ($email !== '' && strpos($email, '@') !== false) {
                $result[$email] = $row;
            }
        }
        return $result;
    }

    private function adminEmailCounts(SimpleXlsxReader $reader, string $sheetName): array
    {
        $counts = [];
        foreach ($reader->rawRows($sheetName) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $email = ad_email_normalize($this->text($row['D'] ?? ''));
            if ($email !== '' && strpos($email, '@') !== false) {
                $counts[$email] = ($counts[$email] ?? 0) + 1;
            }
        }
        return $counts;
    }

    private function costCenterCatalogs(SimpleXlsxReader $reader, string $sheetName): array
    {
        $cu1 = [];
        $cu3 = [];
        foreach ($reader->rawRows($sheetName) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $cu1Code = $this->code($row['A'] ?? '');
            if ($cu1Code !== '') {
                $cu1[$cu1Code] = [
                    'descripcion_corta' => $this->text($row['B'] ?? ''),
                    'descripcion' => $this->text($row['C'] ?? ''),
                    'proceso' => $this->text($row['D'] ?? ''),
                    'regional' => $this->text($row['E'] ?? ''),
                    'ciudad' => $this->text($row['F'] ?? ''),
                ];
            }
            $cu3Code = $this->code($row['H'] ?? '');
            if ($cu3Code !== '') {
                $cu3[$cu3Code] = [
                    'descripcion_corta' => $this->text($row['I'] ?? ''),
                    'descripcion' => $this->text($row['J'] ?? ''),
                    'cliente' => $this->text($row['K'] ?? ''),
                    'linea' => $this->text($row['L'] ?? ''),
                    'proyecto' => $this->text($row['M'] ?? ''),
                    'linea_temp' => $this->text($row['N'] ?? ''),
                ];
            }
        }
        return [$cu1, $cu3];
    }

    private function warehouseCatalog(SimpleXlsxReader $reader, string $sheetName): array
    {
        $result = [];
        foreach ($reader->rawRows($sheetName) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $key = $this->code($row['A'] ?? '');
            if ($key !== '') {
                $result[$key] = [
                    'codigo' => $this->code($row['B'] ?? ''),
                    'descripcion' => $this->text($row['C'] ?? ''),
                    'cliente' => $this->text($row['D'] ?? ''),
                ];
            }
        }
        return $result;
    }

    private function integralRules(SimpleXlsxReader $reader, string $sheetName): array
    {
        $rules = [];
        $totalRevenue = 0.0;
        foreach ($reader->rawRows($sheetName) as $row) {
            if ((int)($row['_row'] ?? 0) <= 1) {
                continue;
            }
            $revenue = $this->money($row['E'] ?? 0);
            $client = $this->text($row['A'] ?? '');
            $line = $this->text($row['B'] ?? '');
            $city = $this->text($row['C'] ?? '');
            $project = $this->text($row['D'] ?? '');
            if ($revenue <= 0 || $client === '' || $line === '' || $city === '' || $project === '') {
                continue;
            }
            $rules[] = [
                'cliente' => $client,
                'linea' => $line,
                'ciudad' => $city,
                'proyecto' => $project,
                'ingresos' => $revenue,
            ];
            $totalRevenue += $revenue;
        }
        if ($totalRevenue <= 0) {
            return [];
        }
        foreach ($rules as &$rule) {
            $rule['porcentaje'] = (float)$rule['ingresos'] / $totalRevenue;
        }
        unset($rule);
        return $rules;
    }

    private function sheetName(SimpleXlsxReader $reader, array $candidates): ?string
    {
        foreach ($reader->sheetNames() as $sheetName) {
            $normalized = ad_normalize_text($sheetName);
            foreach ($candidates as $candidate) {
                if ($normalized === ad_normalize_text((string)$candidate)) {
                    return $sheetName;
                }
            }
        }
        return null;
    }

    private function status(string $cu1, string $cu3, ?int $accountId, string $warehouse, bool $duplicate): string
    {
        if ($duplicate) {
            return 'DUPLICADO';
        }
        if ($cu1 === '') {
            return 'PENDIENTE_CU1';
        }
        if ($cu3 === '') {
            return 'PENDIENTE_CU3';
        }
        if ($accountId === null) {
            return 'SIN_CUENTA';
        }
        if ($warehouse === '') {
            return 'SIN_ALMACEN';
        }
        return 'OK';
    }

    private function isClaroIntegral(array $base, array $cu3Data): bool
    {
        $client = ad_normalize_text((string)($base['cliente'] ?? ''));
        $lineType = ad_normalize_text((string)($cu3Data['linea_temp'] ?? $base['tipo_proyecto'] ?? ''));
        return strpos($client, 'CLARO') !== false && $lineType === 'INTEGRAL';
    }

    private function distributionInsertStatement(): PDOStatement
    {
        return $this->pdo->prepare(
            'INSERT INTO ad_distribuciones_usuario_factura
             (importacion_id, cuenta_id, fila_origen, fila_sharepoint, correo,
              plan_original, plan_normalizado, valor_base, tipo_distribucion,
              porcentaje, valor_distribuido, cu1, proceso_cu1, regional, ciudad,
              cu3, cliente, linea_negocio, proyecto, grupo, empresa,
              proceso_general, tipo_proyecto, almacen, estado, observaciones)
             VALUES
             (:importacion_id, :cuenta_id, :fila_origen, :fila_sharepoint, :correo,
              :plan_original, :plan_normalizado, :valor_base, :tipo_distribucion,
              :porcentaje, :valor_distribuido, :cu1, :proceso_cu1, :regional, :ciudad,
              :cu3, :cliente, :linea_negocio, :proyecto, :grupo, :empresa,
              :proceso_general, :tipo_proyecto, :almacen, :estado, :observaciones)'
        );
    }

    private function insertDistribution(PDOStatement $statement, array $row): void
    {
        $parameters = [];
        foreach ($row as $key => $value) {
            $parameters[':' . $key] = $value === '' ? null : $value;
        }
        $statement->execute($parameters);
    }

    private function firstText(array $values): string
    {
        foreach ($values as $value) {
            $text = $this->text($value);
            if ($text !== '') {
                return $text;
            }
        }
        return '';
    }

    private function text($value): string
    {
        $text = trim((string)$value);
        $normalized = ad_normalize_text($text);
        if (in_array($normalized, ['', 'NA', 'N/A', '#N/A', '(EN BLANCO)', 'NULL'], true)) {
            return '';
        }
        return $text;
    }

    private function code($value): string
    {
        $text = $this->text($value);
        if ($text === '' || $text === '0') {
            return '';
        }
        return preg_replace('/\s+/u', '', mb_strtoupper($text, 'UTF-8')) ?: '';
    }

    private function money($value): float
    {
        if (is_int($value) || is_float($value)) {
            return round((float)$value, 2);
        }
        $text = preg_replace('/[^0-9,\.\-]/', '', (string)$value) ?: '0';
        $comma = strrpos($text, ',');
        $dot = strrpos($text, '.');
        if ($comma !== false && $dot !== false) {
            if ($comma > $dot) {
                $text = str_replace('.', '', $text);
                $text = str_replace(',', '.', $text);
            } else {
                $text = str_replace(',', '', $text);
            }
        } elseif ($comma !== false) {
            $text = str_replace(',', '.', $text);
        }
        return round((float)$text, 2);
    }

    private function normalizePlan(string $plan): string
    {
        $normalized = ad_normalize_text($plan);
        $map = [
            'BASICO' => 'MICROSOFT 365 BUSINESS BASIC',
            'MICROSOFT 365 EMPRESA BASICO' => 'MICROSOFT 365 BUSINESS BASIC',
            'ESTANDAR' => 'MICROSOFT 365 BUSINESS STANDARD',
            'MICROSOFT 365 EMPRESA ESTANDAR' => 'MICROSOFT 365 BUSINESS STANDARD',
            'EO PLAN1' => 'EXCHANGE ONLINE (PLAN 1)',
            'EXCHANGE ONLINE PLAN 1' => 'EXCHANGE ONLINE (PLAN 1)',
            'BI PREMIUM' => 'POWER BI PREMIUM PER USER',
            'POWER BI PREMIUM POR USUARIO' => 'POWER BI PREMIUM PER USER',
            'BI PRO' => 'POWER BI PRO',
        ];
        return $map[$normalized] ?? ($plan !== '' ? mb_strtoupper($plan, 'UTF-8') : 'SIN PLAN');
    }
}
