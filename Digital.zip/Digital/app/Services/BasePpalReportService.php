<?php
declare(strict_types=1);

final class BasePpalReportService
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function visibleClients(): array
    {
        $allowed = ad_dashboard_client_ids();
        $where = ['b.activo=1', 'f.cliente_normalizado IS NOT NULL'];
        $parameters = [];
        if ($allowed !== null) {
            if (!$allowed) {
                return [];
            }
            $marks = [];
            foreach ($allowed as $index => $id) {
                $key = ':client_' . $index;
                $marks[] = $key;
                $parameters[$key] = (int)$id;
            }
            $where[] = 'f.cliente_id IN (' . implode(',', $marks) . ')';
        }
        $statement = $this->pdo->prepare(
            'SELECT MIN(f.cliente_id) id,
                    f.cliente_normalizado codigo,
                    MAX(f.cliente) nombre
             FROM ad_base_ppal_filas f
             INNER JOIN ad_base_ppal_lotes b ON b.id=f.lote_id
             WHERE ' . implode(' AND ', $where) . '
             GROUP BY f.cliente_normalizado
             ORDER BY nombre'
        );
        $statement->execute($parameters);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findVisibleClient(int $id): ?array
    {
        foreach ($this->visibleClients() as $client) {
            if ((int)$client['id'] === $id) {
                return $client;
            }
        }
        return null;
    }

    public function activeBatch(): ?array
    {
        $statement = $this->pdo->query(
            'SELECT id,finalizado_at,archivo FROM ad_base_ppal_lotes
             WHERE activo=1 AND estado="EXITOSA" ORDER BY id DESC LIMIT 1'
        );
        $batch = $statement->fetch(PDO::FETCH_ASSOC);
        return $batch ?: null;
    }

    public function licenseReport(array $client): array
    {
        $rows = $this->rowsForClient($client);
        $groups = [];
        $accounts = [];
        $accountPlans = [];
        $multiple = [];
        $totalCost = 0.0;
        foreach ($rows as $row) {
            $plan = (string)$row['plan_canonico'];
            if (!isset($groups[$plan])) {
                $groups[$plan] = [
                    'licencia' => $plan,
                    'fabricante' => ClientDashboardService::normalizeLicenseManufacturer('', $plan),
                    'licencias' => 0,
                    'cuentas' => [],
                    'usuarios' => [],
                    'costo_total' => 0.0,
                    'valor_minimo' => null,
                    'valor_maximo' => null,
                ];
            }
            $email = (string)$row['correo_normalizado'];
            $value = (float)$row['precio_usd'];
            $groups[$plan]['licencias']++;
            $groups[$plan]['cuentas'][$email] = true;
            $groups[$plan]['usuarios'][] = $this->reportRow($row);
            $groups[$plan]['costo_total'] += $value;
            $groups[$plan]['valor_minimo'] = $groups[$plan]['valor_minimo'] === null ? $value : min($groups[$plan]['valor_minimo'], $value);
            $groups[$plan]['valor_maximo'] = $groups[$plan]['valor_maximo'] === null ? $value : max($groups[$plan]['valor_maximo'], $value);
            $accounts[$email] = true;
            $accountPlans[$email][$plan] = true;
            $totalCost += $value;
        }
        foreach ($groups as &$group) {
            $group['cuentas_licenciadas'] = count($group['cuentas']);
            unset($group['cuentas']);
            $group['costo_total'] = round($group['costo_total'], 2);
        }
        unset($group);
        foreach ($accountPlans as $email => $plans) {
            if (count($plans) < 2) {
                continue;
            }
            $first = null;
            foreach ($rows as $row) {
                if ((string)$row['correo_normalizado'] === $email) {
                    $first = $row;
                    break;
                }
            }
            $licenseLabels = array_keys($plans);
            $multiple[] = [
                'correo' => $email,
                'nombre' => (string)($first['nombre'] ?? ''),
                'cliente' => (string)($first['cliente'] ?? ''),
                'cantidad_licencias' => count($plans),
                'licencias_detalle' => implode(' · ', $licenseLabels),
                'costo_total' => round(array_sum(array_map(static function (string $plan) use ($rows, $email): float {
                    $sum = 0.0;
                    foreach ($rows as $row) {
                        if ((string)$row['correo_normalizado'] === $email && (string)$row['plan_canonico'] === $plan) {
                            $sum += (float)$row['precio_usd'];
                        }
                    }
                    return $sum;
                }, $licenseLabels)), 2),
            ];
        }
        usort($multiple, static function (array $left, array $right): int {
            return strcmp($left['correo'], $right['correo']);
        });
        $batch = $this->activeBatch();
        return [
            'cuentas_licenciadas' => count($accounts),
            'licencias_asignadas' => count($rows),
            'costo_mensual' => round($totalCost, 2),
            'grupos' => array_values($groups),
            'cuentas_multiples' => $multiple,
            'pendientes_reasignacion' => [],
            'fecha_corte' => $batch['finalizado_at'] ?? null,
            'lote_id' => $batch['id'] ?? null,
        ];
    }

    public function licenseOptions(array $client): array
    {
        $rows = $this->rowsForClient($client);
        $options = [];
        foreach ($rows as $row) {
            $plan = (string)$row['plan_canonico'];
            $options[$plan] = ['id' => 0, 'nombre' => $plan];
        }
        return array_values($options);
    }

    public function licenseDetail(array $client, int $planId = 0, string $search = '', int $page = 1, int $perPage = 50): array
    {
        $rows = array_map([$this, 'reportRow'], $this->rowsForClient($client));
        $search = mb_strtolower(trim($search), 'UTF-8');
        if ($search !== '') {
            $rows = array_values(array_filter($rows, static function (array $row) use ($search): bool {
                foreach (['correo', 'funcionario', 'numero_documento', 'cargo', 'licencia', 'cu3', 'cliente', 'linea_negocio', 'proyecto', 'ciudad', 'empresa', 'proceso'] as $field) {
                    if (strpos(mb_strtolower((string)($row[$field] ?? ''), 'UTF-8'), $search) !== false) {
                        return true;
                    }
                }
                return false;
            }));
        }
        $perPage = max(10, min(100, $perPage));
        $total = count($rows);
        $pages = max(1, (int)ceil($total / $perPage));
        $page = max(1, min($page, $pages));
        return [
            'rows' => array_slice($rows, ($page - 1) * $perPage, $perPage),
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'perPage' => $perPage,
        ];
    }

    private function rowsForClient(array $client): array
    {
        $batch = $this->activeBatch();
        if (!$batch) {
            return [];
        }
        $aliases = isset($client['aliases']) && is_array($client['aliases'])
            ? $client['aliases']
            : [(string)($client['nombre'] ?? '')];
        $aliases = array_values(array_filter(array_map(static function (string $value): string {
            return ad_normalize_text($value);
        }, $aliases)));
        if (!$aliases) {
            return [];
        }
        $marks = [];
        $parameters = [':batch' => (int)$batch['id']];
        foreach ($aliases as $index => $alias) {
            $key = ':alias_' . $index;
            $marks[] = $key;
            $parameters[$key] = $alias;
        }
        $statement = $this->pdo->prepare(
            'SELECT correo,correo_normalizado,documento,nombre,plan_original,plan_canonico,precio_usd,
                    cliente,cliente_normalizado,cargo,ciudad_labor,cu1,cu1_proceso,cu1_regional,cu1_ciudad,
                    cu3,linea_negocio,proyecto,grupo,empresa,proceso_gen,porcentaje_proyecto,fecha_creacion,observacion
             FROM ad_base_ppal_filas
             WHERE lote_id=:batch AND estado_validacion IN ("VALIDA","CONFLICTO")
               AND cliente_normalizado IN (' . implode(',', $marks) . ')
             ORDER BY plan_canonico,correo_normalizado,fila_origen'
        );
        $statement->execute($parameters);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    private function reportRow(array $row): array
    {
        return [
            'correo' => $row['correo'],
            'nombre' => $row['nombre'],
            'funcionario' => $row['nombre'] ?: 'Sin funcionario asignado',
            'numero_documento' => $row['documento'],
            'cargo' => $row['cargo'],
            'licencia' => $row['plan_canonico'],
            'fabricante' => ClientDashboardService::normalizeLicenseManufacturer('', (string)$row['plan_canonico']),
            'valor_usd' => (float)$row['precio_usd'],
            'cu3' => $row['cu3'],
            'cliente' => $row['cliente'],
            'linea_negocio' => $row['linea_negocio'],
            'proyecto' => $row['proyecto'],
            'ciudad' => $row['ciudad_labor'],
            'pais' => '',
            'empresa' => $row['empresa'],
            'proceso' => $row['cu1_proceso'] ?: $row['proceso_gen'],
        ];
    }
}
