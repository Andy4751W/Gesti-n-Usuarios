<?php
declare(strict_types=1);

/**
 * Escritor XLSX sencillo para exportaciones tabulares sin dependencias externas.
 */
final class SimpleXlsxWriter
{
    /**
     * @param array<int,string> $headers
     * @param array<int,array<int,mixed>> $rows
     * @param array<int,int> $moneyColumns Índices de columna basados en cero.
     * @param array<int,int> $percentColumns Índices de columna basados en cero.
     */
    public static function write(
        string $filePath,
        string $sheetName,
        array $headers,
        array $rows,
        array $moneyColumns = [],
        array $percentColumns = []
    ): void {
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('La exportación XLSX requiere la extensión ZIP de PHP.');
        }

        $directory = dirname($filePath);
        if (!is_dir($directory) && !mkdir($directory, 0770, true) && !is_dir($directory)) {
            throw new RuntimeException('No fue posible crear el directorio de exportación.');
        }

        $zip = new ZipArchive();
        if ($zip->open($filePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('No fue posible crear el archivo XLSX.');
        }

        $sheetName = mb_substr(preg_replace('/[\\\/\?\*\[\]:]/u', ' ', $sheetName) ?: 'Distribucion', 0, 31);
        $sheetXml = self::sheetXml($headers, $rows, $moneyColumns, $percentColumns);

        $zip->addFromString('[Content_Types].xml', self::contentTypesXml());
        $zip->addFromString('_rels/.rels', self::rootRelationshipsXml());
        $zip->addFromString('xl/workbook.xml', self::workbookXml($sheetName));
        $zip->addFromString('xl/_rels/workbook.xml.rels', self::workbookRelationshipsXml());
        $zip->addFromString('xl/styles.xml', self::stylesXml());
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
        $zip->close();
    }

    private static function sheetXml(
        array $headers,
        array $rows,
        array $moneyColumns,
        array $percentColumns
    ): string {
        $columnCount = max(1, count($headers));
        $lastColumn = self::columnLetter($columnCount);
        $lastRow = count($rows) + 1;
        $widths = [];

        foreach ($headers as $index => $header) {
            $widths[$index] = min(42, max(11, mb_strlen((string)$header) + 2));
        }
        foreach (array_slice($rows, 0, 250) as $row) {
            foreach ($row as $index => $value) {
                if (!isset($widths[$index])) {
                    continue;
                }
                $length = mb_strlen((string)$value) + 2;
                $widths[$index] = min(42, max($widths[$index], $length));
            }
        }

        $columnsXml = '';
        foreach ($widths as $index => $width) {
            $number = $index + 1;
            $columnsXml .= '<col min="' . $number . '" max="' . $number
                . '" width="' . number_format((float)$width, 2, '.', '') . '" customWidth="1"/>';
        }

        $rowsXml = '<row r="1" ht="24" customHeight="1">';
        foreach ($headers as $index => $header) {
            $reference = self::columnLetter($index + 1) . '1';
            $rowsXml .= self::textCell($reference, (string)$header, 1);
        }
        $rowsXml .= '</row>';

        foreach ($rows as $rowIndex => $row) {
            $excelRow = $rowIndex + 2;
            $rowsXml .= '<row r="' . $excelRow . '">';
            for ($columnIndex = 0; $columnIndex < $columnCount; $columnIndex++) {
                $value = $row[$columnIndex] ?? null;
                if ($value === null || $value === '') {
                    continue;
                }
                $reference = self::columnLetter($columnIndex + 1) . $excelRow;
                if (is_int($value) || is_float($value)) {
                    $style = in_array($columnIndex, $percentColumns, true)
                        ? 3
                        : (in_array($columnIndex, $moneyColumns, true) ? 2 : 0);
                    $rowsXml .= '<c r="' . $reference . '" s="' . $style . '"><v>'
                        . self::number($value) . '</v></c>';
                } else {
                    $rowsXml .= self::textCell($reference, (string)$value, 0);
                }
            }
            $rowsXml .= '</row>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<dimension ref="A1:' . $lastColumn . $lastRow . '"/>'
            . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            . '<sheetFormatPr defaultRowHeight="18"/>'
            . '<cols>' . $columnsXml . '</cols>'
            . '<sheetData>' . $rowsXml . '</sheetData>'
            . '<autoFilter ref="A1:' . $lastColumn . $lastRow . '"/>'
            . '</worksheet>';
    }

    private static function textCell(string $reference, string $value, int $style): string
    {
        return '<c r="' . $reference . '" s="' . $style . '" t="inlineStr"><is><t xml:space="preserve">'
            . self::xml($value) . '</t></is></c>';
    }

    private static function number($value): string
    {
        return rtrim(rtrim(number_format((float)$value, 8, '.', ''), '0'), '.');
    }

    private static function columnLetter(int $number): string
    {
        $result = '';
        while ($number > 0) {
            $number--;
            $result = chr(65 + ($number % 26)) . $result;
            $number = intdiv($number, 26);
        }
        return $result;
    }

    private static function xml(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    private static function contentTypesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';
    }

    private static function rootRelationshipsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private static function workbookXml(string $sheetName): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . self::xml($sheetName) . '" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
    }

    private static function workbookRelationshipsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
    }

    private static function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="0.00%"/></numFmts>'
            . '<fonts count="2"><font><sz val="10"/><name val="Arial"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Arial"/></font></fonts>'
            . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="4">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            . '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }
}
