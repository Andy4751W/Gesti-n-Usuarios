<?php
declare(strict_types=1);

final class ControlUsuariosImporter
{
    private ?PDO $pdo;
    private int $importId;
    private array $basePpalAccounts = [];
    private array $basePpalPlans = [];
    private array $stats = [
        'filas_leidas' => 0,
        'filas_insertadas' => 0,
        'filas_actualizadas' => 0,
        'filas_omitidas' => 0,
        'errores' => 0,
        'cuentas' => 0,
        'personas' => 0,
        'asignaciones_cuenta' => 0,
        'asignaciones_licencia' => 0,
        'respaldos' => 0,
        'novedades' => 0,
        'funcionarios' => 0,
        'reconciliaciones' => 0,
    ];
    private ?int $basePpalBatchId = null;

    public function __construct(?PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function import(string $filePath, bool $force = false): array
    {
        $reader = new SimpleXlsxReader($filePath);
        $basePpalColumns = $this->basePpalColumns($reader);
        $hash = hash_file('sha256', $filePath);
        if ($hash === false) {
            throw new RuntimeException('No fue posible calcular el hash del archivo.');
        }
        $existing = $this->findExistingImport($hash);
        if ($existing && !$force) {
            throw new RuntimeException(
                'Este archivo ya fue importado. Use --force únicamente si desea reprocesarlo.'
            );
        }

        $this->basePpalBatchId = $this->startBasePpalBatch($filePath, $hash, $force);
        try {
            $this->pdo->beginTransaction();
            $summary = $this->buildBasePpalSnapshot($reader, $basePpalColumns);
            $this->validateBasePpalControls($summary);
            $this->activateBasePpalBatch($summary);
            $this->pdo->commit();
            return $summary + ['lote_id' => $this->basePpalBatchId];
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            $this->finishBasePpalBatch('FALLIDA', $e->getMessage());
            throw $e;
        }
    }

    public function dryRun(string $filePath): array
    {
        $reader = new SimpleXlsxReader($filePath);
        $columns = $this->basePpalColumns($reader);
        $summary = $this->scanBasePpal($reader, $columns);
        $this->validateBasePpalControls($summary);
        unset($summary['_rows']);
        return $summary + ['modo' => 'DRY_RUN'];
    }

    private function buildBasePpalSnapshot(SimpleXlsxReader $reader, array $columns): array
    {
        $summary = $this->scanBasePpal($reader, $columns);
        $insert = $this->pdo->prepare(
            'INSERT INTO ad_base_ppal_filas
             (lote_id,fila_origen,correo,correo_normalizado,documento,nombre,plan_original,plan_canonico,
              precio_usd,cliente,cliente_normalizado,cliente_id,cargo,ciudad_labor,cu1,cu1_proceso,cu1_regional,
              cu1_ciudad,cu3,linea_negocio,proyecto,grupo,empresa,proceso_gen,porcentaje_proyecto,fecha_creacion,
              observacion,datos_originales,estado_validacion,motivo_conflicto)
             VALUES
             (:lote,:fila,:correo,:correo_normalizado,:documento,:nombre,:plan_original,:plan_canonico,
              :precio,:cliente,:cliente_normalizado,:cliente_id,:cargo,:ciudad,:cu1,:cu1_proceso,:cu1_regional,
              :cu1_ciudad,:cu3,:linea,:proyecto,:grupo,:empresa,:proceso_gen,:porcentaje,:fecha,:observacion,
              :datos,:estado,:motivo)'
        );
        foreach ($summary['_rows'] as $item) {
            $clientId = $this->resolveSnapshotClientId($item['cliente']);
            $insert->execute([
                ':lote' => $this->basePpalBatchId,
                ':fila' => $item['fila_origen'],
                ':correo' => $item['correo'],
                ':correo_normalizado' => $item['correo_normalizado'],
                ':documento' => $item['documento'],
                ':nombre' => $item['nombre'],
                ':plan_original' => $item['plan_original'],
                ':plan_canonico' => $item['plan_canonico'],
                ':precio' => $item['precio_usd'],
                ':cliente' => $item['cliente'],
                ':cliente_normalizado' => $item['cliente_normalizado'],
                ':cliente_id' => $clientId,
                ':cargo' => $item['cargo'],
                ':ciudad' => $item['ciudad_labor'],
                ':cu1' => $item['cu1'],
                ':cu1_proceso' => $item['cu1_proceso'],
                ':cu1_regional' => $item['cu1_regional'],
                ':cu1_ciudad' => $item['cu1_ciudad'],
                ':cu3' => $item['cu3'],
                ':linea' => $item['linea_negocio'],
                ':proyecto' => $item['proyecto'],
                ':grupo' => $item['grupo'],
                ':empresa' => $item['empresa'],
                ':proceso_gen' => $item['proceso_gen'],
                ':porcentaje' => $item['porcentaje_proyecto'],
                ':fecha' => $item['fecha_creacion'],
                ':observacion' => $item['observacion'],
                ':datos' => json_encode($item['original'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ':estado' => $item['estado_validacion'],
                ':motivo' => $item['motivo_conflicto'],
            ]);
        }
        unset($summary['_rows']);
        return $summary;
    }

    private function scanBasePpal(SimpleXlsxReader $reader, array $columns): array
    {
        $items = [];
        $rowsRead = 0;
        $discarded = [];
        foreach ($reader->rows('BASE_PPAL') as $rawRow) {
            $rowsRead++;
            $row = $this->basePpalRow($rawRow, $columns);
            $email = ad_email_normalize((string)($row['NOMBRE_USUARIO'] ?? ''));
            $planOriginal = $this->cleanSnapshotValue($row['PLAN'] ?? null);
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $planOriginal === null) {
                $discarded[] = [
                    'fila' => (int)($row['_row'] ?? 0),
                    'motivo' => $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)
                        ? 'Correo vacío o inválido.' : 'Licencia vacía.',
                ];
                continue;
            }
            $item = $this->normalizeBasePpalItem($row, $email, $planOriginal);
            $items[] = $item;
        }

        $documentsByEmail = [];
        foreach ($items as $index => $item) {
            $documentsByEmail[$item['correo_normalizado']][$item['documento'] ?: '(sin documento)'][] = $index;
        }
        $conflictRows = [];
        $conflictEmails = [];
        foreach ($documentsByEmail as $documents) {
            if (count($documents) <= 1) {
                continue;
            }
            $conflictEmails[] = array_key_first($documents);
            foreach ($documents as $indexes) {
                foreach ($indexes as $index) {
                    $items[$index]['estado_validacion'] = 'CONFLICTO';
                    $items[$index]['motivo_conflicto'] = 'Correo asociado a documentos diferentes.';
                    $conflictRows[] = $items[$index]['fila_origen'];
                }
            }
        }
        $plansByClient = [];
        $accountsByClient = [];
        $costByClient = [];
        $distribution = [];
        $accounts = [];
        foreach ($items as $item) {
            $client = $item['cliente_normalizado'] ?: '(sin cliente)';
            $plansByClient[$client] = ($plansByClient[$client] ?? 0) + 1;
            $accountsByClient[$client][$item['correo_normalizado']] = true;
            $costByClient[$client] = ($costByClient[$client] ?? 0) + $item['precio_usd'];
            $distribution[$client][$item['plan_canonico']] = ($distribution[$client][$item['plan_canonico']] ?? 0) + 1;
            $accounts[$item['correo_normalizado']] = true;
        }
        foreach ($costByClient as $client => $cost) {
            $costByClient[$client] = round($cost, 2);
        }
        $summary = [
            'filas_no_vacias' => $rowsRead,
            'filas_validas' => count($items),
            'filas_descartadas' => count($discarded),
            'descartes' => $discarded,
            'cuentas_distintas' => count($accounts),
            'conflictos' => count($conflictEmails),
            'filas_conflicto' => array_values(array_unique($conflictRows)),
            'costo_mensual' => round(array_sum(array_column($items, 'precio_usd')), 2),
            'por_cliente' => [],
            '_rows' => $items,
        ];
        foreach ($plansByClient as $client => $count) {
            $summary['por_cliente'][$client] = [
                'filas_licencias' => $count,
                'cuentas_distintas' => count($accountsByClient[$client]),
                'costo_mensual' => $costByClient[$client],
                'licencias' => $distribution[$client],
            ];
        }
        return $summary;
    }

    private function normalizeBasePpalItem(array $row, string $email, string $planOriginal): array
    {
        $client = $this->cleanSnapshotValue($row['CU3_CLIENTE'] ?? null);
        return [
            'fila_origen' => (int)($row['_row'] ?? 0),
            'correo' => $email,
            'correo_normalizado' => $email,
            'documento' => $this->normalizeDocument($row['NUM_DOCUMENTO'] ?? null),
            'nombre' => $this->cleanSnapshotValue($row['APELLIDO_NOMBRE'] ?? null),
            'plan_original' => $planOriginal,
            'plan_canonico' => $this->canonicalSnapshotPlan($planOriginal),
            'precio_usd' => $this->parseSnapshotPrice($row['PRECIO_USD'] ?? null),
            'cliente' => $client,
            'cliente_normalizado' => $client === null ? null : ad_normalize_text($client),
            'cargo' => $this->cleanSnapshotValue($row['CARGO'] ?? null),
            'ciudad_labor' => $this->cleanSnapshotValue($row['CIUDAD_LABOR'] ?? null),
            'cu1' => $this->cleanSnapshotValue($row['CU1'] ?? null),
            'cu1_proceso' => $this->cleanSnapshotValue($row['CU1_PROCESO'] ?? null),
            'cu1_regional' => $this->cleanSnapshotValue($row['CU1_REGIONAL'] ?? null),
            'cu1_ciudad' => $this->cleanSnapshotValue($row['CU1_CIUDAD'] ?? null),
            'cu3' => $this->cleanSnapshotValue($row['CU3'] ?? null),
            'linea_negocio' => $this->cleanSnapshotValue($row['CU3_LINEA_NEGOCIO'] ?? null),
            'proyecto' => $this->cleanSnapshotValue($row['CU3_PROYECTO'] ?? null),
            'grupo' => $this->cleanSnapshotValue($row['GRUPO'] ?? null),
            'empresa' => $this->cleanSnapshotValue($row['EMPRESA'] ?? null),
            'proceso_gen' => $this->cleanSnapshotValue($row['PROCESO_GEN'] ?? null),
            'porcentaje_proyecto' => $this->cleanSnapshotValue($row['PORCENTAJE_PROYECTO'] ?? null),
            'fecha_creacion' => ad_excel_serial_to_date($row['FECHA_CREACION'] ?? null),
            'observacion' => $this->cleanSnapshotValue($row['OBSERVACION'] ?? null),
            'estado_validacion' => 'VALIDA',
            'motivo_conflicto' => null,
            'original' => $row,
        ];
    }

    private function validateBasePpalControls(array $summary): void
    {
        $expected = [
            'CLARO R3' => ['filas_licencias' => 1065, 'cuentas_distintas' => 1059, 'costo_mensual' => 1068.87],
            'CLARO R4' => ['filas_licencias' => 142, 'cuentas_distintas' => 142, 'costo_mensual' => 120.89],
        ];
        foreach ($expected as $client => $control) {
            $actual = $summary['por_cliente'][$client] ?? null;
            if ($actual === null || $actual['filas_licencias'] !== $control['filas_licencias'] || $actual['cuentas_distintas'] !== $control['cuentas_distintas'] || abs($actual['costo_mensual'] - $control['costo_mensual']) > 0.005) {
                throw new RuntimeException('Control BASE_PPAL no coincide para ' . $client . '.');
            }
        }
        if ($summary['filas_no_vacias'] !== 1533 || $summary['filas_validas'] !== 1531 || $summary['cuentas_distintas'] !== 1520 || abs($summary['costo_mensual'] - 3358.66) > 0.005 || $summary['filas_descartadas'] !== 2 || $summary['conflictos'] !== 7) {
            throw new RuntimeException('Los controles de conciliación de BASE_PPAL no coinciden.');
        }
    }

    public function repairImportedLicenses(string $filePath, bool $apply = false): array
    {
        $reader = new SimpleXlsxReader($filePath);
        $columns = $this->basePpalColumns($reader);
        $official = [];
        foreach ($reader->rows('BASE_PPAL') as $row) {
            $row = $this->basePpalRow($row, $columns);
            $email = ad_email_normalize((string)$row['NOMBRE_USUARIO']);
            $plan = $this->findPlanId((string)$row['PLAN']);
            if ($email !== '' && $plan !== null) {
                $official[$email][$plan] = true;
            }
        }
        $accounts = $this->pdo->query('SELECT id,correo_normalizado FROM ad_cuentas')->fetchAll(PDO::FETCH_KEY_PAIR);
        $accountPlans = [];
        foreach ($accounts as $id => $email) {
            if (isset($official[ad_email_normalize((string)$email)])) {
                $accountPlans[(int)$id] = $official[ad_email_normalize((string)$email)];
            }
        }
        $rows = $this->pdo->query(
            'SELECT al.id,al.cuenta_id,s.plan_id FROM ad_asignaciones_licencia al
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             WHERE al.estado="ACTIVA" AND al.motivo="MIGRACION_EXCEL" ORDER BY al.cuenta_id,s.plan_id,al.id'
        )->fetchAll(PDO::FETCH_ASSOC);
        $seen = [];
        $closeIds = [];
        foreach ($rows as $row) {
            $accountId = (int)$row['cuenta_id'];
            $planId = (int)$row['plan_id'];
            $key = $accountId . ':' . $planId;
            if (!isset($accountPlans[$accountId][$planId]) || isset($seen[$key])) {
                $closeIds[] = (int)$row['id'];
                continue;
            }
            $seen[$key] = true;
        }
        $deactivateIds = [];
        foreach ($this->pdo->query('SELECT id,correo_normalizado FROM ad_cuentas WHERE legacy_sheet="BASE_PPAL" AND estado="ACTIVA"')->fetchAll(PDO::FETCH_ASSOC) as $account) {
            if (!isset($official[ad_email_normalize((string)$account['correo_normalizado'])])) {
                $deactivateIds[] = (int)$account['id'];
            }
        }
        $summary = ['modo' => $apply ? 'APLICAR' : 'DIAGNOSTICO', 'duplicados_y_obsoletos' => count($closeIds), 'asignaciones_cerradas' => 0, 'cuentas_desactivadas' => 0];
        if (!$apply) {
            return $summary;
        }
        $this->pdo->beginTransaction();
        try {
            $close = $this->pdo->prepare('UPDATE ad_asignaciones_licencia SET estado="CERRADA",fecha_fin=CURDATE(),motivo="DEPURACION_DUPLICADO_IMPORTACION" WHERE id=:id AND estado="ACTIVA" AND motivo="MIGRACION_EXCEL"');
            foreach ($closeIds as $id) {
                $close->execute([':id' => $id]);
                $summary['asignaciones_cerradas'] += $close->rowCount();
            }
            $deactivate = $this->pdo->prepare('UPDATE ad_cuentas SET estado="GESTION_DE_BAJA" WHERE id=:id AND legacy_sheet="BASE_PPAL" AND estado="ACTIVA"');
            foreach ($deactivateIds as $id) {
                $deactivate->execute([':id' => $id]);
                $summary['cuentas_desactivadas'] += $deactivate->rowCount();
            }
            $this->pdo->commit();
        } catch (Throwable $exception) {
            $this->pdo->rollBack();
            throw $exception;
        }
        return $summary;
    }

    private function normalizeDocument(
    $value
): ?string {
    if ($value === null) {
        return null;
    }

    $value = trim((string)$value);

    if ($value === '') {
        return null;
    }

    /*
     * Quitar sufijos decimales del Excel:
     * 1000862587.0 -> 1000862587
     */
    $value = preg_replace('/\.0+$/', '', $value) ?? $value;

    /*
     * Conservar solo dígitos.
     */
    $value = preg_replace('/\D+/', '', $value) ?? '';

    return $value !== '' ? $value : null;
}

    private function basePpalColumns(SimpleXlsxReader $reader): array
    {
        if (!in_array('BASE_PPAL', $reader->sheetNames(), true)) {
            throw new RuntimeException('No se encontró la hoja obligatoria BASE_PPAL en Control_Usuarios.xlsx.');
        }

        $headers = [];
        foreach ($reader->rawRows('BASE_PPAL') as $row) {
            unset($row['_row']);
            foreach ($row as $column => $value) {
                $header = trim((string)$value);
                if ($header !== '') {
                    $headers[$this->normalizeHeader($header)] = $header;
                }
            }
            break;
        }

        if ($headers === []) {
            throw new RuntimeException('La hoja BASE_PPAL no contiene encabezados en la fila 1.');
        }

        $definitions = [
            'RAZON_SOCIAL' => ['RAZON_SOCIAL'],
            'NOMBRE_USUARIO' => ['NOMBRE_USUARIO'],
            'PLAN' => ['PLAN'],
            'PRECIO_USD' => ['PRECIO USD'],
            'CIUDAD_LABOR' => ['CIUDAD LABOR'],
            'DOMINIO' => ['DOMINIO'],
            'NUM_DOCUMENTO' => ['NUM_DOCUMENTO'],
            'APELLIDO_NOMBRE' => ['APELLIDO NOMBRE'],
            'CARGO' => ['CARGO'],
            'CU1' => ['CU1'],
            'CU1_PROCESO' => ['CU1-PROCESO'],
            'CU1_REGIONAL' => ['CU1-REGIONAL'],
            'CU1_CIUDAD' => ['CU1-CIUDAD'],
            'CU3' => ['CU3'],
            'CU3_CLIENTE' => ['CU3-CLIENTE'],
            'CU3_LINEA_NEGOCIO' => ['CU3-LINEA DE NEGOCIO'],
            'CU3_PROYECTO' => ['CU3-PROYECTO'],
            'GRUPO' => ['GRUPO'],
            'EMPRESA' => ['RAZON_SOCIAL', 'EMPRESA'],
            'PROCESO_GEN' => ['PROCESO GEN'],
            'PORCENTAJE_PROYECTO' => ['% PROYECTO'],
            'FECHA_CREACION' => ['FECHA_CREACION'],
            'OBSERVACION' => ['OBSERVACIÓN (Solicitante)'],
        ];
        $columns = [];
        $missing = [];
        foreach ($definitions as $field => $aliases) {
            foreach ($aliases as $alias) {
                $normalized = $this->normalizeHeader($alias);
                if (isset($headers[$normalized])) {
                    $columns[$field] = $headers[$normalized];
                    break;
                }
            }
            if (!isset($columns[$field])) {
                $missing[] = implode(' o ', $aliases);
            }
        }

        if ($missing !== []) {
            throw new RuntimeException(
                'La hoja BASE_PPAL no contiene los encabezados obligatorios: ' . implode(', ', $missing) . '.'
            );
        }

        return $columns;
    }

    private function startBasePpalBatch(string $filePath, string $hash, bool $force): int
    {
        $statement = $this->pdo->prepare(
            'SELECT id,estado FROM ad_base_ppal_lotes WHERE hash_archivo=:hash LIMIT 1'
        );
        $statement->execute([':hash' => $hash]);
        $existing = $statement->fetch(PDO::FETCH_ASSOC);
        if ($existing && !$force && (string)$existing['estado'] === 'EXITOSA') {
            throw new RuntimeException('Este archivo ya tiene una importación BASE_PPAL exitosa. Use --force para reprocesarlo.');
        }
        $insert = $this->pdo->prepare(
            'INSERT INTO ad_base_ppal_lotes (archivo,hash_archivo,estado,activo)
             VALUES (:archivo,:hash,"PENDIENTE",0)'
        );
        $insert->execute([':archivo' => basename($filePath), ':hash' => $hash]);
        return (int)$this->pdo->lastInsertId();
    }

    private function activateBasePpalBatch(array $summary): void
    {
        $this->pdo->prepare(
            'UPDATE ad_base_ppal_lotes SET activo=0 WHERE activo=1 AND id<>:id'
        )->execute([':id' => $this->basePpalBatchId]);
        $this->pdo->prepare(
            'UPDATE ad_base_ppal_lotes
             SET estado="EXITOSA",activo=1,filas_leidas=:leidas,filas_validas=:validas,
                 filas_descartadas=:descartadas,conflictos=:conflictos,resumen=:resumen,finalizado_at=NOW()
             WHERE id=:id'
        )->execute([
            ':leidas' => $summary['filas_no_vacias'],
            ':validas' => $summary['filas_validas'],
            ':descartadas' => $summary['filas_descartadas'],
            ':conflictos' => $summary['conflictos'],
            ':resumen' => json_encode($summary, JSON_UNESCAPED_UNICODE),
            ':id' => $this->basePpalBatchId,
        ]);
    }

    private function finishBasePpalBatch(string $status, string $message): void
    {
        $this->pdo->prepare(
            'UPDATE ad_base_ppal_lotes SET estado=:estado,error=:error,finalizado_at=NOW() WHERE id=:id AND activo=0'
        )->execute([':estado' => $status, ':error' => $message, ':id' => $this->basePpalBatchId]);
    }

    private function resolveSnapshotClientId(?string $client): ?int
    {
        if ($client === null) {
            return null;
        }
        $normalized = ad_normalize_text($client);
        $statement = $this->pdo->prepare('SELECT id FROM ad_clientes_dashboard WHERE UPPER(TRIM(nombre))=UPPER(TRIM(:nombre)) LIMIT 1');
        $statement->execute([':nombre' => $client]);
        $id = $statement->fetchColumn();
        if ($id !== false) {
            return (int)$id;
        }
        $code = substr(trim((string)preg_replace('/[^A-Z0-9]+/', '_', $normalized), '_'), 0, 80);
        if ($code === '') {
            return null;
        }
        $insert = $this->pdo->prepare('INSERT INTO ad_clientes_dashboard (codigo,nombre,activo) VALUES (:codigo,:nombre,1)');
        try {
            $insert->execute([':codigo' => $code, ':nombre' => $client]);
            return (int)$this->pdo->lastInsertId();
        } catch (Throwable $exception) {
            $statement->execute([':nombre' => $client]);
            $id = $statement->fetchColumn();
            return $id === false ? null : (int)$id;
        }
    }

    private function cleanSnapshotValue($value): ?string
    {
        $value = trim((string)$value);
        if ($value === '' || $this->isNullToken($value)) {
            return null;
        }
        return preg_replace('/\s+/u', ' ', $value) ?: null;
    }

    private function parseSnapshotPrice($value): float
    {
        $text = trim((string)$value);
        if ($text === '') {
            return 0.0;
        }
        $text = preg_replace('/[^0-9,\.\-]/', '', $text) ?? '';
        $lastComma = strrpos($text, ',');
        $lastDot = strrpos($text, '.');
        if ($lastComma !== false && $lastDot !== false) {
            if ($lastComma > $lastDot) {
                $text = str_replace('.', '', $text);
                $text = str_replace(',', '.', $text);
            } else {
                $text = str_replace(',', '', $text);
            }
        } elseif ($lastComma !== false) {
            $text = str_replace(',', '.', $text);
        }
        return is_numeric($text) ? (float)$text : 0.0;
    }

    private function canonicalSnapshotPlan(string $plan): string
    {
        $normalized = ad_normalize_text($plan);
        $aliases = [
            'MICROSOFT 365 EMPRESA BASICO' => 'MICROSOFT 365 BUSINESS BASIC',
            'MICROSOFT 365 EMPRESA ESTANDAR' => 'MICROSOFT 365 BUSINESS STANDARD',
            'EXCHANGE ONLINE PLAN 1' => 'EXCHANGE ONLINE (PLAN 1)',
            'EXCHANGE ONLINE (PLAN 1)' => 'EXCHANGE ONLINE (PLAN 1)',
        ];
        return $aliases[$normalized] ?? $normalized;
    }

    private function normalizeHeader(string $header): string
    {
        return preg_replace('/[^A-Z0-9]+/u', '', ad_normalize_text($header)) ?? '';
    }

    private function basePpalRow(array $row, array $columns): array
    {
        $mapped = ['_row' => $row['_row'] ?? 0];
        foreach ($columns as $field => $header) {
            $mapped[$field] = $row[$header] ?? null;
        }
        return $mapped;
    }

    private function importAccounts(SimpleXlsxReader $reader, string $sheet, string $country, array $columns): void
    {
        foreach ($reader->rows($sheet) as $row) {
            $row = $this->basePpalRow($row, $columns);
            $this->stats['filas_leidas']++;
            try {
                $email = ad_email_normalize((string)($row['NOMBRE_USUARIO'] ?? ''));
                if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $this->skipOrError($sheet, $row, 'NOMBRE_USUARIO', 'Correo vacío o inválido.', true);
                    continue;
                }

                $reasonRaw = trim((string)($row['EMPRESA'] ?? ''));
                $reasonId = $reasonRaw !== '' && !$this->isNullToken($reasonRaw)
                    ? $this->upsertReason($reasonRaw, $country)
                    : null;

                $document = $this->cleanNullable($row['NUM_DOCUMENTO'] ?? null);
                $personId = null;
                if ($document !== null) {
                    $personId = $this->upsertPerson([
                        'pais' => $country,
                        'documento' => $document,
                        'nombre' => $this->cleanNullable($row['APELLIDO_NOMBRE'] ?? null),
                        'cargo' => $this->cleanNullable($row['CARGO'] ?? null),
                        'ciudad' => $this->cleanNullable($row['CIUDAD_LABOR'] ?? null),
                        'proceso' => $this->cleanNullable($row['PROCESO'] ?? null),
                        'cliente' => $this->clientValue($row['CU3_CLIENTE'] ?? null),
                        'proyecto' => $this->cleanNullable($row['CU3_PROYECTO'] ?? null),
                        'razon_social_id' => $reasonId,
                        'fuente' => $sheet,
                        'fuente_id' => (string)($row['_row'] ?? ''),
                    ]);
                }

                $domainName = substr(strrchr($email, '@') ?: '', 1);
                $domainId = $domainName !== '' ? $this->upsertDomain($domainName, $reasonId) : null;
                $accountId = $this->upsertAccount([
                    'correo' => $email,
                    'dominio_id' => $domainId,
                    'tipo' => $personId ? 'PERSONAL' : 'GENERICA',
                    'razon_social_id' => $reasonId,
                    'pais' => $country,
                    'ciudad' => $this->cleanNullable($row['CIUDAD_LABOR'] ?? null),
                    'observaciones' => $this->cleanNullable($row['OBSERVACION'] ?? null),
                    'fecha_creacion' => ad_excel_serial_to_date($row['FECHA_CREACION'] ?? null),
                    'legacy_sheet' => $sheet,
                    'legacy_row' => (int)($row['_row'] ?? 0),
                ]);
                $this->basePpalAccounts[$accountId] = true;

                $this->upsertDistributionProfile($accountId, $row, $reasonRaw);

                if ($personId !== null) {
                    if ($this->ensureAccountAssignment($accountId, $personId, ad_excel_serial_to_date($row['FECHA_CREACION'] ?? null))) {
                        $this->stats['asignaciones_cuenta']++;
                    }
                }

                $planRaw = $this->cleanNullable($row['PLAN'] ?? null);
                if ($planRaw !== null) {
                    $planId = $this->resolvePlan($planRaw);
                    $price = is_numeric($row['PRECIO_USD'] ?? null) ? (float)$row['PRECIO_USD'] : 0.0;
                    $subscriptionId = $this->resolveImportedSubscription(
                        $planId,
                        $price,
                        $country,
                        $reasonId,
                        (string)($row['DOMINIO'] ?? '')
                    );
                    $this->basePpalPlans[$accountId][$planId] = true;
                    if ($this->ensureLicenseAssignment(
                        $accountId,
                        $planId,
                        $subscriptionId,
                        ad_excel_serial_to_date($row['FECHA_CREACION'] ?? null),
                        $price
                    )) {
                        $this->stats['asignaciones_licencia']++;
                    }
                }
                $this->stats['filas_insertadas']++;
            } catch (Throwable $e) {
                $this->recordError($sheet, (int)($row['_row'] ?? 0), null, $e->getMessage(), $row);
            }
        }
    }

    private function importPeopleColombia(
        SimpleXlsxReader $reader
    ): void {
        foreach ($reader->rows('MatrizHDUniclass') as $row) {
            $this->stats['filas_leidas']++;

            try {
                $documento = $this->normalizeDocument(
                    $row['IDENTIFICACION'] ?? null
                );

                if ($documento === null) {
                    $this->stats['filas_omitidas']++;
                    continue;
                }

                $empresa = $this->cleanNullable(
                    $row['EMPRESA'] ?? null
                );

                $razonSocialId = $empresa !== null
                    ? $this->upsertReason($empresa, 'CO')
                    : null;

                $this->upsertPerson([
                    'pais' => 'CO',

                    'documento' => $documento,

                    'nombre' => $this->cleanNullable(
                        $row['APELLIDOS_Y_NOMBRES']
                            ?? $row['APELLIDOS Y NOMBRES']
                            ?? null
                    ),

                    'cargo' => $this->cleanNullable(
                        $row['NOMBRE_PUESTO']
                            ?? $row['CARGO']
                            ?? null
                    ),

                    'ciudad' => $this->cleanNullable(
                        $row['CU1_CIUDAD']
                            ?? $row['CIUDAD']
                            ?? null
                    ),

                    'proceso' => $this->cleanNullable(
                        $row['CU1_PROCESO']
                            ?? $row['PROCESO GEN']
                            ?? null
                    ),

                    'cliente' => $this->cleanNullable(
                        $row['CU3_CLIENTE'] ?? null
                    ),

                    'proyecto' => $this->cleanNullable(
                        $row['CU3_PROYECTO'] ?? null
                    ),

                    'razon_social_id' => $razonSocialId,

                    'estado_laboral' => 'SIN_VALIDAR',

                    'fuente' => 'MatrizHDUniclass',

                    'fuente_id' => $this->cleanNullable(
                        $row['ID_EMP'] ?? null
                    ) ?? (string)($row['_row'] ?? ''),
                ]);

                $this->stats['filas_insertadas']++;
            } catch (Throwable $e) {
                $this->recordError(
                    'MatrizHDUniclass',
                    (int)($row['_row'] ?? 0),
                    null,
                    $e->getMessage(),
                    $row
                );
            }
        }
    }

    private function importPeoplePeru(
        SimpleXlsxReader $reader
    ): void {
        foreach ($reader->rows('PLANTA PERU') as $row) {
            $this->stats['filas_leidas']++;

            try {
                $documento = $this->normalizeDocument(
                    $row['CEDULA']
                        ?? $row['DOCUMENTO']
                        ?? $row['NUM_DOCUMENTO']
                        ?? null
                );

                if ($documento === null) {
                    $this->stats['filas_omitidas']++;
                    continue;
                }

                $empresa = $this->cleanNullable(
                    $row['EMPRESA'] ?? null
                ) ?? 'CONECTAR TELECOMUNICACIONES SAC';

                $razonSocialId = $this->upsertReason(
                    $empresa,
                    'PE'
                );

                $this->upsertPerson([
                    'pais' => 'PE',

                    'documento' => $documento,

                    'nombre' => $this->cleanNullable(
                        $row['APELLIDOS Y NOMBRES']
                            ?? $row['APELLIDOS_Y_NOMBRES']
                            ?? $row['NOMBRE']
                            ?? null
                    ),

                    'cargo' => $this->cleanNullable(
                        $row['CARGO']
                            ?? $row['NOMBRE_PUESTO']
                            ?? null
                    ),

                    'ciudad' => $this->cleanNullable(
                        $row['CIUDAD OPE']
                            ?? $row['CIUDAD']
                            ?? $row['CIUDAD LABOR']
                            ?? null
                    ),

                    'proceso' => $this->cleanNullable(
                        $row['PROCESO']
                            ?? $row['CU1_PROCESO']
                            ?? null
                    ),

                    'cliente' => $this->cleanNullable(
                        $row['CLIENTE']
                            ?? $row['CU3_CLIENTE']
                            ?? null
                    ),

                    'proyecto' => $this->cleanNullable(
                        $row['PROYECTO']
                            ?? $row['CU3_PROYECTO']
                            ?? null
                    ),

                    'razon_social_id' => $razonSocialId,

                    'estado_laboral' => 'SIN_VALIDAR',

                    'fuente' => 'PLANTA PERU',

                    'fuente_id' => (string)(
                        $row['_row'] ?? ''
                    ),
                ]);

                $this->stats['filas_insertadas']++;
            } catch (Throwable $e) {
                $this->recordError(
                    'PLANTA PERU',
                    (int)($row['_row'] ?? 0),
                    null,
                    $e->getMessage(),
                    $row
                );
            }
        }
    }



    private function importBackups(SimpleXlsxReader $reader): void
    {
        foreach ($reader->rows('Backup-Correos') as $row) {
            $this->stats['filas_leidas']++;
            try {
                $stmt = $this->pdo->prepare(
                    'INSERT INTO ad_respaldos
                     (servidor, carpeta, subcarpeta_1, subcarpeta_2, subcarpeta_3, archivo,
                      repositorio_cloud, fecha_carga, tamano_pst, tamano_onedrive, legacy_row)
                     VALUES
                     (:servidor, :carpeta, :sub1, :sub2, :sub3, :archivo,
                      :cloud, :fecha, :pst, :onedrive, :legacy_row)
                     ON DUPLICATE KEY UPDATE
                      servidor=VALUES(servidor), carpeta=VALUES(carpeta), subcarpeta_1=VALUES(subcarpeta_1),
                      subcarpeta_2=VALUES(subcarpeta_2), subcarpeta_3=VALUES(subcarpeta_3),
                      archivo=VALUES(archivo), repositorio_cloud=VALUES(repositorio_cloud),
                      fecha_carga=VALUES(fecha_carga), tamano_pst=VALUES(tamano_pst),
                      tamano_onedrive=VALUES(tamano_onedrive)'
                );
                $stmt->execute([
                    ':servidor' => $this->cleanNullable($row['Servidor'] ?? null),
                    ':carpeta' => $this->cleanNullable($row['Carpeta'] ?? null),
                    ':sub1' => $this->cleanNullable($row['Carpeta 1'] ?? null),
                    ':sub2' => $this->cleanNullable($row['Carpeta 2'] ?? null),
                    ':sub3' => $this->cleanNullable($row['Carpeta 3'] ?? null),
                    ':archivo' => $this->cleanNullable($row['Archivo'] ?? null),
                    ':cloud' => $this->cleanNullable($row['CLOUD'] ?? null),
                    ':fecha' => ad_excel_serial_to_date($row['FECHA CARGA'] ?? null),
                    ':pst' => $this->cleanNullable($row['TamPST '] ?? $row['Tam PST'] ?? null),
                    ':onedrive' => $this->cleanNullable($row['Tam  OneDrive'] ?? null),
                    ':legacy_row' => (int)($row['_row'] ?? 0),
                ]);
                $this->stats['respaldos']++;
                $this->stats['filas_insertadas']++;
            } catch (Throwable $e) {
                $this->recordError('Backup-Correos', (int)($row['_row'] ?? 0), null, $e->getMessage(), $row);
            }
        }
    }

    private function importNews(SimpleXlsxReader $reader): void
{
    foreach ($reader->rows('NOVEDADES') as $row) {
        $this->stats['filas_leidas']++;

        try {
            $email = ad_email_normalize(
                (string)($row['NOMBRE_USUARIO'] ?? '')
            );

            $accountId = null;

            if (
                $email !== ''
                && filter_var($email, FILTER_VALIDATE_EMAIL)
            ) {
                $stmt = $this->pdo->prepare(
                    'SELECT id
                     FROM ad_cuentas
                     WHERE correo_normalizado=:correo
                     LIMIT 1'
                );

                $stmt->execute([
                    ':correo' => $email
                ]);

                $accountId = $stmt->fetchColumn() ?: null;
            }

            $mainObservation = $this->cleanNullable(
                $row['OBSERVACION'] ?? null
            );

            $requestObservation = $this->cleanNullable(
                $row['OBSERVACIÓN (Solicitante)'] ?? null
            );

            $descriptionParts = array_values(array_filter([
                $mainObservation,
                $requestObservation !== null
                    ? 'Solicitante: ' . $requestObservation
                    : null,
            ]));

            $description = $descriptionParts !== []
                ? implode(' | ', $descriptionParts)
                : 'Novedad migrada desde Excel';

            $normalizedObservation = ad_normalize_text(
                $mainObservation ?? ''
            );

            $type = strpos($normalizedObservation, 'CAMBIO DE ASIGNACION') !== false
                ? 'CAMBIO_ASIGNACION'
                : (
                    strpos($normalizedObservation, 'ELIMIN') !== false
                        ? 'ELIMINACION'
                        : (
                            strpos($normalizedObservation, 'BAJA') !== false
                                ? 'BAJA_CORREO'
                                : 'MIGRACION_EXCEL'
                        )
                );

            $noveltyDate = ad_excel_serial_to_date(
                $row['Fecha Modificación'] ?? null
            ) ?? ad_excel_serial_to_date(
                $row['FECHA_CREACION'] ?? null
            );

            $stmt = $this->pdo->prepare(
                'INSERT INTO ad_novedades
                 (
                    cuenta_id,
                    tipo,
                    estado,
                    fecha_novedad,
                    descripcion,
                    datos_origen,
                    legacy_sheet,
                    legacy_row
                 )
                 VALUES
                 (
                    :cuenta,
                    :tipo,
                    "ABIERTA",
                    :fecha,
                    :descripcion,
                    :datos,
                    "NOVEDADES",
                    :fila
                 )
                      ON DUPLICATE KEY UPDATE id=id'
            );

            $stmt->execute([
                ':cuenta' => $accountId,
                ':tipo' => $type,
                ':fecha' => $noveltyDate,
                ':descripcion' => $description,
                ':datos' => json_encode(
                    array_merge($row, ['origen' => 'IMPORTACION']),
                    JSON_UNESCAPED_UNICODE
                ),
                ':fila' => (int)($row['_row'] ?? 0),
            ]);

            $this->stats['novedades']++;
            $this->stats['filas_insertadas']++;
        } catch (Throwable $e) {
            $this->recordError(
                'NOVEDADES',
                (int)($row['_row'] ?? 0),
                null,
                $e->getMessage(),
                $row
            );
        }
    }
}

    private function upsertReason(string $rawName, string $country): int
    {
        $name = trim($rawName);
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_razones_sociales (codigo, nombre, pais)
             VALUES (:codigo, :nombre, :pais)
             ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id), codigo=COALESCE(codigo, VALUES(codigo))'
        );
        $code = mb_strlen($name) <= 30 ? mb_strtoupper($name, 'UTF-8') : null;
        $stmt->execute([':codigo' => $code, ':nombre' => $name, ':pais' => $country]);
        return (int)$this->pdo->lastInsertId();
    }

    private function upsertPerson(array $data): int
{
    $stmt = $this->pdo->prepare(
        'INSERT INTO ad_personas
         (
            pais,
            numero_documento,
            nombre_completo,
            cargo,
            ciudad,
            proceso,
            cliente,
            proyecto,
            razon_social_id,
            estado_laboral,
            fuente,
            fuente_id
         )
         VALUES
         (
            :pais,
            :documento,
            :nombre,
            :cargo,
            :ciudad,
            :proceso,
            :cliente,
            :proyecto,
            :razon,
            :estado_laboral,
            :fuente,
            :fuente_id
         )
         ON DUPLICATE KEY UPDATE
            id=LAST_INSERT_ID(id),
            nombre_completo=CASE
    WHEN VALUES(fuente) IN (
        "MatrizHDUniclass",
        "PLANTA PERU"
    )
    AND NULLIF(
        TRIM(VALUES(nombre_completo)),
        ""
    ) IS NOT NULL
    THEN TRIM(VALUES(nombre_completo))

    ELSE COALESCE(
        NULLIF(
            TRIM(VALUES(nombre_completo)),
            ""
        ),
        nombre_completo
    )
END,
            cargo=COALESCE(VALUES(cargo), cargo),
            ciudad=COALESCE(VALUES(ciudad), ciudad),
            proceso=COALESCE(VALUES(proceso), proceso),
            cliente=COALESCE(VALUES(cliente), cliente),
            proyecto=COALESCE(VALUES(proyecto), proyecto),
            razon_social_id=COALESCE(
                VALUES(razon_social_id),
                razon_social_id
            ),
            estado_laboral=CASE
                WHEN VALUES(fuente) IN (
                    "MatrizHDUniclass",
                    "PLANTA PERU"
                )
                THEN VALUES(estado_laboral)
                ELSE estado_laboral
            END,
            fuente=VALUES(fuente),
            fuente_id=VALUES(fuente_id)'
    );

    $stmt->execute([
        ':pais' => $data['pais'],
        ':documento' => $data['documento'],
        ':nombre' => $data['nombre'],
        ':cargo' => $data['cargo'],
        ':ciudad' => $data['ciudad'],
        ':proceso' => $data['proceso'],
        ':cliente' => $data['cliente'],
        ':proyecto' => $data['proyecto'],
        ':razon' => $data['razon_social_id'],
        ':estado_laboral' =>
            $data['estado_laboral'] ?? 'SIN_VALIDAR',
        ':fuente' => $data['fuente'],
        ':fuente_id' => $data['fuente_id'],
    ]);

    $this->stats['personas']++;

    return (int)$this->pdo->lastInsertId();
}

    private function upsertDomain(string $domain, ?int $reasonId): int
    {
        $domain = mb_strtolower(trim($domain), 'UTF-8');
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_dominios (dominio, razon_social_id)
             VALUES (:dominio, :razon)
             ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id), razon_social_id=COALESCE(razon_social_id, VALUES(razon_social_id))'
        );
        $stmt->execute([':dominio' => $domain, ':razon' => $reasonId]);
        return (int)$this->pdo->lastInsertId();
    }

    private function upsertAccount(array $data): int
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_cuentas
             (correo, correo_normalizado, dominio_id, tipo, estado, razon_social_id, pais, ciudad,
              observaciones, fecha_creacion, legacy_sheet, legacy_row)
             VALUES
             (:correo, :correo_normalizado, :dominio, :tipo, "ACTIVA", :razon, :pais, :ciudad,
              :observaciones, :fecha, :hoja, :fila)
             ON DUPLICATE KEY UPDATE
              id=LAST_INSERT_ID(id), dominio_id=COALESCE(VALUES(dominio_id), dominio_id),
              razon_social_id=COALESCE(VALUES(razon_social_id), razon_social_id),
              ciudad=COALESCE(VALUES(ciudad), ciudad), observaciones=COALESCE(VALUES(observaciones), observaciones),
              legacy_sheet=VALUES(legacy_sheet), legacy_row=VALUES(legacy_row)'
        );
        $stmt->execute([
            ':correo' => $data['correo'], ':correo_normalizado' => ad_email_normalize($data['correo']),
            ':dominio' => $data['dominio_id'], ':tipo' => $data['tipo'], ':razon' => $data['razon_social_id'],
            ':pais' => $data['pais'], ':ciudad' => $data['ciudad'], ':observaciones' => $data['observaciones'],
            ':fecha' => $data['fecha_creacion'], ':hoja' => $data['legacy_sheet'], ':fila' => $data['legacy_row'],
        ]);
        $this->stats['cuentas']++;
        return (int)$this->pdo->lastInsertId();
    }

    private function ensureAccountAssignment(int $accountId, int $personId, ?string $startDate): bool
    {
        $stmt = $this->pdo->prepare(
            'SELECT id FROM ad_asignaciones_cuenta
             WHERE cuenta_id=:cuenta AND persona_id=:persona AND estado="ACTIVA" LIMIT 1'
        );
        $stmt->execute([':cuenta' => $accountId, ':persona' => $personId]);
        if ($stmt->fetchColumn()) {
            return false;
        }
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_asignaciones_cuenta
             (cuenta_id, persona_id, fecha_inicio, estado, motivo)
             VALUES (:cuenta, :persona, :fecha, "ACTIVA", "MIGRACION_EXCEL")'
        );
        $stmt->execute([
            ':cuenta' => $accountId,
            ':persona' => $personId,
            ':fecha' => $startDate ?: date('Y-m-d'),
        ]);
        return true;
    }

    private function reconcilePendingAssignments(string $country): void
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, persona_id, cuenta_id, observaciones
             FROM ad_asignaciones_cuenta
             WHERE estado = "PENDIENTE"
               AND motivo = "CAMBIO_ASIGNACION_PENDIENTE"
               AND persona_id IS NULL'
        );
        $stmt->execute();

        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$assignments) {
            return;
        }

        $documentToAssignments = [];
        foreach ($assignments as $assignment) {
            $observation = (string)($assignment['observaciones'] ?? '');
            if ($observation === '') {
                continue;
            }

            if (!preg_match('/documento:\s*([0-9]+).*pais:\s*([A-Z]{2})/i', $observation, $matches)) {
                continue;
            }

            $document = $this->normalizeDocument($matches[1]);
            $assignmentCountry = strtoupper(trim($matches[2]));
            if ($document === null || $assignmentCountry !== strtoupper($country)) {
                continue;
            }

            $documentToAssignments[$document][] = (int)$assignment['id'];
        }

        if ($documentToAssignments === []) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($documentToAssignments), '?'));
        $query = 'SELECT id, numero_documento FROM ad_personas
                  WHERE pais = ?
                    AND numero_documento IN (' . $placeholders . ')';
        $stmt = $this->pdo->prepare($query);
        $params = array_merge([$country], array_keys($documentToAssignments));
        $stmt->execute($params);

        $persons = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($persons as $person) {
            $document = $this->normalizeDocument($person['numero_documento']);
            if ($document === null || !isset($documentToAssignments[$document])) {
                continue;
            }

            foreach ($documentToAssignments[$document] as $assignmentId) {
                $this->pdo->prepare(
                    'UPDATE ad_asignaciones_cuenta
                     SET persona_id = :persona,
                         estado = "ACTIVA",
                         motivo = "CAMBIO_ASIGNACION"
                     WHERE id = :id'
                )->execute([
                    ':persona' => $person['id'],
                    ':id' => $assignmentId,
                ]);

                $this->stats['reconciliaciones']++;
            }
        }
    }

    private function upsertDistributionProfile(int $accountId, array $row, string $company): void
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_perfiles_distribucion_cuenta
             (cuenta_id, plan_fuente, costo_mensual, moneda, proceso_cu1, ciudad,
              cu3, cliente, linea_negocio, proyecto, empresa, proceso_general,
              observaciones, fuente)
             VALUES (:cuenta, :plan, :costo, "USD", :proceso, :ciudad,
              :cu3, :cliente, :linea, :proyecto, :empresa, :proceso_general,
              :observaciones, "BASE_PPAL")
             ON DUPLICATE KEY UPDATE
              plan_fuente=COALESCE(VALUES(plan_fuente), plan_fuente),
              costo_mensual=COALESCE(VALUES(costo_mensual), costo_mensual),
              moneda="USD",
              proceso_cu1=COALESCE(VALUES(proceso_cu1), proceso_cu1),
              ciudad=COALESCE(VALUES(ciudad), ciudad),
              cu3=COALESCE(VALUES(cu3), cu3),
              cliente=VALUES(cliente),
              linea_negocio=COALESCE(VALUES(linea_negocio), linea_negocio),
              proyecto=COALESCE(VALUES(proyecto), proyecto),
              empresa=COALESCE(VALUES(empresa), empresa),
              proceso_general=COALESCE(VALUES(proceso_general), proceso_general),
              observaciones=COALESCE(VALUES(observaciones), observaciones),
              fuente="BASE_PPAL"'
        );
        $price = $row['PRECIO_USD'] ?? null;
        $stmt->execute([
            ':cuenta' => $accountId,
            ':plan' => $this->cleanNullable($row['PLAN'] ?? null),
            ':costo' => is_numeric($price) ? (float)$price : null,
            ':proceso' => $this->cleanNullable($row['PROCESO'] ?? null),
            ':ciudad' => $this->cleanNullable($row['CIUDAD_LABOR'] ?? null),
            ':cu3' => $this->cleanNullable($row['CU3'] ?? null),
            ':cliente' => $this->clientValue($row['CU3_CLIENTE'] ?? null),
            ':linea' => $this->cleanNullable($row['CU3_LINEA_NEGOCIO'] ?? null),
            ':proyecto' => $this->cleanNullable($row['CU3_PROYECTO'] ?? null),
            ':empresa' => $this->cleanNullable($company),
            ':proceso_general' => $this->cleanNullable($row['PROCESO'] ?? null),
            ':observaciones' => $this->cleanNullable($row['OBSERVACION'] ?? null),
        ]);
    }

    private function clientValue($value): ?string
    {
        $client = $this->cleanNullable($value);
        return $client !== null && ad_is_valid_dashboard_client($client) ? $client : null;
    }

    private function resolvePlan(string $rawName): int
    {
        $normalized = $this->canonicalPlanName($rawName);
        $stmt = $this->pdo->prepare(
            'SELECT plan_id FROM ad_plan_aliases WHERE alias_normalizado=:alias LIMIT 1'
        );
        $stmt->execute([':alias' => $normalized]);
        $planId = $stmt->fetchColumn();
        if ($planId) {
            return (int)$planId;
        }
        $stmt = $this->pdo->prepare('SELECT id FROM ad_planes WHERE nombre=:nombre LIMIT 1');
        $stmt->execute([':nombre' => $normalized]);
        $planId = $stmt->fetchColumn();
        if ($planId) {
            return (int)$planId;
        }
        $code = 'MIG_' . strtoupper(substr(hash('sha256', $normalized), 0, 12));
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_planes (codigo, nombre, fabricante, categoria)
             VALUES (:codigo, :nombre, :fabricante, "OTRO")'
        );
        $stmt->execute([
            ':codigo' => $code,
            ':nombre' => $normalized,
            ':fabricante' => ClientDashboardService::normalizeLicenseManufacturer('', $normalized) ?: null,
        ]);
        $planId = (int)$this->pdo->lastInsertId();
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_plan_aliases (plan_id, alias, alias_normalizado) VALUES (:plan, :alias, :normalizado)'
        );
        $stmt->execute([':plan' => $planId, ':alias' => $rawName, ':normalizado' => $normalized]);
        return $planId;
    }

    private function findPlanId(string $rawName): ?int
    {
        $normalized = $this->canonicalPlanName($rawName);
        if ($normalized === '') {
            return null;
        }
        $stmt = $this->pdo->prepare('SELECT plan_id FROM ad_plan_aliases WHERE alias_normalizado=:plan LIMIT 1');
        $stmt->execute([':plan' => $normalized]);
        $id = $stmt->fetchColumn();
        if (!$id) {
            $stmt = $this->pdo->prepare('SELECT id FROM ad_planes WHERE nombre=:plan LIMIT 1');
            $stmt->execute([':plan' => $normalized]);
            $id = $stmt->fetchColumn();
        }
        return $id ? (int)$id : null;
    }

    private function canonicalPlanName(string $rawName): string
    {
        $normalized = ad_normalize_text($rawName);
        if (in_array($normalized, ['EXCHANGE ONLINE PLAN 1', 'EXCHANGE ONLINE (PLAN 1)'], true)) {
            return 'EXCHANGE ONLINE (PLAN 1)';
        }
        return $normalized;
    }

    private function resolveImportedSubscription(
        int $planId,
        float $price,
        string $country,
        ?int $reasonId,
        string $domainCategory
    ): int {
        $hash = hash('sha256', implode('|', [
            'MIGRACION_EXCEL', $planId, number_format($price, 4, '.', ''), $country,
            $reasonId ?? 'NULL', ad_normalize_text($domainCategory),
        ]));
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_suscripciones
             (plan_id, razon_social_id, referencia_contrato, pais, valor_unitario, moneda,
              periodicidad, estado, origen, hash_importacion)
             VALUES
             (:plan, :razon, :referencia, :pais, :valor, "USD", "MENSUAL", "VIGENTE", "MIGRACION_EXCEL", :hash)
             ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id), valor_unitario=VALUES(valor_unitario)'
        );
        $stmt->execute([
            ':plan' => $planId,
            ':razon' => $reasonId,
            ':referencia' => 'MIG-' . $country . '-' . substr($hash, 0, 10),
            ':pais' => $country,
            ':valor' => $price,
            ':hash' => $hash,
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    private function ensureLicenseAssignment(
        int $accountId,
        int $planId,
        int $subscriptionId,
        ?string $startDate,
        float $price
    ): bool {
        $stmt = $this->pdo->prepare(
            'SELECT al.id,al.motivo FROM ad_asignaciones_licencia al
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             WHERE al.cuenta_id=:cuenta AND s.plan_id=:plan AND al.estado="ACTIVA"
             ORDER BY al.id'
        );
        $stmt->execute([':cuenta' => $accountId, ':plan' => $planId]);
        $existing = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $imported = [];
        foreach ($existing as $assignment) {
            if ((string)$assignment['motivo'] === 'MIGRACION_EXCEL') {
                $imported[] = (int)$assignment['id'];
            }
        }
        if ($imported) {
            $keepId = array_shift($imported);
            $update = $this->pdo->prepare(
                'UPDATE ad_asignaciones_licencia SET suscripcion_id=:suscripcion,valor_unitario_asignado=:valor,
                 fecha_inicio=:fecha,moneda="USD",fecha_fin=NULL,estado="ACTIVA",motivo="MIGRACION_EXCEL" WHERE id=:id'
            );
            $update->execute([':suscripcion'=>$subscriptionId, ':valor'=>$price, ':fecha'=>$startDate ?: date('Y-m-d'), ':id'=>$keepId]);
            $this->stats['filas_actualizadas']++;
            if ($imported) {
                $marks = implode(',', array_fill(0, count($imported), '?'));
                $close = $this->pdo->prepare(
                    'UPDATE ad_asignaciones_licencia SET estado="CERRADA",fecha_fin=CURDATE(),motivo="DEPURACION_DUPLICADO_IMPORTACION" WHERE id IN (' . $marks . ')'
                );
                $close->execute($imported);
            }
            return false;
        }
        if ($existing) {
            return false;
        }
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_asignaciones_licencia
             (cuenta_id, suscripcion_id, fecha_inicio, valor_unitario_asignado, moneda, estado, motivo)
             VALUES (:cuenta, :suscripcion, :fecha, :valor, "USD", "ACTIVA", "MIGRACION_EXCEL")'
        );
        $stmt->execute([
            ':cuenta' => $accountId,
            ':suscripcion' => $subscriptionId,
            ':fecha' => $startDate ?: date('Y-m-d'),
            ':valor' => $price,
        ]);
        return true;
    }

    private function synchronizeBasePpalAssignments(): void
    {
        $statement = $this->pdo->query(
            'SELECT al.id,al.cuenta_id,s.plan_id FROM ad_asignaciones_licencia al
             INNER JOIN ad_suscripciones s ON s.id=al.suscripcion_id
             WHERE al.estado="ACTIVA" AND al.motivo="MIGRACION_EXCEL"'
        );
        $close = $this->pdo->prepare(
            'UPDATE ad_asignaciones_licencia SET estado="CERRADA",fecha_fin=CURDATE(),motivo="DEPURACION_DUPLICADO_IMPORTACION" WHERE id=:id'
        );
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $assignment) {
            $accountId = (int)$assignment['cuenta_id'];
            $planId = (int)$assignment['plan_id'];
            if (!isset($this->basePpalPlans[$accountId][$planId])) {
                $close->execute([':id' => (int)$assignment['id']]);
            }
        }
        $accounts = $this->pdo->query(
            'SELECT id FROM ad_cuentas WHERE legacy_sheet="BASE_PPAL" AND estado="ACTIVA"'
        )->fetchAll(PDO::FETCH_COLUMN);
        $deactivate = $this->pdo->prepare('UPDATE ad_cuentas SET estado="GESTION_DE_BAJA" WHERE id=:id');
        foreach ($accounts as $accountId) {
            if (!isset($this->basePpalAccounts[(int)$accountId])) {
                $deactivate->execute([':id' => (int)$accountId]);
            }
        }
    }

    private function findExistingImport(string $hash): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM ad_importaciones WHERE hash_archivo=:hash AND tipo="CONTROL_USUARIOS" LIMIT 1'
        );
        $stmt->execute([':hash' => $hash]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    private function startImport(string $filePath, string $hash, ?int $existingId): int
    {
        if ($existingId !== null) {
            $stmt = $this->pdo->prepare(
                'UPDATE ad_importaciones SET estado="INICIADA", started_at=NOW(), finished_at=NULL,
                 filas_leidas=0, filas_insertadas=0, filas_actualizadas=0, filas_omitidas=0,
                 errores=0, resumen=NULL WHERE id=:id'
            );
            $stmt->execute([':id' => $existingId]);
            $clear = $this->pdo->prepare('DELETE FROM ad_importacion_errores WHERE importacion_id=:id');
            $clear->execute([':id' => $existingId]);
            return $existingId;
        }
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_importaciones (archivo, hash_archivo, tipo, ejecutado_por)
             VALUES (:archivo, :hash, "CONTROL_USUARIOS", :usuario)'
        );
        $stmt->execute([
            ':archivo' => basename($filePath), ':hash' => $hash, ':usuario' => ad_current_user_id(),
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    private function finishImport(string $status, ?string $fatalMessage = null): void
    {
        $summary = $this->stats;
        if ($fatalMessage !== null) {
            $summary['error_fatal'] = $fatalMessage;
        }
        $stmt = $this->pdo->prepare(
            'UPDATE ad_importaciones SET estado=:estado, filas_leidas=:leidas,
             filas_insertadas=:insertadas, filas_actualizadas=:actualizadas,
             filas_omitidas=:omitidas, errores=:errores, resumen=:resumen, finished_at=NOW()
             WHERE id=:id'
        );
        $stmt->execute([
            ':estado' => $status,
            ':leidas' => $this->stats['filas_leidas'],
            ':insertadas' => $this->stats['filas_insertadas'],
            ':actualizadas' => $this->stats['filas_actualizadas'],
            ':omitidas' => $this->stats['filas_omitidas'],
            ':errores' => $this->stats['errores'],
            ':resumen' => json_encode($summary, JSON_UNESCAPED_UNICODE),
            ':id' => $this->importId,
        ]);
    }

    private function skipOrError(string $sheet, array $row, ?string $field, string $message, bool $skip): void
    {
        if ($skip) {
            $this->stats['filas_omitidas']++;
        }
        $this->recordError($sheet, (int)($row['_row'] ?? 0), $field, $message, $row);
    }

    private function recordError(string $sheet, int $row, ?string $field, string $message, array $data): void
    {
        $this->stats['errores']++;
        $stmt = $this->pdo->prepare(
            'INSERT INTO ad_importacion_errores
             (importacion_id, hoja, fila, campo, mensaje, datos)
             VALUES (:importacion, :hoja, :fila, :campo, :mensaje, :datos)'
        );
        $stmt->execute([
            ':importacion' => $this->importId,
            ':hoja' => $sheet,
            ':fila' => $row,
            ':campo' => $field,
            ':mensaje' => mb_substr($message, 0, 500),
            ':datos' => json_encode($data, JSON_UNESCAPED_UNICODE),
        ]);
    }

    private function cleanNullable($value): ?string
    {
        $value = trim((string)$value);
        return $value === '' || $this->isNullToken($value) ? null : $value;
    }

    private function isNullToken(string $value): bool
    {
        return in_array(ad_normalize_text($value), ['NA', 'N/A', '#N/A', 'NULL', '0'], true);
    }
}
