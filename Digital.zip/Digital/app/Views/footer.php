</main>
<script src="<?= ad_e(ad_url('assets/bootstrap.bundle.min.js')) ?>"></script>
<?php if (!empty($user)): ?>
<script>
(function () {
    const statusUrl = <?= json_encode(ad_url('api/session_status.php'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const loginUrl = <?= json_encode(ad_url('login.php'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    let redirected = false;

    function checkSession() {
        if (redirected) {
            return;
        }
        fetch(statusUrl, {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {'X-Requested-With': 'XMLHttpRequest'}
        }).then(function (response) {
            if (response.status === 401 || response.status === 403) {
                redirected = true;
                window.location.replace(loginUrl);
            }
        }).catch(function () {
            // Un corte temporal de red no cierra la sesión localmente.
        });
    }

    window.setInterval(checkSession, 5000);
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            checkSession();
        }
    });
})();
</script>
<?php endif; ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.record-list').forEach(function (list) {
        const records = list.querySelectorAll(':scope > details');

        records.forEach(function (record) {
            record.addEventListener('toggle', function () {
                if (!record.open) {
                    return;
                }

                records.forEach(function (otherRecord) {
                    if (otherRecord !== record) {
                        otherRecord.open = false;
                    }
                });
            });
        });
    });
});
</script>
</body>
</html>
