<?php
declare(strict_types=1);

function ad_current_user(): ?array
{
    $user = $_SESSION['ad_user'] ?? null;
    if (!is_array($user)) {
        return null;
    }

    /*
     * Refresca rol, nombre y estado una vez por solicitud. Así los cambios
     * realizados por un administrador aplican sin borrar ni recrear sesiones.
     */
    static $refreshedUserId = null;
    static $validatedSessionHash = null;
    $userId = (int)($user['id'] ?? 0);
    if ($userId > 0 && $refreshedUserId !== $userId) {
        $refreshedUserId = $userId;
        try {
            $statement = db()->prepare(
                'SELECT id,nombre,email,rol,activo
                 FROM ad_usuarios WHERE id=:id LIMIT 1'
            );
            $statement->execute([':id' => $userId]);
            $current = $statement->fetch(PDO::FETCH_ASSOC);
            if (!$current || (int)$current['activo'] !== 1) {
                unset($_SESSION['ad_user']);
                return null;
            }
            $_SESSION['ad_user'] = [
                'id' => (int)$current['id'],
                'nombre' => (string)$current['nombre'],
                'email' => (string)$current['email'],
                'rol' => (string)$current['rol'],
            ];
            $user = $_SESSION['ad_user'];
        } catch (Throwable $ignored) {
            // Antes de ejecutar la migración se conserva la sesión existente.
        }
    }

    // La fila de sesión es el permiso de autenticación actual. Si otro
    // dispositivo inició sesión, claimUserSession() cerró esta fila y la
    // cookie antigua ya no puede seguir utilizando la aplicación.
    if ($userId > 0) {
        $sessionHash = SessionAuditService::currentSessionHash();
        if ($validatedSessionHash !== $sessionHash) {
            try {
                $statement = db()->prepare(
                    'SELECT usuario_id,estado
                     FROM ad_sesiones_usuario
                     WHERE session_hash=:hash LIMIT 1'
                );
                $statement->execute([':hash' => $sessionHash]);
                $session = $statement->fetch(PDO::FETCH_ASSOC);
                if (!$session
                    || (int)$session['usuario_id'] !== $userId
                    || (string)$session['estado'] !== 'ABIERTA'
                ) {
                    unset($_SESSION['ad_user']);
                    $_SESSION['ad_session_notice'] =
                        'Esta sesión se cerró porque se inició sesión en otro dispositivo.';
                    session_regenerate_id(true);
                    return null;
                }
                $validatedSessionHash = $sessionHash;
            } catch (Throwable $ignored) {
                // Ante cualquier fallo al validar la sesión se aplica
                // denegación segura: no se conserva una sesión que no pudo
                // comprobarse contra la base de datos.
                unset($_SESSION['ad_user']);
                $_SESSION['ad_session_notice'] =
                    'No fue posible validar la sesión. Ingrese nuevamente.';
                session_regenerate_id(true);
                return null;
            }
        }
    }

    return $user;
}

function ad_is_authenticated(): bool
{
    return ad_current_user() !== null;
}

function ad_user_role(): string
{
    $user = ad_current_user();
    return $user ? mb_strtoupper(trim((string)$user['rol']), 'UTF-8') : 'SIN_ROL';
}

function ad_attempt_login(string $email, string $password): bool
{
    $stmt = db()->prepare(
        'SELECT id, nombre, email, password_hash, rol
         FROM ad_usuarios
         WHERE email=:email AND activo=1
         LIMIT 1'
    );
    $stmt->execute([':email' => mb_strtolower(trim($email), 'UTF-8')]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, (string)$user['password_hash'])) {
        SessionAuditService::loginFailed($email);
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['ad_user'] = [
        'id' => (int)$user['id'],
        'nombre' => (string)$user['nombre'],
        'email' => (string)$user['email'],
        'rol' => (string)$user['rol'],
    ];

    SessionAuditService::claimUserSession($_SESSION['ad_user']);

    $update = db()->prepare('UPDATE ad_usuarios SET ultimo_acceso=NOW() WHERE id=:id');
    $update->execute([':id' => (int)$user['id']]);
    SessionAuditService::loginSuccess($_SESSION['ad_user']);
    return true;
}

function ad_logout(): void
{
    SessionAuditService::logout(ad_current_user());
    unset($_SESSION['ad_user']);
    session_regenerate_id(true);
}

function ad_require_auth(): void
{
    if (!ad_is_authenticated()) {
        $target = $_SERVER['REQUEST_URI'] ?? ad_url();
        $safeTarget = ad_safe_intended_url($target);
        if ($safeTarget !== null) {
            $_SESSION['ad_intended_url'] = $safeTarget;
        } else {
            unset($_SESSION['ad_intended_url']);
        }
        header('Location: ' . ad_url('login.php'));
        exit;
    }
}

function ad_can(string $permission): bool
{
    if (!ad_is_authenticated()) {
        return false;
    }
    $role = ad_user_role();
    $roles = ad_config('roles') ?? [];
    $rolePermissions = $roles[$role] ?? [];
    if ($role === 'ADMIN' || in_array('*', $rolePermissions, true)) {
        return true;
    }
    if ($role === 'CONSULTOR') {
        return $permission === 'dashboards.clientes.ver';
    }
    if ($permission === 'usuarios.administrar') {
        return false;
    }

    $user = ad_current_user();
    $userId = (int)($user['id'] ?? 0);
    static $userOverrides = [];
    $cacheKey = $userId . '|' . $permission;
    if (!array_key_exists($cacheKey, $userOverrides)) {
        $userOverrides[$cacheKey] = null;
        try {
            $statement = db()->prepare(
                'SELECT up.permitido
                 FROM ad_usuario_permisos up
                 INNER JOIN ad_permisos p ON p.id=up.permiso_id
                 WHERE up.usuario_id=:usuario AND p.codigo=:permiso AND p.activo=1
                 LIMIT 1'
            );
            $statement->execute([
                ':usuario' => $userId,
                ':permiso' => $permission,
            ]);
            $override = $statement->fetchColumn();
            if ($override !== false) {
                $userOverrides[$cacheKey] = (int)$override === 1;
            }
        } catch (Throwable $ignored) {
            // Compatibilidad mientras se instala la migración de permisos.
        }
    }

    if ($userOverrides[$cacheKey] !== null) {
        return $userOverrides[$cacheKey];
    }
    return in_array($permission, $rolePermissions, true);
}

/**
 * Retorna null cuando el usuario puede consultar todos los clientes; de lo
 * contrario retorna los identificadores expresamente asignados.
 */
function ad_dashboard_client_ids(): ?array
{
    $user = ad_current_user();
    if (!$user) {
        return [];
    }
    $role = ad_user_role();
    if ($role === 'ADMIN') {
        return null;
    }

    static $loaded = false;
    static $result = [];
    if ($loaded) {
        return $result;
    }
    $loaded = true;
    try {
        $allStatement = db()->prepare(
            'SELECT todos_clientes_dashboard FROM ad_usuarios WHERE id=:id'
        );
        $allStatement->execute([':id' => (int)$user['id']]);
        if ($role !== 'CONSULTOR' && (int)$allStatement->fetchColumn() === 1) {
            $result = null;
            return null;
        }
        $statement = db()->prepare(
            'SELECT c.id,c.nombre
             FROM ad_usuario_clientes_dashboard uc
             INNER JOIN ad_clientes_dashboard c ON c.id=uc.cliente_id
             WHERE uc.usuario_id=:id AND c.activo=1
             ORDER BY c.nombre'
        );
        $statement->execute([':id' => (int)$user['id']]);
        $result = [];
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $client) {
            if (ad_is_valid_dashboard_client((string)$client['nombre'])) {
                $result[] = (int)$client['id'];
            }
        }
    } catch (Throwable $ignored) {
        $result = [];
    }
    return $result;
}

function ad_can_view_dashboard_client($client): bool
{
    if (!ad_can('dashboards.clientes.ver')) {
        return false;
    }
    $allowed = ad_dashboard_client_ids();
    if ($allowed === null) {
        return true;
    }
    if (is_numeric($client)) {
        return in_array((int)$client, $allowed, true);
    }
    try {
        $statement = db()->prepare(
            'SELECT id,nombre FROM ad_clientes_dashboard WHERE codigo=:codigo AND activo=1 LIMIT 1'
        );
        $statement->execute([':codigo' => mb_strtoupper(trim((string)$client), 'UTF-8')]);
        $clientRow = $statement->fetch(PDO::FETCH_ASSOC);
        return $clientRow
            && ad_is_valid_dashboard_client((string)$clientRow['nombre'])
            && in_array((int)$clientRow['id'], $allowed, true);
    } catch (Throwable $ignored) {
        return false;
    }
}

/**
 * Construye una condición segura para consultas de dashboards por cliente.
 * null significa todos, 0=1 significa ningún cliente autorizado.
 */
function ad_dashboard_client_sql(string $column, array &$parameters): string
{
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_.]*$/', $column)) {
        throw new InvalidArgumentException('La columna de cliente no es válida.');
    }
    if (!ad_can('dashboards.clientes.ver')) {
        return '0=1';
    }
    $ids = ad_dashboard_client_ids();
    if ($ids === null) {
        return '1=1';
    }
    if (!$ids) {
        return '0=1';
    }
    $placeholders = [];
    foreach ($ids as $index => $id) {
        $key = ':cliente_permiso_' . $index;
        $placeholders[] = $key;
        $parameters[$key] = $id;
    }
    return $column . ' IN (' . implode(',', $placeholders) . ')';
}

function ad_require_permission(string $permission): void
{
    ad_require_auth();
    if (!ad_can($permission)) {
        ad_deny_access($permission);
    }
}

function ad_deny_access(string $permission): void
{
    http_response_code(403);
    SessionAuditService::accessDenied($permission);
    exit('No tiene permisos para acceder a este módulo');
}

/**
 * CONSULTOR solo puede usar el informe por cliente y su descarga CSV. Esta
 * guardia se ejecuta desde bootstrap antes de cargar cualquier controlador.
 */
function ad_enforce_consultor_module_access(): void
{
    if (PHP_SAPI === 'cli' || !ad_is_authenticated() || ad_user_role() !== 'CONSULTOR') {
        return;
    }

    $path = parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    $path = strtolower(str_replace('\\', '/', is_string($path) ? $path : ''));
    if (preg_match('~/(?:dashboards/(?:informe|informe_exportar)\.php|api/session_status\.php|(?:login|logout)\.php)$~', $path)) {
        return;
    }

    ad_deny_access('consultor.ruta.restringida');
}

/**
 * Define el inicio apropiado sin otorgar permisos adicionales.
 * Los consultores entran al informe de los clientes que les asignó el admin.
 */
function ad_home_path(): string
{
    if (ad_is_authenticated()
        && ad_user_role() === 'CONSULTOR'
        && ad_can('dashboards.clientes.ver')) {
        return 'dashboards/informe.php';
    }
    return 'index.php';
}
