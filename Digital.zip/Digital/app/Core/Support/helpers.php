<?php
declare(strict_types=1);

function ad_config(?string $key = null)
{
    static $config;
    if ($config === null) {
        $config = require dirname(__DIR__, 3) . '/config/module.php';
    }
    return $key === null ? $config : ($config[$key] ?? null);
}

function ad_url(string $path = ''): string
{
    $base = rtrim((string)ad_config('base_url'), '/');
    if ($base === '' && PHP_SAPI !== 'cli') {
        $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
        $publicPosition = strpos($scriptName, '/public/');
        $detectedBase = $publicPosition !== false
            ? substr($scriptName, 0, $publicPosition + strlen('/public'))
            : rtrim(dirname($scriptName), '/.');
        $base = $detectedBase === '' ? '' : $detectedBase;
    }
    if ($path === '') {
        return $base !== '' ? $base : '/';
    }
    return ($base !== '' ? $base : '') . '/' . ltrim($path, '/');
}

function ad_e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function ad_csrf_token(): string
{
    if (empty($_SESSION['ad_csrf'])) {
        $_SESSION['ad_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['ad_csrf'];
}

function ad_verify_csrf(): void
{
    $token = $_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(ad_csrf_token(), $token)) {
        http_response_code(419);
        exit('Token CSRF inválido.');
    }
}

function ad_redirect(string $path = ''): void
{
    $target = $path === '' ? ad_url() : ad_url($path);
    if ($path !== '' && ad_safe_intended_url($target) === null) {
        $target = ad_url('login.php');
    }
    header('Location: ' . $target);
    exit;
}

function ad_safe_intended_url($target): ?string
{
    if (!is_string($target) || $target === ''
        || preg_match('/[\x00-\x1F\x7F\r\n]/', $target)
        || strpos($target, '\\') !== false
        || strpos($target, '//') === 0
    ) {
        return null;
    }
    $parts = parse_url($target);
    if ($parts === false
        || isset($parts['scheme'])
        || isset($parts['host'])
        || isset($parts['port'])
        || isset($parts['user'])
        || isset($parts['pass'])
        || isset($parts['fragment'])
    ) {
        return null;
    }
    $path = (string)($parts['path'] ?? '');
    $decodedPath = rawurldecode($path);
    if (strpos($decodedPath, '\\') !== false) {
        return null;
    }
    foreach (explode('/', $decodedPath) as $segment) {
        if ($segment === '.' || $segment === '..') {
            return null;
        }
    }
    $basePath = (string)(parse_url(ad_url(), PHP_URL_PATH) ?? '');
    $basePath = rtrim($basePath, '/');
    if ($path === '' || ($basePath !== '' && $path !== $basePath && strpos($path, $basePath . '/') !== 0)) {
        return null;
    }
    $lowerPath = mb_strtolower(rtrim($path, '/'), 'UTF-8');
    if (substr($lowerPath, -10) === '/login.php' || substr($lowerPath, -11) === '/logout.php') {
        return null;
    }
    return $target;
}

function ad_flash(string $type, string $message): void
{
    $_SESSION['ad_flash'][] = ['type' => $type, 'message' => $message];
}

function ad_pull_flashes(): array
{
    $items = $_SESSION['ad_flash'] ?? [];
    unset($_SESSION['ad_flash']);
    return is_array($items) ? $items : [];
}

function ad_normalize_text(?string $value): string
{
    $value = trim((string)$value);
    $value = strtr($value, [
        'á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ñ'=>'n',
        'Á'=>'A','É'=>'E','Í'=>'I','Ó'=>'O','Ú'=>'U','Ñ'=>'N',
    ]);
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return mb_strtoupper($value, 'UTF-8');
}

function ad_normalize_dashboard_client(?string $value): string
{
    $normalized = ad_normalize_text($value);
    return preg_replace('/[\s\/.]+/u', '', $normalized) ?? $normalized;
}

function ad_is_pending_reassignment_client(?string $value): bool
{
    return ad_normalize_dashboard_client($value) === 'NA';
}

function ad_is_valid_dashboard_client(?string $value): bool
{
    $normalized = ad_normalize_dashboard_client($value);
    return $normalized !== '' && $normalized !== 'NA';
}

function ad_email_normalize(string $email): string
{
    return mb_strtolower(trim($email), 'UTF-8');
}

function ad_currency(): string
{
    return (string)(ad_config('currency') ?: 'USD');
}

function ad_money($value, string $currency = 'USD'): string
{
    $currency = strtoupper(trim($currency));
    if ($currency === '') {
        $currency = ad_currency();
    }
    return $currency . ' ' . number_format((float)$value, 2, ',', '.');
}

function ad_current_user_id(): ?int
{
    $user = ad_current_user();
    return $user ? (int)$user['id'] : null;
}

function ad_json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ad_excel_serial_to_date($value): ?string
{
    if ($value === null || $value === '') {
        return null;
    }
    if (is_numeric($value)) {
        $days = (int)floor((float)$value);
        $date = (new DateTimeImmutable('1899-12-30'))->modify('+' . $days . ' days');
        return $date->format('Y-m-d');
    }
    $parsed = date_create_immutable((string)$value);
    return $parsed ? $parsed->format('Y-m-d') : null;
}
