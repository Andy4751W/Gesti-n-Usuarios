<?php
require dirname(__DIR__, 2) . '/app/Modules/Facturas/distribucion_generar.php';
