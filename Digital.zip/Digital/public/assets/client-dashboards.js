(function () {
    'use strict';
    var data = window.clientDashboardData || {};
    var colors = ['#246bfd', '#7257d9', '#13a06f', '#f0a028', '#df4d5c', '#0a91ad', '#65758b', '#d75dab', '#76a82a', '#965ee8'];
    var money = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 });
    var integer = new Intl.NumberFormat('es-CO', { maximumFractionDigits: 0 });

    function setup(id, hasData) {
        var canvas = document.getElementById(id);
        if (!canvas) return null;
        var box = canvas.parentElement;
        box.classList.toggle('is-empty', !hasData);
        if (!hasData) return null;
        var ratio = Math.max(1, window.devicePixelRatio || 1);
        var width = Math.max(260, box.clientWidth);
        var height = Math.max(180, box.clientHeight);
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
        var context = canvas.getContext('2d');
        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        context.clearRect(0, 0, width, height);
        return { ctx: context, width: width, height: height };
    }

    function total(rows) {
        return (rows || []).reduce(function (sum, row) { return sum + Number(row.value || 0); }, 0);
    }

    function legend(elementId, rows) {
        var element = document.getElementById(elementId);
        if (!element) return;
        element.innerHTML = '';
        rows.forEach(function (row, index) {
            var item = document.createElement('div');
            item.className = 'chart-legend-item';
            var dot = document.createElement('span');
            dot.className = 'chart-legend-dot';
            dot.style.backgroundColor = colors[index % colors.length];
            var label = document.createElement('span');
            label.className = 'chart-legend-label';
            label.title = row.label;
            label.textContent = row.label;
            var value = document.createElement('span');
            value.className = 'chart-legend-value';
            value.textContent = integer.format(Number(row.value || 0));
            item.appendChild(dot); item.appendChild(label); item.appendChild(value); element.appendChild(item);
        });
    }

    function donut(canvasId, legendId, rows) {
        rows = rows || [];
        var sum = total(rows);
        var chart = setup(canvasId, sum > 0);
        legend(legendId, rows);
        if (!chart) return;
        var ctx = chart.ctx;
        var cx = chart.width / 2;
        var cy = chart.height / 2;
        var radius = Math.min(chart.width, chart.height) * .37;
        var inner = radius * .62;
        var start = -Math.PI / 2;
        rows.forEach(function (row, index) {
            var angle = (Number(row.value || 0) / sum) * Math.PI * 2;
            ctx.beginPath(); ctx.arc(cx, cy, radius, start, start + angle); ctx.arc(cx, cy, inner, start + angle, start, true); ctx.closePath();
            ctx.fillStyle = colors[index % colors.length]; ctx.fill();
            ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
            start += angle;
        });
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#17243a'; ctx.font = '700 24px system-ui, sans-serif'; ctx.fillText(integer.format(sum), cx, cy - 6);
        ctx.fillStyle = '#7a899d'; ctx.font = '11px system-ui, sans-serif'; ctx.fillText('Total', cx, cy + 16);
    }

    function axes(ctx, width, height, max, formatter) {
        var left = 54, right = 14, top = 14, bottom = 35;
        ctx.font = '10px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
        for (var step = 0; step <= 4; step++) {
            var y = top + ((height - top - bottom) * step / 4);
            var value = max * (1 - step / 4);
            ctx.strokeStyle = '#e8edf4'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(width - right, y); ctx.stroke();
            ctx.fillStyle = '#8290a3'; ctx.fillText(formatter(value), left - 7, y);
        }
        return { left: left, right: right, top: top, bottom: bottom, width: width - left - right, height: height - top - bottom };
    }

    function line(canvasId, labels, values, monetary) {
        values = (values || []).map(Number);
        var hasData = values.some(function (value) { return value > 0; });
        var chart = setup(canvasId, hasData);
        if (!chart) return;
        var max = Math.max.apply(null, values.concat([1]));
        var compact = function (value) {
            if (monetary) return value >= 1000 ? '$' + (value / 1000).toFixed(0) + 'k' : '$' + value.toFixed(0);
            return integer.format(value);
        };
        var area = axes(chart.ctx, chart.width, chart.height, max * 1.12, compact);
        var ctx = chart.ctx;
        var points = values.map(function (value, index) {
            return {
                x: area.left + (values.length === 1 ? area.width / 2 : area.width * index / (values.length - 1)),
                y: area.top + area.height * (1 - value / (max * 1.12))
            };
        });
        var gradient = ctx.createLinearGradient(0, area.top, 0, area.top + area.height);
        gradient.addColorStop(0, 'rgba(36,107,253,.28)'); gradient.addColorStop(1, 'rgba(36,107,253,0)');
        ctx.beginPath(); ctx.moveTo(points[0].x, area.top + area.height); points.forEach(function (point) { ctx.lineTo(point.x, point.y); }); ctx.lineTo(points[points.length - 1].x, area.top + area.height); ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();
        ctx.beginPath(); points.forEach(function (point, index) { if (index === 0) ctx.moveTo(point.x, point.y); else ctx.lineTo(point.x, point.y); }); ctx.strokeStyle = '#246bfd'; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.stroke();
        points.forEach(function (point, index) { ctx.beginPath(); ctx.arc(point.x, point.y, 3.3, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#246bfd'; ctx.lineWidth = 2; ctx.stroke(); if (values[index] > 0) { ctx.fillStyle = '#34445b'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.font = '600 9px system-ui, sans-serif'; ctx.fillText(monetary ? money.format(values[index]) : integer.format(values[index]), point.x, point.y - 7); } });
        ctx.fillStyle = '#7d8b9e'; ctx.font = '9px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        (labels || []).forEach(function (label, index) { if (index % Math.max(1, Math.ceil(labels.length / 8)) === 0 || index === labels.length - 1) ctx.fillText(label, points[index].x, chart.height - area.bottom + 10); });
    }

    function horizontalBars(canvasId, rows) {
        rows = rows || [];
        var sum = total(rows);
        var chart = setup(canvasId, sum > 0);
        if (!chart) return;
        var ctx = chart.ctx, left = Math.min(145, chart.width * .38), right = 42, top = 8, bottom = 8;
        var max = Math.max.apply(null, rows.map(function (row) { return Number(row.value || 0); }).concat([1]));
        var band = (chart.height - top - bottom) / rows.length;
        ctx.font = '10px system-ui, sans-serif';
        rows.forEach(function (row, index) {
            var y = top + band * index + band * .19;
            var height = Math.max(8, band * .58);
            var width = (chart.width - left - right) * Number(row.value || 0) / max;
            ctx.fillStyle = '#edf1f7'; ctx.fillRect(left, y, chart.width - left - right, height);
            ctx.fillStyle = colors[index % colors.length]; ctx.fillRect(left, y, width, height);
            ctx.fillStyle = '#536278'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
            var label = row.label.length > 21 ? row.label.slice(0, 20) + '…' : row.label;
            ctx.fillText(label, left - 8, y + height / 2);
            ctx.fillStyle = '#26364c'; ctx.textAlign = 'left'; ctx.font = '700 10px system-ui, sans-serif'; ctx.fillText(integer.format(Number(row.value || 0)), Math.min(left + width + 6, chart.width - right + 4), y + height / 2); ctx.font = '10px system-ui, sans-serif';
        });
    }

    function draw() {
        donut('licenseDonutChart', 'licenseLegend', data.plans || []);
        donut('accountDonutChart', 'accountLegend', data.states || []);
        donut('backupDonutChart', 'backupLegend', data.backups || []);
        line('costTrendChart', data.months || [], data.costTrend || [], true);
        line('newsTrendChart', data.months || [], data.newsTrend || [], false);
        horizontalBars('businessLineChart', data.lines || []);
    }

    var timer;
    window.addEventListener('resize', function () { window.clearTimeout(timer); timer = window.setTimeout(draw, 140); });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw); else draw();
}());
