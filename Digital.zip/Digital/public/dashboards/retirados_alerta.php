<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/Modules/Dashboards/retirados_alerta.php';
