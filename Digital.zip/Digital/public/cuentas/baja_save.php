<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/Modules/Cuentas/baja_save.php';
