# Activos Digitales — PHP 7.4 / XAMPP

Aplicación PHP modular para administrar cuentas, licencias, novedades, respaldos y facturas de activos digitales. Esta edición no utiliza Docker. Incluye archivos `.htaccess` compatibles con Apache/XAMPP para funcionamiento y protección básica, todavía sin enmascaramiento de URL.

## Informes por cliente

El menú **Informes** crea el selector exclusivamente con los valores únicos de
`SHAREPOINT > CU3-CLIENTE`. Los nombres se respetan de forma exacta: por
ejemplo, `CLARO PERU`, `CLARO R3` y `CLARO R4` son clientes diferentes, al
igual que `HUAWEI` y `HUAWEI PERU`. No se agrupan alias ni se toman nombres de
`CONCATEN ALMACENES`.
Cada informe presenta tres indicadores directos: cuentas con licencia,
licencias asignadas y costo mensual en USD. Debajo se muestra un único resumen
por tipo de licencia con cantidad de cuentas, licencias, valor unitario y costo
mensual. El botón **Ver usuarios** despliega dentro de ese mismo resumen las
columnas Cuenta, Nombre, Documento, Cargo, Licencia, Valor mensual, CU3,
Cliente, Línea, Proyecto, Ciudad y País. No existe una segunda tabla repetida.
El detalle utiliza una barra horizontal fija en la parte inferior de la
pantalla para facilitar la lectura de todas las columnas. El catálogo se
actualiza automáticamente desde los perfiles ya
importados; los valores que dejan de existir en esa columna dejan de aparecer
en los selectores.

El bloque **Control de licenciamiento** identifica las cuentas que tienen más
de una licencia activa y consolida sus licencias y costo mensual. También
muestra las **Cuentas N/A pendientes de gestión**. Para este control, una cuenta
se considera N/A cuando pertenece al cliente seleccionado y todavía no tiene
ninguna licencia activa registrada en USD; no depende de que Excel escriba el
valor como `N/A`, `NA`, vacío o `SIN PLAN`.

Para el rol **ADMIN**, el mismo bloque incorpora la alerta **Retirados con
licencia**. El sistema cruza por documento —y por correo como respaldo— las
cuentas que tienen licencias activas en USD con la tabla empresarial
`mae_data_uniclass` mediante el `conexion.php` empresarial. Solo alerta cuando el último registro disponible en
UNICLASS tiene `EST = R`; las personas retiradas sin licencia no se consultan
ni se muestran. Técnicos y consultores no ejecutan esta consulta ni reciben el
detalle en el HTML.

No se importa ni replica la tabla. Por defecto, la aplicación reutiliza
`C:\xampp\htdocs\Digital\conexion.php`; este archivo puede retornar un objeto
PDO/MySQLi o exponerlo como `$pdo`, `$conexion`, `$conn`, `$mysqli` o `$con`.
Si el archivo ya existe en otra ubicación, indique su ruta absoluta mediante
`UNICLASS_CONNECTION_FILE` o edite `uniclass_connection.file` en
`config/module.php`. La cuenta usada allí debe tener permiso de solo lectura
sobre `mae_data_uniclass`.

La visibilidad se controla desde **Usuarios**: un administrador puede habilitar
todos los clientes o seleccionar clientes específicos para cada técnico o
consultor. El filtro se aplica en el servidor; ocultar una opción del menú no es
el mecanismo de seguridad.

## Nombres de los módulos y auditoría

`public/index.php` se reserva exclusivamente para la página de inicio. Los
archivos principales conservan sus carpetas y usan nombres identificables:
`cuentas/cuentas.php`, `novedades/novedades.php`,
`respaldos/respaldos.php`, `facturas/facturas.php`,
`auditoria/auditoria.php`, `usuarios/usuarios.php` y
`dashboards/informe.php`. De esta manera la ruta registrada en la auditoría
permite reconocer el módulo y el archivo PHP consultado.

## Requisitos

- XAMPP o servidor con PHP 7.4.x.
- Apache y MySQL iniciados desde el panel de control de XAMPP.
- Extensiones PHP `pdo_mysql`, `mbstring`, `zip` y `simplexml` habilitadas.

## Compatibilidad

Todo el código PHP fue ajustado para PHP 7.4. No utiliza tipos `mixed`, `never`, propiedades `readonly`, promoción de propiedades en constructores, tipos unión, `match`, operador nullsafe, capturas sin variable ni funciones `str_contains`/`str_starts_with` introducidas en PHP 8.

## Instalación

1. Elimine completamente cualquier versión anterior de `C:\xampp\htdocs\Digital` para evitar que permanezcan archivos `.htaccess` antiguos.
2. Copie la nueva carpeta `Digital` en `C:\xampp\htdocs\`.
3. Inicie Apache y MySQL desde XAMPP.
4. Abra el Símbolo del sistema de Windows.
5. Ejecute:

   ```text
   cd C:\xampp\htdocs\Digital
   C:\xampp\php\php.exe bin\install.php
   ```

   El instalador crea automáticamente la base de datos `activos_digitales`, sus tablas y los datos iniciales.

6. Abra `http://localhost/Digital/`. El proyecto lo llevará automáticamente al acceso del sistema.

Credenciales iniciales:

- Usuario: `admin@prueba.local`
- Contraseña: `Prueba2026`

## Conexión predeterminada

La aplicación utiliza la configuración habitual de MySQL en XAMPP:

- Servidor: `127.0.0.1`
- Puerto: `3306`
- Base de datos: `activos_digitales`
- Usuario: `root`
- Contraseña: vacía

Si su MySQL tiene otra contraseña, edite `config/module.php` antes de ejecutar el instalador.

## Estructura

- `public/`: entrada web y recursos estáticos.
- `app/Modules/`: módulos funcionales.
- `app/Core/Support/`: autenticación, conexión y utilidades.
- `app/Services/`: servicios compartidos.
- `app/Import/`: importadores de Excel.
- `app/Views/`: encabezado y pie comunes.
- `config/`: configuración y permisos.
- `database/`: migraciones y datos iniciales.
- `storage/`: facturas, archivos y registros generados.
- `bin/`: instalador y comandos administrativos.

## Direcciones actuales

Puede ingresar por `http://localhost/Digital/`, que lo remite al acceso, o directamente por `http://localhost/Digital/public/login.php`.

En esta etapa las direcciones internas conservan sus carpetas y archivos PHP. Los `.htaccess` incluidos no hacen reescrituras ni enmascaramiento; únicamente definen `index.php`, evitan listar directorios y bloquean el acceso web directo a las carpetas internas.

## Interfaz de listados

Los módulos Cuentas, Novedades y Backups presentan cada registro como una fila compacta. Al seleccionar una fila se abre su información detallada y se cierra cualquier otra fila que estuviera abierta. En Facturas, la fila completa abre la vista de la factura; también puede utilizarse con las teclas Enter o Espacio.

## Distribución mensual de facturas

Dentro de cada factura se encuentra el botón **Distribución de costos**. El módulo puede calcular la factura directamente desde la base de datos usando las licencias activas, tarifas, perfiles CU1/CU3, almacenes y reglas de distribución integral. También permite corregir pendientes y exportar tanto el detalle como el consolidado equivalente a las tablas de resumen del libro.

La primera vez use **Sincronizar Excel y distribuir** con el libro suministrado. Esa operación importa a la base de datos las hojas `BASE ADMIN`, `SHAREPOINT`, `CUs`, `CONCATEN ALMACENES` e `INTEGRALES R3`. Después puede mantener esa información desde **Facturas > Datos maestros** y usar **Calcular distribución** sin depender del archivo mensual.

Los cambios de licencia realizados desde **Cuentas > Gestión de cuenta** actualizan inmediatamente el plan y costo del perfil de facturación. La gestión **Eliminación sin backup** da de baja la cuenta y sus licencias sin crear un registro en Backups, y queda disponible como filtro en Novedades.

Si el sistema ya estaba instalado, haga una copia de seguridad de MySQL, reemplace los archivos del proyecto y ejecute solamente las migraciones:

```text
cd C:\xampp\htdocs\Digital
C:\xampp\php\php.exe bin\update.php
```

Este comando conserva los registros existentes y crea las tablas nuevas. `bin\install.php` debe reservarse para instalaciones nuevas.

## Tarifas registradas directamente en USD

La aplicación no consulta la TRM ni convierte valores desde pesos colombianos.
Los precios de las licencias se registran con el valor real cobrado por el
proveedor en dólares. Por ejemplo, si Microsoft 365 Business Standard cuesta
USD 5, se guarda y se muestra como `USD 5,00`.

Las tarifas se administran desde **Facturas → Datos maestros → Tarifas de
licencias**. Al cambiar una tarifa se actualizan la suscripción, las asignaciones
activas y los perfiles de distribución creados por movimientos de cuenta.

Los registros antiguos marcados como COP no se dividen ni se renombran como USD.
Se presentan como pendientes hasta que un administrador escriba su precio real
en dólares. Las columnas monetarias de los archivos que se importen deben contener
también valores expresados directamente en USD.

## Auditoría de sesiones y accesos

El módulo **Auditoría** está disponible para los roles `ADMIN` y `AUDITOR`.
Registra automáticamente inicios de sesión exitosos y fallidos, cierres de
sesión, páginas consultadas, acciones `POST` y accesos denegados. La vista de
uso general muestra actividad diaria y sesiones recientes; la vista detallada
permite filtrar por fechas, evento, método, módulo, usuario, IP y estado de la
sesión, además de exportar el resultado a CSV.

La aplicación guarda un hash irreversible de la sesión y nunca registra la
contraseña ni el contenido enviado en los formularios. Una sesión abierta con
más de 30 minutos sin actividad se presenta como inactiva.

## Usuarios, permisos e informes por cliente

El sistema utiliza tres roles base: `ADMIN`, `TECNICO` y `CONSULTOR`. El
Administrador conserva acceso completo; el Técnico recibe permisos de consulta
y gestión operativa; el Consultor recibe permisos de solo lectura.

Desde **Usuarios** el Administrador puede crear o inactivar usuarios, cambiar
su rol, restablecer la contraseña y marcar permisos particulares sin eliminar
la cuenta. Los permisos individuales prevalecen sobre la configuración base
del rol.

El mismo formulario permite autorizar todos los informes o seleccionar uno o
varios clientes. Los informes nuevos deben exigir el permiso
`dashboards.clientes.ver` y aplicar `ad_dashboard_client_sql()` en sus consultas,
o validar un cliente puntual con `ad_can_view_dashboard_client()`.

## Seguridad para producción

Esta configuración está preparada para desarrollo local en XAMPP. Antes de publicarla en Internet, cambie las credenciales iniciales, configure una contraseña segura de MySQL y haga que Apache apunte directamente a la carpeta `public/`.
