<?php
declare(strict_types=1);

if (PHP_VERSION_ID < 70400) {
    throw new RuntimeException(
        'Activos Digitales requiere PHP 7.4 o superior. Versión detectada: '
        . PHP_VERSION
    );
}

$config = require __DIR__ . '/config/module.php';
date_default_timezone_set($config['timezone']);

if (session_status() !== PHP_SESSION_ACTIVE) {
    /*
     * Nombre estable y distinto al usado por las versiones iniciales.
     * Evita reutilizar cookies antiguas que puedan dejar al navegador
     * atrapado entre la pantalla de ingreso y la página principal.
     */
    session_name('activos_digitales_v2');
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        'cookie_path' => '/',
        'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'use_strict_mode' => true,
    ]);
}

require_once __DIR__ . '/app/Core/Support/helpers.php';
require_once __DIR__ . '/app/Core/Support/database.php';
require_once __DIR__ . '/app/Core/Support/auth.php';
require_once __DIR__ . '/app/Services/AuditService.php';
require_once __DIR__ . '/app/Services/SessionAuditService.php';
ad_enforce_consultor_module_access();
require_once __DIR__ . '/app/Services/SessionAuditReportService.php';
require_once __DIR__ . '/app/Services/ClientDashboardService.php';
require_once __DIR__ . '/app/Services/BasePpalReportService.php';
require_once __DIR__ . '/app/Services/UniclassEmploymentService.php';
require_once __DIR__ . '/app/Services/NoveltyHistoryService.php';
require_once __DIR__ . '/app/Services/ReconciliationService.php';
require_once __DIR__ . '/app/Import/SimpleXlsxReader.php';
require_once __DIR__ . '/app/Import/SimpleXlsxWriter.php';
require_once __DIR__ . '/app/Services/InvoiceDistributionService.php';

SessionAuditService::captureRequest();
